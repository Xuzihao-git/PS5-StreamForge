/*
*****************************************************************************
* Copyright (C) 2024 MulticoreWare, Inc
*
* Authors: Hao Chen <chenhao@loongson.cn>
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02111, USA.
*
* This program is also available under a commercial proprietary license.
* For more information, contact us at license @ x265.com.
*****************************************************************************
*/

#include "loongson_asm.S"

const g_lumaFilter
.byte 0, 0, 0, 0, 0, 0, 64, 64, 0, 0, 0, 0, 0, 0, 0, 0
.byte 0, 0, 0, 0, 0, 0, 64, 64, 0, 0, 0, 0, 0, 0, 0, 0
.byte -1, -1, 4, 4, -10, -10, 58, 58, 17, 17, -5, -5, 1, 1, 0, 0
.byte -1, -1, 4, 4, -10, -10, 58, 58, 17, 17, -5, -5, 1, 1, 0, 0
.byte -1, -1, 4, 4, -11, -11, 40, 40, 40, 40, -11, -11, 4, 4, -1, -1
.byte -1, -1, 4, 4, -11, -11, 40, 40, 40, 40, -11, -11, 4, 4, -1, -1
.byte 0, 0, 1, 1, -5, -5, 17, 17, 58, 58, -10, -10, 4, 4, -1, -1
.byte 0, 0, 1, 1, -5, -5, 17, 17, 58, 58, -10, -10, 4, 4, -1, -1
.short 0, 0, 0, 64, 0, 0, 0, 0
.short -1, 4, -10, 58, 17, -5, 1, 0
.short -1, 4, -11, 40, 40, -11, 4, -1
.short 0, 1, -5, 17, 58, -10, 4, -1
endconst

const g_chromaFilter
.byte 0, 0, 64, 64, 0, 0, 0, 0, 0, 0, 64, 64, 0, 0, 0, 0
.byte 0, 0, 64, 64, 0, 0, 0, 0, 0, 0, 64, 64, 0, 0, 0, 0
.byte -2, -2, 58, 58, 10, 10, -2, -2, -2, -2, 58, 58, 10, 10, -2, -2
.byte -2, -2, 58, 58, 10, 10, -2, -2, -2, -2, 58, 58, 10, 10, -2, -2
.byte -4, -4, 54, 54, 16, 16, -2, -2, -4, -4, 54, 54, 16, 16, -2, -2
.byte -4, -4, 54, 54, 16, 16, -2, -2, -4, -4, 54, 54, 16, 16, -2, -2
.byte -6, -6, 46, 46, 28, 28, -4, -4, -6, -6, 46, 46, 28, 28, -4, -4
.byte -6, -6, 46, 46, 28, 28, -4, -4, -6, -6, 46, 46, 28, 28, -4, -4
.byte -4, -4, 36, 36, 36, 36, -4, -4, -4, -4, 36, 36, 36, 36, -4, -4
.byte -4, -4, 36, 36, 36, 36, -4, -4, -4, -4, 36, 36, 36, 36, -4, -4
.byte -4, -4, 28, 28, 46, 46, -6, -6, -4, -4, 28, 28, 46, 46, -6, -6
.byte -4, -4, 28, 28, 46, 46, -6, -6, -4, -4, 28, 28, 46, 46, -6, -6
.byte -2, -2, 16, 16, 54, 54, -4, -4, -2, -2, 16, 16, 54, 54, -4, -4
.byte -2, -2, 16, 16, 54, 54, -4, -4, -2, -2, 16, 16, 54, 54, -4, -4
.byte -2, -2, 10, 10, 58, 58, -2, -2, -2, -2, 10, 10, 58, 58, -2, -2
.byte -2, -2, 10, 10, 58, 58, -2, -2, -2, -2, 10, 10, 58, 58, -2, -2
.short 0, 64, 0, 0
.short -2, 58, 10, -2
.short -4, 54, 16, -2
.short -6, 46, 28, -4
.short -4, 36, 36, -4
.short -4, 28, 46, -6
.short -2, 16, 54, -4
.short -2, 10, 58, -2
endconst

const h_psOffset
.short -8192, -8192, -8192, -8192, -8192, -8192, -8192, -8192
.short -8192, -8192, -8192, -8192, -8192, -8192, -8192, -8192
.word 526336, 526336, 526336, 526336, 526336, 526336, 526336, 526336
endconst

.macro PROCESS_LUMA in0, in1, in2, in3, in4, in5, in6, in7, out0,   \
                    tmp0, tmp1, tmp2, tmp3
    vhaddw.w.h   \in0,   \in0,  \in0
    vhaddw.w.h   \in1,   \in1,  \in1
    vhaddw.w.h   \in2,   \in2,  \in2
    vhaddw.w.h   \in3,   \in3,  \in3
    vhaddw.w.h   \in4,   \in4,  \in4
    vhaddw.w.h   \in5,   \in5,  \in5
    vhaddw.w.h   \in6,   \in6,  \in6
    vhaddw.w.h   \in7,   \in7,  \in7
    vpickev.h    \tmp0,  \in1,  \in0
    vpickev.h    \tmp1,  \in3,  \in2
    vpickev.h    \tmp2,  \in5,  \in4
    vpickev.h    \tmp3,  \in7,  \in6
    vhaddw.w.h   \tmp0,  \tmp0, \tmp0
    vhaddw.w.h   \tmp1,  \tmp1, \tmp1
    vhaddw.w.h   \tmp2,  \tmp2, \tmp2
    vhaddw.w.h   \tmp3,  \tmp3, \tmp3
    vpickev.h    \in0,   \tmp1, \tmp0
    vpickev.h    \in1,   \tmp3, \tmp2
    vhaddw.w.h   \in0,   \in0,  \in0
    vhaddw.w.h   \in1,   \in1,  \in1
    vpickev.h    \out0,  \in1,  \in0
.endm

.macro VMULW4_H in0, in1, mul0, mul1, out0, out1, out2, out3
    vmulwev.h.bu.b  \out0, \in0, \mul0
    vmulwod.h.bu.b  \out1, \in0, \mul0
    vmulwev.h.bu.b  \out2, \in1, \mul1
    vmulwod.h.bu.b  \out3, \in1, \mul1
.endm

.macro VMADDW4_H in0, in1, mul0, mul1, out0, out1, out2, out3
    vmaddwev.h.bu.b  \out0, \in0, \mul0
    vmaddwod.h.bu.b  \out1, \in0, \mul0
    vmaddwev.h.bu.b  \out2, \in1, \mul1
    vmaddwod.h.bu.b  \out3, \in1, \mul1
.endm

.macro FILTER_HORIZ_LUMA_4xN  h
function x265_interp_8tap_horiz_pp_4x\h\()_lsx
    slli.d       t7,    a4,    5
    la.local     t6,    g_lumaFilter
    vldx         vr10,  t6,    t7
    addi.d       t0,    zero,  \h/4
.loopH_4x\h:
    fld.d        f0,    a0,    -3
    fld.d        f1,    a0,    -2
    fld.d        f2,    a0,    -1
    fld.d        f3,    a0,    0
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    add.d        a0,    a0,    a1
    VMULW4_H vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    fld.d        f0,    a0,    -3
    fld.d        f1,    a0,    -2
    fld.d        f2,    a0,    -1
    fld.d        f3,    a0,    0
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    add.d        a0,    a0,    a1
    VMULW4_H vr4, vr5, vr10, vr10, vr11, vr12, vr13, vr14

    PROCESS_LUMA vr6, vr7, vr8, vr9, vr11, vr12, vr13, vr14, \
                 vr20, vr15, vr16, vr17, vr18

    fld.d        f0,    a0,    -3
    fld.d        f1,    a0,    -2
    fld.d        f2,    a0,    -1
    fld.d        f3,    a0,    0
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    add.d        a0,    a0,    a1
    VMULW4_H vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    fld.d        f0,    a0,    -3
    fld.d        f1,    a0,    -2
    fld.d        f2,    a0,    -1
    fld.d        f3,    a0,    0
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    add.d        a0,    a0,    a1
    VMULW4_H vr4, vr5, vr10, vr10, vr11, vr12, vr13, vr14

    PROCESS_LUMA vr6, vr7, vr8, vr9, vr11, vr12, vr13, vr14, \
                 vr21, vr15, vr16, vr17, vr18

    vssrarni.bu.h vr21, vr20, 6
    vstelm.w     vr21,  a2,    0,    0
    add.d        a2,    a2,    a3
    vstelm.w     vr21,  a2,    0,    1
    add.d        a2,    a2,    a3
    vstelm.w     vr21,  a2,    0,    2
    add.d        a2,    a2,    a3
    vstelm.w     vr21,  a2,    0,    3
    addi.d       t0,    t0,    -1
    add.d        a2,    a2,    a3
    blt          zero,  t0,    .loopH_4x\h
endfunc
.endm

FILTER_HORIZ_LUMA_4xN  4
FILTER_HORIZ_LUMA_4xN  8
FILTER_HORIZ_LUMA_4xN  16

.macro FILTER_HORIZ_LUMA_8xN  h
function x265_interp_8tap_horiz_pp_8x\h\()_lsx
    slli.d       t7,    a4,    5
    la.local     t6,    g_lumaFilter
    vldx         vr10,  t6,    t7
    addi.d       t0,    zero,  \h/2
.loopH_8x\h:
    fld.d        f0,    a0,    -3
    fld.d        f1,    a0,    -2
    fld.d        f2,    a0,    -1
    fld.d        f3,    a0,    0
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    VMULW4_H vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    fld.d        f0,    a0,    1
    fld.d        f1,    a0,    2
    fld.d        f2,    a0,    3
    fld.d        f3,    a0,    4
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    add.d        a0,    a0,    a1
    VMULW4_H vr4, vr5, vr10, vr10, vr11, vr12, vr13, vr14

    PROCESS_LUMA vr6, vr7, vr8, vr9, vr11, vr12, vr13, vr14, \
                 vr20, vr15, vr16, vr17, vr18

    fld.d        f0,    a0,    -3
    fld.d        f1,    a0,    -2
    fld.d        f2,    a0,    -1
    fld.d        f3,    a0,    0
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    VMULW4_H vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    fld.d        f0,    a0,    1
    fld.d        f1,    a0,    2
    fld.d        f2,    a0,    3
    fld.d        f3,    a0,    4
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    add.d        a0,    a0,    a1
    VMULW4_H vr4, vr5, vr10, vr10, vr11, vr12, vr13, vr14

    PROCESS_LUMA vr6, vr7, vr8, vr9, vr11, vr12, vr13, vr14, \
                 vr21, vr15, vr16, vr17, vr18

    vssrarni.bu.h vr21, vr20, 6
    vstelm.d     vr21,  a2,    0,    0
    add.d        a2,    a2,    a3
    vstelm.d     vr21,  a2,    0,    1
    addi.d       t0,    t0,    -1
    add.d        a2,    a2,    a3
    blt          zero,  t0,    .loopH_8x\h
endfunc
.endm

FILTER_HORIZ_LUMA_8xN 4
FILTER_HORIZ_LUMA_8xN 8
FILTER_HORIZ_LUMA_8xN 16
FILTER_HORIZ_LUMA_8xN 32

function x265_interp_8tap_horiz_pp_12x16_lsx
    slli.d       t7,    a4,    5
    la.local     t6,    g_lumaFilter
    vldx         vr10,  t6,    t7
    addi.d       t0,    zero,  16
.loopH_12x16:
    vld          vr0,   a0,    -3
    vld          vr1,   a0,    -2
    vld          vr2,   a0,    -1
    vld          vr3,   a0,    0
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    vilvh.b      vr19,  vr1,   vr0
    vilvh.b      vr21,  vr3,   vr2
    VMULW4_H vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    fld.d        f0,    a0,    1
    fld.d        f1,    a0,    2
    fld.d        f2,    a0,    3
    fld.d        f3,    a0,    4
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    VMULW4_H vr4, vr5, vr10, vr10, vr11, vr12, vr13, vr14

    PROCESS_LUMA vr6, vr7, vr8, vr9, vr11, vr12, vr13, vr14, \
                 vr20, vr15, vr16, vr17, vr18

    VMULW4_H vr19, vr21, vr10, vr10, vr15, vr16, vr17, vr18

    vhaddw.w.h   vr15,  vr15,  vr15
    vhaddw.w.h   vr16,  vr16,  vr16
    vhaddw.w.h   vr17,  vr17,  vr17
    vhaddw.w.h   vr18,  vr18,  vr18
    vpickev.h    vr0,   vr16,  vr15
    vpickev.h    vr1,   vr18,  vr17
    vhaddw.w.h   vr0,   vr0,   vr0
    vhaddw.w.h   vr1,   vr1,   vr1
    vpickev.h    vr2,   vr1,   vr0
    vhaddw.w.h   vr3,   vr2,   vr2
    vpickev.h    vr5,   vr10,  vr3
    add.d        a0,    a0,    a1

    vssrarni.bu.h vr5, vr20, 6
    vstelm.d     vr5,   a2,    0,    0
    vstelm.w     vr5,   a2,    8,    2
    addi.d       t0,    t0,    -1
    add.d        a2,    a2,    a3
    blt          zero,  t0,    .loopH_12x16
endfunc

function x265_interp_8tap_horiz_pp_24x32_lsx
    slli.d       t7,    a4,    5
    la.local     t6,    g_lumaFilter
    vldx         vr10,  t6,    t7
    addi.d       t0,    zero,  32
.loopH_24x32:
    vld          vr0,   a0,    -3
    vld          vr1,   a0,    -2
    vld          vr2,   a0,    -1
    vld          vr3,   a0,    0
    vld          vr20,  a0,    1
    vld          vr21,  a0,    2
    vld          vr22,  a0,    3
    vld          vr23,  a0,    4
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    vilvl.b      vr16,  vr21,  vr20
    vilvl.b      vr17,  vr23,  vr22

    VMULW4_H vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    VMULW4_H vr16, vr17, vr10, vr10, vr11, vr12, vr13, vr14

    PROCESS_LUMA vr6, vr7, vr8, vr9, vr11, vr12, vr13, vr14, \
                 vr19, vr15, vr16, vr17, vr18

    vilvh.b      vr4,   vr1,    vr0
    vilvh.b      vr5,   vr3,    vr2
    vilvh.b      vr16,  vr21,   vr20
    vilvh.b      vr17,  vr23,   vr22

    VMULW4_H vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    VMULW4_H vr16, vr17, vr10, vr10, vr11, vr12, vr13, vr14

    PROCESS_LUMA vr6, vr7, vr8, vr9, vr11, vr12, vr13, vr14, \
                 vr20, vr15, vr16, vr17, vr18

    vssrarni.bu.h vr20, vr19,  6

    fld.d        f0,    a0,    13
    fld.d        f1,    a0,    14
    fld.d        f2,    a0,    15
    fld.d        f3,    a0,    16
    fld.d        f19,   a0,    17
    fld.d        f21,   a0,    18
    fld.d        f22,   a0,    19
    fld.d        f23,   a0,    20
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    vilvl.b      vr16,  vr21,  vr19
    vilvl.b      vr17,  vr23,  vr22

    VMULW4_H vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    VMULW4_H vr16, vr17, vr10, vr10, vr11, vr12, vr13, vr14

    PROCESS_LUMA vr6, vr7, vr8, vr9, vr11, vr12, vr13, vr14, \
                 vr19, vr15, vr16, vr17, vr18

    vssrarni.bu.h vr21, vr19,  6

    vst          vr20,  a2,    0
    vstelm.d     vr21,  a2,    16,  0
    addi.d       t0,    t0,    -1
    add.d        a0,    a0,    a1
    add.d        a2,    a2,    a3
    blt          zero,  t0,    .loopH_24x32
endfunc

.macro FILTER_HORIZ_LUMA_WxN  w, h, rep
function x265_interp_8tap_horiz_pp_\w\()x\h\()_lsx
    slli.d       t7,    a4,    5
    la.local     t6,    g_lumaFilter
    vldx         vr10,  t6,    t7
    addi.d       t0,    zero,  \h
.loopH_\w\()x\h:
    move         t1,    a0
    move         t2,    a2
.rept \rep
    vld          vr0,   t1,    -3
    vld          vr1,   t1,    -2
    vld          vr2,   t1,    -1
    vld          vr3,   t1,    0
    vld          vr20,  t1,    1
    vld          vr21,  t1,    2
    vld          vr22,  t1,    3
    vld          vr23,  t1,    4
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    vilvl.b      vr16,  vr21,  vr20
    vilvl.b      vr17,  vr23,  vr22

    VMULW4_H vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    VMULW4_H vr16, vr17, vr10, vr10, vr11, vr12, vr13, vr14

    PROCESS_LUMA vr6, vr7, vr8, vr9, vr11, vr12, vr13, vr14, \
                 vr19, vr15, vr16, vr17, vr18

    vilvh.b      vr4,   vr1,   vr0
    vilvh.b      vr5,   vr3,   vr2
    vilvh.b      vr16,  vr21,  vr20
    vilvh.b      vr17,  vr23,  vr22

    VMULW4_H vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    VMULW4_H vr16, vr17, vr10, vr10, vr11, vr12, vr13, vr14

    PROCESS_LUMA vr6, vr7, vr8, vr9, vr11, vr12, vr13, vr14, \
                 vr20, vr15, vr16, vr17, vr18

    addi.d        t1,   t1,    16
    vssrarni.bu.h vr20, vr19,  6
    vst           vr20, t2,    0
    addi.d        t2,   t2,    16
.endr
    addi.d        t0,   t0,    -1
    add.d         a0,   a0,    a1
    add.d         a2,   a2,    a3
    blt           zero, t0,    .loopH_\w\()x\h
endfunc
.endm

FILTER_HORIZ_LUMA_WxN 16, 4,  1
FILTER_HORIZ_LUMA_WxN 16, 8,  1
FILTER_HORIZ_LUMA_WxN 16, 12, 1
FILTER_HORIZ_LUMA_WxN 16, 16, 1
FILTER_HORIZ_LUMA_WxN 16, 32, 1
FILTER_HORIZ_LUMA_WxN 16, 64, 1
FILTER_HORIZ_LUMA_WxN 32, 8,  2
FILTER_HORIZ_LUMA_WxN 32, 16, 2
FILTER_HORIZ_LUMA_WxN 32, 24, 2
FILTER_HORIZ_LUMA_WxN 32, 32, 2
FILTER_HORIZ_LUMA_WxN 32, 64, 2
FILTER_HORIZ_LUMA_WxN 48, 64, 3
FILTER_HORIZ_LUMA_WxN 64, 16, 4
FILTER_HORIZ_LUMA_WxN 64, 32, 4
FILTER_HORIZ_LUMA_WxN 64, 48, 4
FILTER_HORIZ_LUMA_WxN 64, 64, 4

.macro FILTER_HORIZ_PS_4xN  h
function x265_interp_8tap_horiz_ps_4x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       a3,    a3,    1
    la.local     t6,    g_lumaFilter
    la.local     t5,    h_psOffset
    vldx         vr10,  t6,    t7
    vld          vr11,  t5,    0
    addi.d       t0,    zero,  \h/2
    beqz         a5,    .loopS_4x\h
    alsl.d       t1,    a1,    a1,   1
    sub.d        a0,    a0,    t1
    addi.d       t0,    t0,    3

    fld.d        f0,    a0,    -3
    fld.d        f1,    a0,    -2
    fld.d        f2,    a0,    -1
    fld.d        f3,    a0,    0
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    VMULW4_H vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    vhaddw.w.h   vr6,   vr6,   vr6
    vhaddw.w.h   vr7,   vr7,   vr7
    vhaddw.w.h   vr8,   vr8,   vr8
    vhaddw.w.h   vr9,   vr9,   vr9
    vpickev.h    vr12,  vr7,   vr6
    vpickev.h    vr13,  vr9,   vr8
    vhaddw.w.h   vr12,  vr12,  vr12
    vhaddw.w.h   vr13,  vr13,  vr13
    vpickev.h    vr14,  vr13,  vr12
    vhaddw.w.h   vr14,  vr14,  vr14
    vpickev.h    vr20,  vr11,  vr14
    vadd.h       vr21,  vr20,  vr11
    add.d        a0,    a0,    a1
    fst.d        f21,   a2,    0
    add.d        a2,    a2,    a3
.loopS_4x\h:
    fld.d        f0,    a0,    -3
    fld.d        f1,    a0,    -2
    fld.d        f2,    a0,    -1
    fld.d        f3,    a0,    0
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    add.d        a0,    a0,    a1
    VMULW4_H vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    fld.d        f16,   a0,    -3
    fld.d        f17,   a0,    -2
    fld.d        f18,   a0,    -1
    fld.d        f19,   a0,    0
    vilvl.b      vr4,   vr17,  vr16
    vilvl.b      vr5,   vr19,  vr18
    add.d        a0,    a0,    a1
    VMULW4_H vr4, vr5, vr10, vr10, vr12, vr13, vr14, vr15

    PROCESS_LUMA vr6, vr7, vr8, vr9, vr12, vr13, vr14, vr15, \
                 vr20, vr16, vr17, vr18, vr19

    vadd.h       vr21,  vr20,  vr11
    addi.d       t0,    t0,    -1
    vstelm.d     vr21,  a2,    0,    0
    add.d        a2,    a2,    a3
    vstelm.d     vr21,  a2,    0,    1
    add.d        a2,    a2,    a3
    blt          zero,  t0,    .loopS_4x\h
endfunc
.endm

FILTER_HORIZ_PS_4xN  4
FILTER_HORIZ_PS_4xN  8
FILTER_HORIZ_PS_4xN  16

.macro FILTER_HORIZ_PS_8xN  h
function x265_interp_8tap_horiz_ps_8x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       a3,    a3,    1
    la.local     t6,    g_lumaFilter
    la.local     t5,    h_psOffset
    vldx         vr10,  t6,    t7
    vld          vr11,  t5,    0
    addi.d       t0,    zero,  \h/2
    beqz         a5,    .loopS_8x\h
    alsl.d       t1,    a1,    a1,   1
    sub.d        a0,    a0,    t1
    addi.d       t0,    t0,    3

    fld.d        f0,    a0,    -3
    fld.d        f1,    a0,    -2
    fld.d        f2,    a0,    -1
    fld.d        f3,    a0,    0
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    VMULW4_H vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    fld.d        f0,    a0,    1
    fld.d        f1,    a0,    2
    fld.d        f2,    a0,    3
    fld.d        f3,    a0,    4
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    add.d        a0,    a0,    a1
    VMULW4_H vr4, vr5, vr10, vr10, vr12, vr13, vr14, vr15

    PROCESS_LUMA vr6, vr7, vr8, vr9, vr12, vr13, vr14, vr15, \
                 vr20, vr16, vr17, vr18, vr19

    vadd.h       vr21,  vr20,  vr11
    vst          vr21,  a2,    0
    add.d        a2,    a2,    a3
.loopS_8x\h:
    fld.d        f0,    a0,    -3
    fld.d        f1,    a0,    -2
    fld.d        f2,    a0,    -1
    fld.d        f3,    a0,    0
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    VMULW4_H vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    fld.d        f0,    a0,    1
    fld.d        f1,    a0,    2
    fld.d        f2,    a0,    3
    fld.d        f3,    a0,    4
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    add.d        a0,    a0,    a1
    VMULW4_H vr4, vr5, vr10, vr10, vr12, vr13, vr14, vr15

    PROCESS_LUMA vr6, vr7, vr8, vr9, vr12, vr13, vr14, vr15, \
                 vr20, vr16, vr17, vr18, vr19

    fld.d        f0,    a0,    -3
    fld.d        f1,    a0,    -2
    fld.d        f2,    a0,    -1
    fld.d        f3,    a0,    0
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    VMULW4_H vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    fld.d        f0,    a0,    1
    fld.d        f1,    a0,    2
    fld.d        f2,    a0,    3
    fld.d        f3,    a0,    4
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    add.d        a0,    a0,    a1
    VMULW4_H vr4, vr5, vr10, vr10, vr12, vr13, vr14, vr15

    PROCESS_LUMA vr6, vr7, vr8, vr9, vr12, vr13, vr14, vr15, \
                 vr21, vr16, vr17, vr18, vr19

    vadd.h       vr20,  vr20,  vr11
    vadd.h       vr21,  vr21,  vr11
    vst          vr20,  a2,    0
    add.d        a2,    a2,    a3
    vst          vr21,  a2,    0
    addi.d       t0,    t0,    -1
    add.d        a2,    a2,    a3
    blt          zero,  t0,    .loopS_8x\h
endfunc
.endm

FILTER_HORIZ_PS_8xN 4
FILTER_HORIZ_PS_8xN 8
FILTER_HORIZ_PS_8xN 16
FILTER_HORIZ_PS_8xN 32

function x265_interp_8tap_horiz_ps_12x16_lsx
    slli.d       t7,    a4,    5
    slli.d       a3,    a3,    1
    la.local     t6,    g_lumaFilter
    la.local     t5,    h_psOffset
    vldx         vr10,  t6,    t7
    vld          vr11,  t5,    0
    addi.d       t0,    zero,  16
    beqz         a5,    .loopS_12x16
    alsl.d       t1,    a1,    a1,   1
    sub.d        a0,    a0,    t1
    addi.d       t0,    t0,    7
.loopS_12x16:
    vld          vr0,   a0,    -3
    vld          vr1,   a0,    -2
    vld          vr2,   a0,    -1
    vld          vr3,   a0,    0
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    vilvh.b      vr21,  vr1,   vr0
    vilvh.b      vr22,  vr3,   vr2
    VMULW4_H vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    fld.d        f0,    a0,    1
    fld.d        f1,    a0,    2
    fld.d        f2,    a0,    3
    fld.d        f3,    a0,    4
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    VMULW4_H vr4, vr5, vr10, vr10, vr12, vr13, vr14, vr15

    PROCESS_LUMA vr6, vr7, vr8, vr9, vr12, vr13, vr14, vr15, \
                 vr20, vr16, vr17, vr18, vr19
    VMULW4_H vr21, vr22, vr10, vr10, vr15, vr16, vr17, vr18

    vhaddw.w.h   vr15,  vr15,  vr15
    vhaddw.w.h   vr16,  vr16,  vr16
    vhaddw.w.h   vr17,  vr17,  vr17
    vhaddw.w.h   vr18,  vr18,  vr18
    vpickev.h    vr0,   vr16,  vr15
    vpickev.h    vr1,   vr18,  vr17
    vhaddw.w.h   vr0,   vr0,   vr0
    vhaddw.w.h   vr1,   vr1,   vr1
    vpickev.h    vr2,   vr1,   vr0
    vhaddw.w.h   vr3,   vr2,   vr2
    vpickev.h    vr5,   vr10,  vr3
    vadd.h       vr20,  vr20,  vr11
    vadd.h       vr21,  vr5,   vr11

    add.d        a0,    a0,    a1
    vst          vr20,  a2,    0
    fst.d        f21,   a2,    16
    addi.d       t0,    t0,    -1
    add.d        a2,    a2,    a3
    blt          zero,  t0,    .loopS_12x16
endfunc

function x265_interp_8tap_horiz_ps_24x32_lsx
    slli.d       t7,    a4,    5
    slli.d       a3,    a3,    1
    addi.d       sp,    sp,    -16
    la.local     t6,    g_lumaFilter
    la.local     t5,    h_psOffset
    fst.d        f24,   sp,    0
    fst.d        f25,   sp,    8
    vldx         vr10,  t6,    t7
    vld          vr24,  t5,    0
    addi.d       t0,    zero,  32
    beqz         a5,    .loopS_24x32
    alsl.d       t1,    a1,    a1,   1
    sub.d        a0,    a0,    t1
    addi.d       t0,    t0,    7
.loopS_24x32:
    vld          vr0,   a0,    -3
    vld          vr1,   a0,    -2
    vld          vr2,   a0,    -1
    vld          vr3,   a0,    0
    vld          vr20,  a0,    1
    vld          vr21,  a0,    2
    vld          vr22,  a0,    3
    vld          vr23,  a0,    4
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    vilvl.b      vr16,  vr21,  vr20
    vilvl.b      vr17,  vr23,  vr22

    VMULW4_H vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    VMULW4_H vr16, vr17, vr10, vr10, vr11, vr12, vr13, vr14

    PROCESS_LUMA vr6, vr7, vr8, vr9, vr11, vr12, vr13, vr14, \
                 vr25, vr15, vr16, vr17, vr18

    vilvh.b      vr4,   vr1,    vr0
    vilvh.b      vr5,   vr3,    vr2
    vilvh.b      vr16,  vr21,   vr20
    vilvh.b      vr17,  vr23,   vr22

    VMULW4_H vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    VMULW4_H vr16, vr17, vr10, vr10, vr11, vr12, vr13, vr14

    PROCESS_LUMA vr6, vr7, vr8, vr9, vr11, vr12, vr13, vr14, \
                 vr20, vr15, vr16, vr17, vr18

    fld.d        f0,    a0,    13
    fld.d        f1,    a0,    14
    fld.d        f2,    a0,    15
    fld.d        f3,    a0,    16
    fld.d        f19,   a0,    17
    fld.d        f21,   a0,    18
    fld.d        f22,   a0,    19
    fld.d        f23,   a0,    20
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    vilvl.b      vr16,  vr21,  vr19
    vilvl.b      vr17,  vr23,  vr22

    VMULW4_H vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    VMULW4_H vr16, vr17, vr10, vr10, vr11, vr12, vr13, vr14

    PROCESS_LUMA vr6, vr7, vr8, vr9, vr11, vr12, vr13, vr14, \
                 vr19, vr15, vr16, vr17, vr18

    vadd.h       vr0,   vr25,  vr24
    vadd.h       vr1,   vr20,  vr24
    vadd.h       vr2,   vr19,  vr24

    vst          vr0,   a2,    0
    vst          vr1,   a2,    16
    vst          vr2,   a2,    32
    addi.d       t0,    t0,    -1
    add.d        a0,    a0,    a1
    add.d        a2,    a2,    a3
    blt          zero,  t0,    .loopS_24x32
    fld.d        f24,   sp,    0
    fld.d        f25,   sp,    8
    addi.d       sp,    sp,    16
endfunc

.macro FILTER_HORIZ_PS_WxN  w, h, rep
function x265_interp_8tap_horiz_ps_\w\()x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       a3,    a3,    1
    la.local     t6,    g_lumaFilter
    la.local     t5,    h_psOffset
    addi.d       sp,    sp,    -8
    vldx         vr10,  t6,    t7
    vld          vr11,  t5,    0
    addi.d       t0,    zero,  \h
    fst.d        f24,   sp,    0
    beqz         a5,    .loopS_\w\()x\h
    alsl.d       t1,    a1,    a1,   1
    sub.d        a0,    a0,    t1
    addi.d       t0,    t0,    7
.loopS_\w\()x\h:
    move         t1,    a0
    move         t2,    a2
.rept \rep
    vld          vr0,   t1,    -3
    vld          vr1,   t1,    -2
    vld          vr2,   t1,    -1
    vld          vr3,   t1,    0
    vld          vr20,  t1,    1
    vld          vr21,  t1,    2
    vld          vr22,  t1,    3
    vld          vr23,  t1,    4
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    vilvl.b      vr16,  vr21,  vr20
    vilvl.b      vr17,  vr23,  vr22
    VMULW4_H vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    VMULW4_H vr16, vr17, vr10, vr10, vr12, vr13, vr14, vr15

    PROCESS_LUMA vr6, vr7, vr8, vr9, vr12, vr13, vr14, vr15, \
                 vr24, vr16, vr17, vr18, vr19

    vilvh.b      vr4,   vr1,   vr0
    vilvh.b      vr5,   vr3,   vr2
    vilvh.b      vr16,  vr21,  vr20
    vilvh.b      vr17,  vr23,  vr22
    VMULW4_H vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    VMULW4_H vr16, vr17, vr10, vr10, vr12, vr13, vr14, vr15

    PROCESS_LUMA vr6, vr7, vr8, vr9, vr12, vr13, vr14, vr15, \
                 vr21, vr16, vr17, vr18, vr19

    vadd.h       vr0,   vr24,  vr11
    vadd.h       vr1,   vr21,  vr11

    addi.d       t1,    t1,    16
    vst          vr0,   t2,    0
    vst          vr1,   t2,    16
    addi.d       t2,    t2,    32
.endr
    addi.d       t0,    t0,    -1
    add.d        a0,    a0,    a1
    add.d        a2,    a2,    a3
    blt          zero,  t0,    .loopS_\w\()x\h
    fld.d        f24,   sp,    0
    addi.d       sp,    sp,    8
endfunc
.endm

FILTER_HORIZ_PS_WxN 16, 4,  1
FILTER_HORIZ_PS_WxN 16, 8,  1
FILTER_HORIZ_PS_WxN 16, 12, 1
FILTER_HORIZ_PS_WxN 16, 16, 1
FILTER_HORIZ_PS_WxN 16, 32, 1
FILTER_HORIZ_PS_WxN 16, 64, 1
FILTER_HORIZ_PS_WxN 48, 64, 3
FILTER_HORIZ_PS_WxN 32, 8,  2
FILTER_HORIZ_PS_WxN 32, 16, 2
FILTER_HORIZ_PS_WxN 32, 24, 2
FILTER_HORIZ_PS_WxN 32, 32, 2
FILTER_HORIZ_PS_WxN 32, 64, 2
FILTER_HORIZ_PS_WxN 64, 16, 4
FILTER_HORIZ_PS_WxN 64, 32, 4
FILTER_HORIZ_PS_WxN 64, 48, 4
FILTER_HORIZ_PS_WxN 64, 64, 4

function x265_interp_8tap_vert_pp_4x4_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_lumaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride
    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vldrepl.b    vr20,  t5,    8
    vldrepl.b    vr21,  t5,    10
    vldrepl.b    vr22,  t5,    12
    vldrepl.b    vr23,  t5,    14

    add.d        t6,    a0,    t3
    fld.s        f0,    a0,    0    //0
    fldx.s       f1,    a0,    a1   //1
    fldx.s       f2,    a0,    t1   //2
    fldx.s       f3,    a0,    t2   //3

    fld.s        f4,    t6,    0    //4
    fldx.s       f5,    t6,    a1   //5
    fldx.s       f6,    t6,    t1   //6
    fldx.s       f7,    t6,    t2   //7
    add.d        a0,    t6,    t3

    vilvl.b      vr8,   vr1,   vr0  //0, 1
    vilvl.b      vr9,   vr3,   vr2  //2, 3
    vilvl.b      vr10,  vr2,   vr1  //1, 2
    vilvl.b      vr11,  vr4,   vr3  //3, 4
    vilvl.b      vr12,  vr5,   vr4  //4, 5
    vilvl.b      vr13,  vr7,   vr6  //6, 7
    vilvl.b      vr14,  vr6,   vr5  //5, 6

    vilvl.d      vr0,   vr9,   vr8  //0,1,2,3
    vilvl.d      vr1,   vr11,  vr10 //1,2,3,4
    vilvl.d      vr2,   vr12,  vr9  //2,3,4,5
    vilvl.d      vr3,   vr14,  vr11 //3,4,5,6
    vilvl.d      vr4,   vr13,  vr12 //4,5,6,7

    fld.s        f8,    a0,    0    //8
    fldx.s       f9,    a0,    a1   //9
    fldx.s       f10,   a0,    t1   //10

    vilvl.b      vr15,  vr8,   vr7  //7, 8
    vilvl.b      vr11,  vr9,   vr8  //8, 9
    vilvl.b      vr12,  vr10,  vr9  //9, 10

    vilvl.d      vr5,   vr15,  vr14 //5,6,7,8
    vilvl.d      vr6,   vr11,  vr13 //6,7,8,9
    vilvl.d      vr7,   vr12,  vr15 //7,8,9,10

    vmulwev.h.bu.b   vr9,  vr0,  vr16   //0, 2
    vmulwod.h.bu.b   vr10, vr0,  vr16   //1, 3
    VMADDW4_H vr1, vr2, vr17, vr18, vr9 vr10, vr9, vr10
    VMADDW4_H vr3, vr4, vr19, vr20, vr9 vr10, vr9, vr10
    VMADDW4_H vr5, vr6, vr21, vr22, vr9 vr10, vr9, vr10
    vmaddwev.h.bu.b  vr9,  vr7,  vr23
    vmaddwod.h.bu.b  vr10, vr7,  vr23
    vssrarni.bu.h    vr10, vr9,  6
    vstelm.w         vr10, a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.w         vr10, a2,   0,   2
    add.d            a2,   a2,   a3
    vstelm.w         vr10, a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.w         vr10, a2,   0,   3
endfunc

function x265_interp_8tap_vert_pp_4x8_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_lumaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride
    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vldrepl.b    vr20,  t5,    8
    vldrepl.b    vr21,  t5,    10
    vldrepl.b    vr22,  t5,    12
    vldrepl.b    vr23,  t5,    14

    add.d        t6,    a0,    t3
    fld.s        f0,    a0,    0    //0
    fldx.s       f1,    a0,    a1   //1
    fldx.s       f2,    a0,    t1   //2
    fldx.s       f3,    a0,    t2   //3

    fld.s        f4,    t6,    0    //4
    fldx.s       f5,    t6,    a1   //5
    fldx.s       f6,    t6,    t1   //6
    fldx.s       f7,    t6,    t2   //7
    add.d        a0,    t6,    t3

    vilvl.b      vr8,   vr1,   vr0  //0, 1
    vilvl.b      vr9,   vr3,   vr2  //2, 3
    vilvl.b      vr10,  vr2,   vr1  //1, 2
    vilvl.b      vr11,  vr4,   vr3  //3, 4
    vilvl.b      vr12,  vr5,   vr4  //4, 5
    vilvl.b      vr13,  vr7,   vr6  //6, 7
    vilvl.b      vr14,  vr6,   vr5  //5, 6

    vilvl.d      vr0,   vr9,   vr8  //0,1,2,3
    vilvl.d      vr1,   vr11,  vr10 //1,2,3,4
    vilvl.d      vr2,   vr12,  vr9  //2,3,4,5
    vilvl.d      vr3,   vr14,  vr11 //3,4,5,6
    vilvl.d      vr4,   vr13,  vr12 //4,5,6,7

    add.d        t6,    a0,    t3
    fld.s        f8,    a0,    0    //8
    fldx.s       f9,    a0,    a1   //9
    fldx.s       f10,   a0,    t1   //10

    vilvl.b      vr15,  vr8,   vr7  //7, 8
    vilvl.b      vr11,  vr9,   vr8  //8, 9
    vilvl.b      vr12,  vr10,  vr9  //9, 10

    vilvl.d      vr5,   vr15,  vr14 //5,6,7,8
    vilvl.d      vr6,   vr11,  vr13 //6,7,8,9
    vilvl.d      vr7,   vr12,  vr15 //7,8,9,10

    VMULW4_H  vr0, vr4, vr16, vr16, vr8, vr9, vr13, vr14
    VMADDW4_H vr1, vr5, vr17, vr17, vr8, vr9, vr13, vr14
    VMADDW4_H vr2, vr6, vr18, vr18, vr8, vr9, vr13, vr14
    VMADDW4_H vr3, vr7, vr19, vr19, vr8, vr9, vr13, vr14

    fldx.s       f0,    a0,    t2   //11
    fld.s        f1,    t6,    0    //12
    fldx.s       f2,    t6,    a1   //13
    fldx.s       f3,    t6,    t1   //14

    vilvl.b      vr15,  vr0,   vr10  //10, 11
    vilvl.b      vr0,   vr1,   vr0   //11, 12
    vilvl.d      vr11,  vr15,  vr11  //8,9,10,11
    vilvl.d      vr12,  vr0,   vr12  //9,10,11,12

    VMADDW4_H vr4, vr11, vr20, vr20, vr8, vr9, vr13, vr14
    VMADDW4_H vr5, vr12, vr21, vr21, vr8, vr9, vr13, vr14

    vilvl.b      vr4,   vr2,   vr1  //12, 13
    vilvl.b      vr5,   vr3,   vr2  //13, 14
    vilvl.d      vr1,   vr4,   vr15 //10,11,12,13
    vilvl.d      vr2,   vr5,   vr0  //11,12,13,14

    VMADDW4_H vr6, vr1, vr22, vr22, vr8, vr9, vr13, vr14
    VMADDW4_H vr7, vr2, vr23, vr23, vr8, vr9, vr13, vr14

    vssrarni.bu.h    vr9,  vr8,  6
    vssrarni.bu.h    vr14, vr13, 6
    vstelm.w         vr9,  a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.w         vr9,  a2,   0,   2
    add.d            a2,   a2,   a3
    vstelm.w         vr9,  a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.w         vr9,  a2,   0,   3
    add.d            a2,   a2,   a3
    vstelm.w         vr14, a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.w         vr14, a2,   0,   2
    add.d            a2,   a2,   a3
    vstelm.w         vr14, a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.w         vr14, a2,   0,   3
endfunc

function x265_interp_8tap_vert_pp_4x16_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_lumaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride
    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vldrepl.b    vr20,  t5,    8
    vldrepl.b    vr21,  t5,    10
    vldrepl.b    vr22,  t5,    12
    vldrepl.b    vr23,  t5,    14

    add.d        t6,    a0,    t3
    fld.s        f0,    a0,    0    //0
    fldx.s       f1,    a0,    a1   //1
    fldx.s       f2,    a0,    t1   //2
    fldx.s       f3,    a0,    t2   //3

    fld.s        f4,    t6,    0    //4
    fldx.s       f5,    t6,    a1   //5
    fldx.s       f6,    t6,    t1   //6
    fldx.s       f7,    t6,    t2   //7
    add.d        a0,    t6,    t3

    vilvl.b      vr8,   vr1,   vr0  //0, 1
    vilvl.b      vr9,   vr3,   vr2  //2, 3
    vilvl.b      vr10,  vr2,   vr1  //1, 2
    vilvl.b      vr11,  vr4,   vr3  //3, 4
    vilvl.b      vr12,  vr5,   vr4  //4, 5
    vilvl.b      vr13,  vr7,   vr6  //6, 7
    vilvl.b      vr14,  vr6,   vr5  //5, 6

    vilvl.d      vr0,   vr9,   vr8  //0,1,2,3
    vilvl.d      vr1,   vr11,  vr10 //1,2,3,4
    vilvl.d      vr2,   vr12,  vr9  //2,3,4,5
    vilvl.d      vr3,   vr14,  vr11 //3,4,5,6
    vilvl.d      vr4,   vr13,  vr12 //4,5,6,7

    add.d        t6,    a0,    t3
    fld.s        f8,    a0,    0    //8
    fldx.s       f9,    a0,    a1   //9
    fldx.s       f10,   a0,    t1   //10

    vilvl.b      vr15,  vr8,   vr7  //7, 8
    vilvl.b      vr11,  vr9,   vr8  //8, 9
    vilvl.b      vr12,  vr10,  vr9  //9, 10

    vilvl.d      vr5,   vr15,  vr14 //5,6,7,8
    vilvl.d      vr6,   vr11,  vr13 //6,7,8,9
    vilvl.d      vr7,   vr12,  vr15 //7,8,9,10

    VMULW4_H  vr0, vr4, vr16, vr16, vr8, vr9, vr13, vr14
    VMADDW4_H vr1, vr5, vr17, vr17, vr8, vr9, vr13, vr14
    VMADDW4_H vr2, vr6, vr18, vr18, vr8, vr9, vr13, vr14
    VMADDW4_H vr3, vr7, vr19, vr19, vr8, vr9, vr13, vr14

    fldx.s       f0,    a0,    t2   //11
    fld.s        f1,    t6,    0    //12
    fldx.s       f2,    t6,    a1   //13
    fldx.s       f3,    t6,    t1   //14

    add.d        a0,    t6,    t3
    vilvl.b      vr15,  vr0,   vr10  //10, 11
    vilvl.b      vr0,   vr1,   vr0   //11, 12
    vilvl.d      vr11,  vr15,  vr11  //8,9,10,11
    vilvl.d      vr12,  vr0,   vr12  //9,10,11,12

    VMADDW4_H vr4, vr11, vr20, vr20, vr8, vr9, vr13, vr14
    VMADDW4_H vr5, vr12, vr21, vr21, vr8, vr9, vr13, vr14

    vilvl.b      vr4,   vr2,   vr1  //12, 13
    vilvl.b      vr5,   vr3,   vr2  //13, 14
    vilvl.d      vr1,   vr4,   vr15 //10,11,12,13
    vilvl.d      vr2,   vr5,   vr0  //11,12,13,14

    VMADDW4_H vr6, vr1, vr22, vr22, vr8, vr9, vr13, vr14
    VMADDW4_H vr7, vr2, vr23, vr23, vr8, vr9, vr13, vr14

    vssrarni.bu.h    vr9,  vr8,  6
    vssrarni.bu.h    vr14, vr13, 6
    vstelm.w         vr9,  a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.w         vr9,  a2,   0,   2
    add.d            a2,   a2,   a3
    vstelm.w         vr9,  a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.w         vr9,  a2,   0,   3
    add.d            a2,   a2,   a3
    vstelm.w         vr14, a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.w         vr14, a2,   0,   2
    add.d            a2,   a2,   a3
    vstelm.w         vr14, a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.w         vr14, a2,   0,   3
    add.d            a2,   a2,   a3

    fldx.s       f6,    t6,    t2   //15
    fld.s        f7,    a0,    0    //16
    fldx.s       f10,   a0,    a1   //17
    add.d        t6,    a0,    t3
    vilvl.b      vr8,   vr6,   vr3  //14, 15
    vilvl.b      vr9,   vr7,   vr6  //15, 16

    vilvl.d      vr4,   vr8,   vr4  //12,13,14,15
    vilvl.d      vr5,   vr9,   vr5  //13,14,15,16

    VMULW4_H  vr11, vr4, vr16, vr16, vr0, vr3, vr13, vr14
    VMADDW4_H vr12, vr5, vr17, vr17, vr0, vr3, vr13, vr14

    fldx.s       f11,   a0,    t1   //18
    fldx.s       f12,   a0,    t2   //19
    vilvl.b      vr7,   vr10,  vr7  //16, 17
    vilvl.b      vr15,  vr11,  vr10 //17, 18
    vilvl.d      vr8,   vr7,   vr8  //14,15,16,17
    vilvl.d      vr9,   vr15,  vr9  //15,16,17,18

    VMADDW4_H vr1, vr8, vr18, vr18, vr0, vr3, vr13, vr14
    VMADDW4_H vr2, vr9, vr19, vr19, vr0, vr3, vr13, vr14

    fld.s        f1,    t6,    0    //20
    fldx.s       f2,    t6,    a1   //21

    vilvl.b      vr11,  vr12,  vr11 //18,19
    vilvl.b      vr6,   vr1,   vr12 //19,20
    vilvl.d      vr7,   vr11,  vr7  //16,17,18,19
    vilvl.d      vr15,  vr6,   vr15 //17,18,19,20

    VMADDW4_H vr4, vr7, vr20, vr20, vr0, vr3, vr13, vr14
    VMADDW4_H vr5, vr15, vr21, vr21, vr0, vr3, vr13, vr14

    fldx.s       f4,    t6,    t1   //22
    vilvl.b      vr1,   vr2,   vr1  //20, 21
    vilvl.b      vr5,   vr4,   vr2  //21, 22
    vilvl.d      vr11,  vr1,   vr11 //18,19,20,21
    vilvl.d      vr6,   vr5,   vr6  //19,20,21,22

    VMADDW4_H vr8, vr11, vr22, vr22, vr0, vr3, vr13, vr14
    VMADDW4_H vr9, vr6, vr23, vr23, vr0, vr3, vr13, vr14

    vssrarni.bu.h vr3,  vr0,  6
    vssrarni.bu.h vr14, vr13, 6
    vstelm.w         vr3,  a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.w         vr3,  a2,   0,   2
    add.d            a2,   a2,   a3
    vstelm.w         vr3,  a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.w         vr3,  a2,   0,   3
    add.d            a2,   a2,   a3
    vstelm.w         vr14, a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.w         vr14, a2,   0,   2
    add.d            a2,   a2,   a3
    vstelm.w         vr14, a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.w         vr14, a2,   0,   3
endfunc

.macro FILTER_VERT_PP_8xN  h
function x265_interp_8tap_vert_pp_8x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_lumaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    sub.d        t6,    a0,    t2  //src -= 3 * srcStride
    addi.d       t0,    zero,  \h/4
    addi.d       sp,    sp,    -24
    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vldrepl.b    vr20,  t5,    8
    vldrepl.b    vr21,  t5,    10
    vldrepl.b    vr22,  t5,    12
    vldrepl.b    vr23,  t5,    14
    fst.d        f24,   sp,    0
    fst.d        f25,   sp,    8
    fst.d        f26,   sp,    16

    add.d        a0,    t6,    t3
    fld.d        f8,    t6,    0    //0
    fldx.d       f9,    t6,    a1   //1
    fldx.d       f10,   t6,    t1   //2
    fldx.d       f11,   t6,    t2   //3

    fld.d        f12,   a0,    0    //4
    fldx.d       f13,   a0,    a1   //5
    fldx.d       f14,   a0,    t1   //6

    add.d        t6,    a0,    t2
    vilvl.b      vr0,   vr9,   vr8  //0,1
    vilvl.b      vr1,   vr10,  vr9  //1,2
    vilvl.b      vr2,   vr11,  vr10 //2,3
    vilvl.b      vr3,   vr12,  vr11 //3,4
    vilvl.b      vr4,   vr13,  vr12 //4,5
    vilvl.b      vr5,   vr14,  vr13 //5,6
.loopV_8x\h:
    fld.d        f15,   t6,    0    //7
    fldx.d       f24,   t6,    a1   //8
    fldx.d       f25,   t6,    t1   //9
    fldx.d       f26,   t6,    t2   //10
    VMULW4_H vr0, vr2, vr16, vr16, vr10, vr11, vr12, vr13
    vilvl.b      vr6,   vr15,  vr14 //6,7
    vilvl.b      vr7,   vr24,  vr15 //7,8
    vilvl.b      vr8,   vr25,  vr24 //8,9
    vilvl.b      vr9,   vr26,  vr25 //9,10

    VMADDW4_H vr1, vr3, vr17, vr17, vr10, vr11, vr12, vr13
    VMADDW4_H vr2, vr4, vr18, vr18, vr10, vr11, vr12, vr13
    VMADDW4_H vr3, vr5, vr19, vr19, vr10, vr11, vr12, vr13
    VMADDW4_H vr4, vr6, vr20, vr20, vr10, vr11, vr12, vr13
    VMADDW4_H vr5, vr7, vr21, vr21, vr10, vr11, vr12, vr13
    VMADDW4_H vr6, vr8, vr22, vr22, vr10, vr11, vr12, vr13
    VMADDW4_H vr7, vr9, vr23, vr23, vr10, vr11, vr12, vr13

    vor.v            vr0,  vr4,  vr4
    vor.v            vr1,  vr5,  vr5
    vor.v            vr2,  vr6,  vr6
    vor.v            vr3,  vr7,  vr7
    vor.v            vr4,  vr8,  vr8
    vor.v            vr5,  vr9,  vr9
    vor.v            vr14, vr26, vr26
    vssrarni.bu.h    vr11, vr10, 6
    vssrarni.bu.h    vr13, vr12, 6
    vstelm.d         vr11, a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.d         vr11, a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.d         vr13, a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.d         vr13, a2,   0,   1
    add.d            t6,   t6,   t3
    add.d            a2,   a2,   a3
    addi.d           t0,   t0,   -1
    blt              zero, t0,   .loopV_8x\h
    fld.d            f24,  sp,   0
    fld.d            f25,  sp,   8
    fld.d            f26,  sp,   16
    addi.d           sp,   sp,   24
endfunc
.endm

FILTER_VERT_PP_8xN 4
FILTER_VERT_PP_8xN 8
FILTER_VERT_PP_8xN 16
FILTER_VERT_PP_8xN 32

function x265_interp_8tap_vert_pp_12x16_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_lumaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    sub.d        t6,    a0,    t2  //src -= 3 * srcStride
    addi.d       t0,    zero,  8
    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vldrepl.b    vr20,  t5,    8
    vldrepl.b    vr21,  t5,    10
    vldrepl.b    vr22,  t5,    12
    vldrepl.b    vr23,  t5,    14

    add.d        a0,    t6,    t3
    vld          vr0,   t6,    0    //0
    vldx         vr1,   t6,    a1   //1
    vldx         vr2,   t6,    t1   //2
    vldx         vr3,   t6,    t2   //3

    vld          vr4,   a0,    0    //4
    vldx         vr5,   a0,    a1   //5
    vldx         vr6,   a0,    t1   //6
    add.d        t6,    a0,    t2

.loopV_12x16:
    vld          vr7,   t6,    0   //7
    vldx         vr8,   t6,    a1  //8
    VMULW4_H  vr0, vr1, vr16, vr16, vr10, vr11, vr12, vr13
    VMADDW4_H vr1, vr2, vr17, vr17, vr10, vr11, vr12, vr13
    VMADDW4_H vr2, vr3, vr18, vr18, vr10, vr11, vr12, vr13
    VMADDW4_H vr3, vr4, vr19, vr19, vr10, vr11, vr12, vr13
    VMADDW4_H vr4, vr5, vr20, vr20, vr10, vr11, vr12, vr13
    VMADDW4_H vr5, vr6, vr21, vr21, vr10, vr11, vr12, vr13
    VMADDW4_H vr6, vr7, vr22, vr22, vr10, vr11, vr12, vr13
    VMADDW4_H vr7, vr8, vr23, vr23, vr10, vr11, vr12, vr13

    vor.v            vr0,  vr2,  vr2
    vor.v            vr1,  vr3,  vr3
    vor.v            vr2,  vr4,  vr4
    vor.v            vr3,  vr5,  vr5
    vor.v            vr4,  vr6,  vr6
    vor.v            vr5,  vr7,  vr7
    vor.v            vr6,  vr8,  vr8

    vssrarni.bu.h    vr12, vr10, 6
    vssrarni.bu.h    vr13, vr11, 6
    vilvl.b          vr14, vr13, vr12
    vilvh.b          vr15, vr13, vr12
    vstelm.d         vr14, a2,   0,   0
    vstelm.w         vr14, a2,   8,   2
    add.d            a2,   a2,   a3
    vstelm.d         vr15, a2,   0,   0
    vstelm.w         vr15, a2,   8,   2
    add.d            t6,   t6,   t1
    add.d            a2,   a2,   a3
    addi.d           t0,   t0,   -1
    blt              zero, t0,   .loopV_12x16
endfunc

.macro FILTER_VERT_PP_16xN  h
function x265_interp_8tap_vert_pp_16x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_lumaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  \h/2
    sub.d        t6,    a0,    t2  //src -= 3 * srcStride
    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vldrepl.b    vr20,  t5,    8
    vldrepl.b    vr21,  t5,    10
    vldrepl.b    vr22,  t5,    12
    vldrepl.b    vr23,  t5,    14

    add.d        a0,    t6,    t3
    slli.d       t7,    a3,    1
    vld          vr0,   t6,    0    //0
    vldx         vr1,   t6,    a1   //1
    vldx         vr2,   t6,    t1   //2
    vldx         vr3,   t6,    t2   //3

    vld          vr4,   a0,    0    //4
    vldx         vr5,   a0,    a1   //5
    vldx         vr6,   a0,    t1   //6
    add.d        t6,    a0,    t2

.loopV_16x\h:
    vld          vr7,   t6,    0   //7
    vldx         vr8,   t6,    a1  //8
    VMULW4_H  vr0, vr1, vr16, vr16, vr10, vr11, vr12, vr13
    VMADDW4_H vr1, vr2, vr17, vr17, vr10, vr11, vr12, vr13
    VMADDW4_H vr2, vr3, vr18, vr18, vr10, vr11, vr12, vr13
    VMADDW4_H vr3, vr4, vr19, vr19, vr10, vr11, vr12, vr13
    VMADDW4_H vr4, vr5, vr20, vr20, vr10, vr11, vr12, vr13
    VMADDW4_H vr5, vr6, vr21, vr21, vr10, vr11, vr12, vr13
    VMADDW4_H vr6, vr7, vr22, vr22, vr10, vr11, vr12, vr13
    VMADDW4_H vr7, vr8, vr23, vr23, vr10, vr11, vr12, vr13

    vor.v            vr0,  vr2,  vr2
    vor.v            vr1,  vr3,  vr3
    vor.v            vr2,  vr4,  vr4
    vor.v            vr3,  vr5,  vr5
    vor.v            vr4,  vr6,  vr6
    vor.v            vr5,  vr7,  vr7
    vor.v            vr6,  vr8,  vr8

    vssrarni.bu.h    vr12, vr10, 6
    vssrarni.bu.h    vr13, vr11, 6
    vilvl.b          vr14, vr13, vr12
    vilvh.b          vr15, vr13, vr12
    vst              vr14, a2,   0
    vstx             vr15, a2,   a3
    add.d            t6,   t6,   t1
    addi.d           t0,   t0,   -1
    add.d            a2,   a2,   t7
    blt              zero, t0,   .loopV_16x\h
endfunc
.endm

FILTER_VERT_PP_16xN 4
FILTER_VERT_PP_16xN 8
FILTER_VERT_PP_16xN 12
FILTER_VERT_PP_16xN 16
FILTER_VERT_PP_16xN 32
FILTER_VERT_PP_16xN 64

function x265_interp_8tap_vert_pp_24x32_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_lumaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  16
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride
    addi.d       sp,    sp,    -64
    fst.d        f24,   sp,    0
    fst.d        f25,   sp,    8
    fst.d        f26,   sp,    16
    fst.d        f27,   sp,    24
    fst.d        f28,   sp,    32
    fst.d        f29,   sp,    40
    fst.d        f30,   sp,    48
    fst.d        f31,   sp,    56

    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vldrepl.b    vr20,  t5,    8
    vldrepl.b    vr21,  t5,    10
    vldrepl.b    vr22,  t5,    12
    vldrepl.b    vr23,  t5,    14

    addi.d       t6,    a0,    16
    vld          vr0,   a0,    0    //0
    vldx         vr1,   a0,    a1   //1
    vldx         vr2,   a0,    t1   //2
    vldx         vr3,   a0,    t2   //3

    add.d        a0,    a0,    t3
    fld.d        f30,   t6,    0
    fldx.d       f10,   t6,    a1
    fldx.d       f31,   t6,    t1
    fldx.d       f12,   t6,    t2
    addi.d       t6,    a0,    16

    vilvl.b      vr9,   vr10,  vr30  //0,1
    vilvl.b      vr10,  vr31,  vr10  //1,2
    vilvl.b      vr11,  vr12,  vr31  //2,3

    vld          vr4,   a0,    0    //4
    vldx         vr5,   a0,    a1   //5
    vldx         vr6,   a0,    t1   //6

    fld.d        f30,   t6,    0
    fldx.d       f14,   t6,    a1
    fldx.d       f15,   t6,    t1

    vilvl.b      vr12,  vr30,  vr12  //3,4
    vilvl.b      vr13,  vr14,  vr30  //4,5
    vilvl.b      vr14,  vr15,  vr14  //5,6
    add.d        a0,    a0,    t2
.loopV_24x32:
    addi.d       t6,    a0,    16
    vld          vr7,   a0,    0   //7
    vldx         vr8,   a0,    a1  //8
    fld.d        f28,   t6,    0
    fldx.d       f29,   t6,    a1
    vilvl.b      vr30,  vr28,  vr15  //6,7
    vilvl.b      vr31,  vr29,  vr28  //7,8
    vor.v        vr15,  vr29,  vr29
    VMULW4_H  vr0, vr1, vr16, vr16, vr24, vr25, vr26, vr27
    vmulwev.h.bu.b vr28, vr9, vr16
    vmulwod.h.bu.b vr29, vr9, vr16
    VMADDW4_H vr1, vr2, vr17, vr17, vr24, vr25, vr26, vr27
    vmaddwev.h.bu.b vr28, vr10, vr17
    vmaddwod.h.bu.b vr29, vr10, vr17
    VMADDW4_H vr2, vr3, vr18, vr18, vr24, vr25, vr26, vr27
    vmaddwev.h.bu.b vr28, vr11, vr18
    vmaddwod.h.bu.b vr29, vr11, vr18
    VMADDW4_H vr3, vr4, vr19, vr19, vr24, vr25, vr26, vr27
    vmaddwev.h.bu.b vr28, vr12, vr19
    vmaddwod.h.bu.b vr29, vr12, vr19
    VMADDW4_H vr4, vr5, vr20, vr20, vr24, vr25, vr26, vr27
    vmaddwev.h.bu.b vr28, vr13, vr20
    vmaddwod.h.bu.b vr29, vr13, vr20
    VMADDW4_H vr5, vr6, vr21, vr21, vr24, vr25, vr26, vr27
    vmaddwev.h.bu.b vr28, vr14, vr21
    vmaddwod.h.bu.b vr29, vr14, vr21
    VMADDW4_H vr6, vr7, vr22, vr22, vr24, vr25, vr26, vr27
    vmaddwev.h.bu.b vr28, vr30, vr22
    vmaddwod.h.bu.b vr29, vr30, vr22
    VMADDW4_H vr7, vr8, vr23, vr23, vr24, vr25, vr26, vr27
    vmaddwev.h.bu.b vr28, vr31, vr23
    vmaddwod.h.bu.b vr29, vr31, vr23

    vor.v            vr0,  vr2,  vr2
    vor.v            vr1,  vr3,  vr3
    vor.v            vr2,  vr4,  vr4
    vor.v            vr3,  vr5,  vr5
    vor.v            vr4,  vr6,  vr6
    vor.v            vr5,  vr7,  vr7
    vor.v            vr6,  vr8,  vr8

    vssrarni.bu.h    vr26, vr24, 6
    vssrarni.bu.h    vr27, vr25, 6
    vssrarni.bu.h    vr29, vr28, 6

    vor.v            vr9,  vr11, vr11
    vor.v            vr10, vr12, vr12
    vor.v            vr11, vr13, vr13
    vor.v            vr12, vr14, vr14
    vor.v            vr13, vr30, vr30
    vor.v            vr14, vr31, vr31

    vilvl.b          vr24, vr27, vr26
    vilvh.b          vr25, vr27, vr26
    vst              vr24, a2,   0
    vstelm.d         vr29, a2,   16,   0
    add.d            a2,   a2,   a3
    add.d            a0,   a0,   t1
    addi.d           t0,   t0,   -1
    vst              vr25, a2,   0
    vstelm.d         vr29, a2,   16,   1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_24x32
    fld.d        f24,   sp,    0
    fld.d        f25,   sp,    8
    fld.d        f26,   sp,    16
    fld.d        f27,   sp,    24
    fld.d        f28,   sp,    32
    fld.d        f29,   sp,    40
    fld.d        f30,   sp,    48
    fld.d        f31,   sp,    56
    addi.d       sp,    sp,    64
endfunc

.macro FILTER_VERT_PP_32xN  h
function x265_interp_8tap_vert_pp_32x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_lumaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  \h
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride
    addi.d       sp,    sp,    -32
    fst.d        f24,   sp,    0
    fst.d        f25,   sp,    8
    fst.d        f26,   sp,    16
    fst.d        f27,   sp,    24

    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vldrepl.b    vr20,  t5,    8
    vldrepl.b    vr21,  t5,    10
    vldrepl.b    vr22,  t5,    12
    vldrepl.b    vr23,  t5,    14

    addi.d       t6,    a0,    16
    vld          vr0,   a0,    0    //0
    vldx         vr1,   a0,    a1   //1
    vldx         vr2,   a0,    t1   //2
    vldx         vr3,   a0,    t2   //3

    add.d        a0,    a0,    t3
    vld          vr8,   t6,    0
    vldx         vr9,   t6,    a1
    vldx         vr10,  t6,    t1
    vldx         vr11,  t6,    t2
    addi.d       t6,    a0,    16

    vld          vr4,   a0,    0    //4
    vldx         vr5,   a0,    a1   //5
    vldx         vr6,   a0,    t1   //6

    vld          vr12,  t6,    0
    vldx         vr13,  t6,    a1
    vldx         vr14,  t6,    t1
    add.d        a0,    a0,    t2
.loopV_32x\h:
    vld          vr7,   a0,    0   //7
    vld          vr15,  a0,    16  //7
    VMULW4_H  vr0, vr8, vr16, vr16, vr24, vr25, vr26, vr27
    VMADDW4_H vr1, vr9, vr17, vr17, vr24, vr25, vr26, vr27
    VMADDW4_H vr2, vr10, vr18, vr18, vr24, vr25, vr26, vr27
    VMADDW4_H vr3, vr11, vr19, vr19, vr24, vr25, vr26, vr27
    VMADDW4_H vr4, vr12, vr20, vr20, vr24, vr25, vr26, vr27
    VMADDW4_H vr5, vr13, vr21, vr21, vr24, vr25, vr26, vr27
    VMADDW4_H vr6, vr14, vr22, vr22, vr24, vr25, vr26, vr27
    VMADDW4_H vr7, vr15, vr23, vr23, vr24, vr25, vr26, vr27

    vor.v            vr0,  vr1,  vr1
    vor.v            vr1,  vr2,  vr2
    vor.v            vr2,  vr3,  vr3
    vor.v            vr3,  vr4,  vr4
    vor.v            vr4,  vr5,  vr5
    vor.v            vr5,  vr6,  vr6
    vor.v            vr6,  vr7,  vr7

    vssrarni.bu.h    vr26, vr24, 6
    vssrarni.bu.h    vr27, vr25, 6

    vor.v            vr8,  vr9,  vr9
    vor.v            vr9,  vr10, vr10
    vor.v            vr10, vr11, vr11
    vor.v            vr11, vr12, vr12
    vor.v            vr12, vr13, vr13
    vor.v            vr13, vr14, vr14
    vor.v            vr14, vr15, vr15
    vilvl.b          vr24, vr27, vr26
    vilvh.b          vr25, vr27, vr26
    vst              vr24, a2,   0
    vst              vr25, a2,   16
    add.d            a0,   a0,   a1
    addi.d           t0,   t0,   -1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_32x\h
    fld.d        f24,   sp,    0
    fld.d        f25,   sp,    8
    fld.d        f26,   sp,    16
    fld.d        f27,   sp,    24
    addi.d       sp,    sp,    32
endfunc
.endm

FILTER_VERT_PP_32xN 8
FILTER_VERT_PP_32xN 16
FILTER_VERT_PP_32xN 24
FILTER_VERT_PP_32xN 32
FILTER_VERT_PP_32xN 64

function x265_interp_8tap_vert_pp_48x64_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_lumaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  64
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride

    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vldrepl.b    vr20,  t5,    8
    vldrepl.b    vr21,  t5,    10
    vldrepl.b    vr22,  t5,    12
    vldrepl.b    vr23,  t5,    14

    vld          vr0,   a0,    0
    vld          vr1,   a0,    16
    vld          vr2,   a0,    32
.loopV_48x64:
    add.d        t5,    a0,    a1
    VMULW4_H  vr0, vr1, vr16, vr16, vr8, vr9, vr10, vr11
    vmulwev.h.bu.b  vr12,  vr2,  vr16
    vmulwod.h.bu.b  vr13,  vr2,  vr16
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    add.d        t5,    t5,    a1
    vor.v        vr0,   vr4,   vr4
    vor.v        vr1,   vr5,   vr5
    vor.v        vr2,   vr6,   vr6
    VMADDW4_H vr4, vr5, vr17, vr17, vr8, vr9, vr10, vr11
    vmaddwev.h.bu.b vr12, vr6,  vr17
    vmaddwod.h.bu.b vr13, vr6,  vr17
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    add.d        t5,    t5,    a1
    VMADDW4_H vr4, vr5, vr18, vr18, vr8, vr9, vr10, vr11
    vmaddwev.h.bu.b vr12, vr6,  vr18
    vmaddwod.h.bu.b vr13, vr6,  vr18
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    add.d        t5,    t5,    a1
    VMADDW4_H vr4, vr5, vr19, vr19, vr8, vr9, vr10, vr11
    vmaddwev.h.bu.b vr12, vr6,  vr19
    vmaddwod.h.bu.b vr13, vr6,  vr19
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    add.d        t5,    t5,    a1
    VMADDW4_H vr4, vr5, vr20, vr20, vr8, vr9, vr10, vr11
    vmaddwev.h.bu.b vr12, vr6,  vr20
    vmaddwod.h.bu.b vr13, vr6,  vr20
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    add.d        t5,    t5,    a1
    VMADDW4_H vr4, vr5, vr21, vr21, vr8, vr9, vr10, vr11
    vmaddwev.h.bu.b vr12, vr6,  vr21
    vmaddwod.h.bu.b vr13, vr6,  vr21
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    add.d        t5,    t5,    a1
    VMADDW4_H vr4, vr5, vr22, vr22, vr8, vr9, vr10, vr11
    vmaddwev.h.bu.b vr12, vr6,  vr22
    vmaddwod.h.bu.b vr13, vr6,  vr22
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    VMADDW4_H vr4, vr5, vr23, vr23, vr8, vr9, vr10, vr11
    vmaddwev.h.bu.b vr12, vr6,  vr23
    vmaddwod.h.bu.b vr13, vr6,  vr23

    vssrarni.bu.h    vr10, vr8,  6
    vssrarni.bu.h    vr11, vr9,  6
    vssrarni.bu.h    vr14, vr12, 6
    vssrarni.bu.h    vr15, vr13, 6

    vilvl.b          vr8,  vr11, vr10   //0
    vilvh.b          vr9,  vr11, vr10   //16
    vilvl.b          vr12, vr15, vr14   //32

    vst              vr8,  a2,   0
    vst              vr9,  a2,   16
    vst              vr12, a2,   32
    addi.d           t0,   t0,   -1
    add.d            a0,   a0,   a1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_48x64
endfunc

.macro FILTER_VERT_PP_64xN  h
function x265_interp_8tap_vert_pp_64x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_lumaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  \h
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride

    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vldrepl.b    vr20,  t5,    8
    vldrepl.b    vr21,  t5,    10
    vldrepl.b    vr22,  t5,    12
    vldrepl.b    vr23,  t5,    14

    vld          vr0,   a0,    0
    vld          vr1,   a0,    16
    vld          vr2,   a0,    32
    vld          vr3,   a0,    48
.loopV_64x\h:
    add.d        t5,    a0,    a1
    VMULW4_H  vr0, vr1, vr16, vr16, vr8, vr9, vr10, vr11
    VMULW4_H  vr2, vr3, vr16, vr16, vr12, vr13, vr14, vr15
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    vld          vr7,   t5,    48
    add.d        t5,    t5,    a1
    vor.v        vr0,   vr4,   vr4
    vor.v        vr1,   vr5,   vr5
    vor.v        vr2,   vr6,   vr6
    vor.v        vr3,   vr7,   vr7
    VMADDW4_H vr4, vr5, vr17, vr17, vr8, vr9, vr10, vr11
    VMADDW4_H vr6, vr7, vr17, vr17, vr12, vr13, vr14, vr15
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    vld          vr7,   t5,    48
    add.d        t5,    t5,    a1
    VMADDW4_H vr4, vr5, vr18, vr18, vr8, vr9, vr10, vr11
    VMADDW4_H vr6, vr7, vr18, vr18, vr12, vr13, vr14, vr15
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    vld          vr7,   t5,    48
    add.d        t5,    t5,    a1
    VMADDW4_H vr4, vr5, vr19, vr19, vr8, vr9, vr10, vr11
    VMADDW4_H vr6, vr7, vr19, vr19, vr12, vr13, vr14, vr15
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    vld          vr7,   t5,    48
    add.d        t5,    t5,    a1
    VMADDW4_H vr4, vr5, vr20, vr20, vr8, vr9, vr10, vr11
    VMADDW4_H vr6, vr7, vr20, vr20, vr12, vr13, vr14, vr15
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    vld          vr7,   t5,    48
    add.d        t5,    t5,    a1
    VMADDW4_H vr4, vr5, vr21, vr21, vr8, vr9, vr10, vr11
    VMADDW4_H vr6, vr7, vr21, vr21, vr12, vr13, vr14, vr15
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    vld          vr7,   t5,    48
    add.d        t5,    t5,    a1
    VMADDW4_H vr4, vr5, vr22, vr22, vr8, vr9, vr10, vr11
    VMADDW4_H vr6, vr7, vr22, vr22, vr12, vr13, vr14, vr15
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    vld          vr7,   t5,    48
    VMADDW4_H vr4, vr5, vr23, vr23, vr8, vr9, vr10, vr11
    VMADDW4_H vr6, vr7, vr23, vr23, vr12, vr13, vr14, vr15

    vssrarni.bu.h    vr10, vr8,  6
    vssrarni.bu.h    vr11, vr9,  6
    vssrarni.bu.h    vr14, vr12, 6
    vssrarni.bu.h    vr15, vr13, 6

    vilvl.b          vr8,  vr11, vr10   //0
    vilvh.b          vr9,  vr11, vr10   //16
    vilvl.b          vr12, vr15, vr14   //32
    vilvh.b          vr13, vr15, vr14   //48

    vst              vr8,  a2,   0
    vst              vr9,  a2,   16
    vst              vr12, a2,   32
    vst              vr13, a2,   48
    addi.d           t0,   t0,   -1
    add.d            a0,   a0,   a1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_64x\h
endfunc
.endm

FILTER_VERT_PP_64xN 16
FILTER_VERT_PP_64xN 32
FILTER_VERT_PP_64xN 48
FILTER_VERT_PP_64xN 64

.macro XMULW4_H in0, in1, mul0, mul1, out0, out1, out2, out3
    xvmulwev.h.bu.b  \out0, \in0, \mul0
    xvmulwod.h.bu.b  \out1, \in0, \mul0
    xvmulwev.h.bu.b  \out2, \in1, \mul1
    xvmulwod.h.bu.b  \out3, \in1, \mul1
.endm

.macro XMADDW4_H in0, in1, mul0, mul1, out0, out1, out2, out3
    xvmaddwev.h.bu.b  \out0, \in0, \mul0
    xvmaddwod.h.bu.b  \out1, \in0, \mul0
    xvmaddwev.h.bu.b  \out2, \in1, \mul1
    xvmaddwod.h.bu.b  \out3, \in1, \mul1
.endm

.macro FILTER_VERT_PP_16xN_LASX  h
function x265_interp_8tap_vert_pp_16x\h\()_lasx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_lumaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  \h/2
    sub.d        t6,    a0,    t2  //src -= 3 * srcStride
    xvldrepl.b   xr16,  t5,    0
    xvldrepl.b   xr17,  t5,    2
    xvldrepl.b   xr18,  t5,    4
    xvldrepl.b   xr19,  t5,    6
    xvldrepl.b   xr20,  t5,    8
    xvldrepl.b   xr21,  t5,    10
    xvldrepl.b   xr22,  t5,    12
    xvldrepl.b   xr23,  t5,    14

    add.d        a0,    t6,    t3
    slli.d       t7,    a3,    1
    vld          vr0,   t6,    0    //0
    vldx         vr1,   t6,    a1   //1
    vldx         vr2,   t6,    t1   //2
    vldx         vr3,   t6,    t2   //3

    vld          vr4,   a0,    0    //4
    vldx         vr5,   a0,    a1   //5
    vldx         vr6,   a0,    t1   //6
    add.d        t6,    a0,    t2
    xvpermi.q    xr0,   xr1,   0x2  //0, 1
    xvpermi.q    xr1,   xr2,   0x2  //1, 2
    xvpermi.q    xr2,   xr3,   0x2  //2, 3
    xvpermi.q    xr3,   xr4,   0x2  //3, 4
    xvpermi.q    xr4,   xr5,   0x2  //4, 5
    xvpermi.q    xr5,   xr6,   0x2  //5, 6
.lasx_loopV_16x\h:
    vld          vr7,   t6,    0   //7
    vldx         vr8,   t6,    a1  //8
    xvpermi.q    xr6,   xr7,   0x2  //6, 7
    xvpermi.q    xr7,   xr8,   0x2  //7, 8
    xvmulwev.h.bu.b  xr10, xr0, xr16
    xvmulwod.h.bu.b  xr11, xr0, xr16
    XMADDW4_H xr1, xr2, xr17, xr18, xr10, xr11, xr10, xr11
    XMADDW4_H xr3, xr4, xr19, xr20, xr10, xr11, xr10, xr11
    XMADDW4_H xr5, xr6, xr21, xr22, xr10, xr11, xr10, xr11
    xvmaddwev.h.bu.b xr10, xr7, xr23
    xvmaddwod.h.bu.b xr11, xr7, xr23

    xvor.v           xr0,  xr2,  xr2
    xvor.v           xr1,  xr3,  xr3
    xvor.v           xr2,  xr4,  xr4
    xvor.v           xr3,  xr5,  xr5
    xvor.v           xr4,  xr6,  xr6
    xvor.v           xr5,  xr7,  xr7
    xvor.v           xr6,  xr8,  xr8

    xvssrarni.bu.h   xr11, xr10, 6
    xvpermi.d        xr12, xr11, 0xB1
    add.d            t6,   t6,   t1
    xvilvl.b         xr13, xr12, xr11
    addi.d           t0,   t0,   -1
    xvpermi.d        xr14, xr13, 0x4E
    vst              vr13, a2,   0
    vstx             vr14, a2,   a3
    add.d            a2,   a2,   t7
    blt              zero, t0,   .lasx_loopV_16x\h
endfunc
.endm

FILTER_VERT_PP_16xN_LASX  4
FILTER_VERT_PP_16xN_LASX  8
FILTER_VERT_PP_16xN_LASX  12
FILTER_VERT_PP_16xN_LASX  16
FILTER_VERT_PP_16xN_LASX  32
FILTER_VERT_PP_16xN_LASX  64

function x265_interp_8tap_vert_pp_24x32_lasx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_lumaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  16
    sub.d        t6,    a0,    t2  //src -= 3 * srcStride
    xvldrepl.b   xr16,  t5,    0
    xvldrepl.b   xr17,  t5,    2
    xvldrepl.b   xr18,  t5,    4
    xvldrepl.b   xr19,  t5,    6
    xvldrepl.b   xr20,  t5,    8
    xvldrepl.b   xr21,  t5,    10
    xvldrepl.b   xr22,  t5,    12
    xvldrepl.b   xr23,  t5,    14

    add.d        a0,    t6,    t3
    xvld         xr0,   t6,    0    //0
    xvldx        xr1,   t6,    a1   //1
    xvldx        xr2,   t6,    t1   //2
    xvldx        xr3,   t6,    t2   //3

    xvld         xr4,   a0,    0    //4
    xvldx        xr5,   a0,    a1   //5
    xvldx        xr6,   a0,    t1   //6
    add.d        t6,    a0,    t2

.lasx_loopV_24x32:
    xvld         xr7,   t6,    0   //7
    xvldx        xr8,   t6,    a1  //8
    XMULW4_H  xr0, xr1, xr16, xr16, xr10, xr11, xr12, xr13
    XMADDW4_H xr1, xr2, xr17, xr17, xr10, xr11, xr12, xr13
    XMADDW4_H xr2, xr3, xr18, xr18, xr10, xr11, xr12, xr13
    XMADDW4_H xr3, xr4, xr19, xr19, xr10, xr11, xr12, xr13
    XMADDW4_H xr4, xr5, xr20, xr20, xr10, xr11, xr12, xr13
    XMADDW4_H xr5, xr6, xr21, xr21, xr10, xr11, xr12, xr13
    XMADDW4_H xr6, xr7, xr22, xr22, xr10, xr11, xr12, xr13
    XMADDW4_H xr7, xr8, xr23, xr23, xr10, xr11, xr12, xr13

    xvor.v           xr0,  xr2,  xr2
    xvor.v           xr1,  xr3,  xr3
    xvor.v           xr2,  xr4,  xr4
    xvor.v           xr3,  xr5,  xr5
    xvor.v           xr4,  xr6,  xr6
    xvor.v           xr5,  xr7,  xr7
    xvor.v           xr6,  xr8,  xr8

    xvssrarni.bu.h   xr12, xr10, 6
    xvssrarni.bu.h   xr13, xr11, 6
    add.d            t7,   a2,   a3
    xvilvl.b         xr14, xr13, xr12
    xvilvh.b         xr15, xr13, xr12
    vst              vr14, a2,   0
    xvstelm.d        xr14, a2,   16,  2
    vst              vr15, t7,   0
    xvstelm.d        xr15, t7,   16,  2
    add.d            t6,   t6,   t1
    addi.d           t0,   t0,   -1
    add.d            a2,   t7,   a3
    blt              zero, t0,   .lasx_loopV_24x32
endfunc

function x265_interp_8tap_vert_pp_48x64_lasx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_lumaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  32
    addi.d       sp,    sp,    -64
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride
    fst.d        f24,   sp,    0
    fst.d        f25,   sp,    8
    fst.d        f26,   sp,    16
    fst.d        f27,   sp,    24
    fst.d        f28,   sp,    32
    fst.d        f29,   sp,    40
    fst.d        f30,   sp,    48
    fst.d        f31,   sp,    56
    xvldrepl.b   xr16,  t5,    0
    xvldrepl.b   xr17,  t5,    2
    xvldrepl.b   xr18,  t5,    4
    xvldrepl.b   xr19,  t5,    6
    xvldrepl.b   xr20,  t5,    8
    xvldrepl.b   xr21,  t5,    10
    xvldrepl.b   xr22,  t5,    12
    xvldrepl.b   xr23,  t5,    14

    addi.d       t6,    a0,    32
    xvld         xr0,   a0,    0    //0
    xvldx        xr1,   a0,    a1   //1
    xvldx        xr2,   a0,    t1   //2
    xvldx        xr3,   a0,    t2   //3

    add.d        a0,    a0,    t3
    vld          vr9,   t6,    0
    vldx         vr10,  t6,    a1
    vldx         vr11,  t6,    t1
    vldx         vr12,  t6,    t2
    addi.d       t6,    a0,    32

    xvld         xr4,   a0,    0    //4
    xvldx        xr5,   a0,    a1   //5
    xvldx        xr6,   a0,    t1   //6

    vld          vr13,  t6,    0
    vldx         vr14,  t6,    a1
    vldx         vr15,  t6,    t1
    add.d        a0,    a0,    t2
    xvpermi.q    xr9,   xr10,  0x2
    xvpermi.q    xr10,  xr11,  0x2
    xvpermi.q    xr11,  xr12,  0x2
    xvpermi.q    xr12,  xr13,  0x2
    xvpermi.q    xr13,  xr14,  0x2
    xvpermi.q    xr14,  xr15,  0x2
.lasx_loopV_48x64:
    addi.d       t6,    a0,    32
    xvld         xr7,   a0,    0   //7
    xvldx        xr8,   a0,    a1  //8
    vld          vr24,  t6,    0
    vldx         vr25,  t6,    a1
    xvpermi.q    xr15,  xr24,  0x2
    xvpermi.q    xr24,  xr25,  0x2
    XMULW4_H  xr0, xr1, xr16, xr16, xr26, xr27, xr28, xr29
    xvmulwev.h.bu.b  xr30, xr9,  xr16
    xvmulwod.h.bu.b  xr31, xr9,  xr16
    XMADDW4_H xr1, xr2, xr17, xr17, xr26, xr27, xr28, xr29
    xvmaddwev.h.bu.b xr30, xr10, xr17
    xvmaddwod.h.bu.b xr31, xr10, xr17
    XMADDW4_H xr2, xr3, xr18, xr18, xr26, xr27, xr28, xr29
    xvmaddwev.h.bu.b xr30, xr11, xr18
    xvmaddwod.h.bu.b xr31, xr11, xr18
    XMADDW4_H xr3, xr4, xr19, xr19, xr26, xr27, xr28, xr29
    xvmaddwev.h.bu.b xr30, xr12, xr19
    xvmaddwod.h.bu.b xr31, xr12, xr19
    XMADDW4_H xr4, xr5, xr20, xr20, xr26, xr27, xr28, xr29
    xvmaddwev.h.bu.b xr30, xr13, xr20
    xvmaddwod.h.bu.b xr31, xr13, xr20
    XMADDW4_H xr5, xr6, xr21, xr21, xr26, xr27, xr28, xr29
    xvmaddwev.h.bu.b xr30, xr14, xr21
    xvmaddwod.h.bu.b xr31, xr14, xr21
    XMADDW4_H xr6, xr7, xr22, xr22, xr26, xr27, xr28, xr29
    xvmaddwev.h.bu.b xr30, xr15, xr22
    xvmaddwod.h.bu.b xr31, xr15, xr22
    XMADDW4_H xr7, xr8, xr23, xr23, xr26, xr27, xr28, xr29
    xvmaddwev.h.bu.b xr30, xr24, xr23
    xvmaddwod.h.bu.b xr31, xr24, xr23

    xvor.v           xr0,  xr2,  xr2
    xvor.v           xr1,  xr3,  xr3
    xvor.v           xr2,  xr4,  xr4
    xvor.v           xr3,  xr5,  xr5
    xvor.v           xr4,  xr6,  xr6
    xvor.v           xr5,  xr7,  xr7
    xvor.v           xr6,  xr8,  xr8
    xvor.v           xr9,  xr11, xr11
    xvor.v           xr10, xr12, xr12
    xvor.v           xr11, xr13, xr13
    xvor.v           xr12, xr14, xr14
    xvor.v           xr13, xr15, xr15
    xvor.v           xr14, xr24, xr24
    xvor.v           xr15, xr25, xr25

    xvssrarni.bu.h   xr31, xr30, 6
    xvssrarni.bu.h   xr28, xr26, 6
    xvssrarni.bu.h   xr29, xr27, 6
    xvpermi.d        xr30, xr31, 0xB1
    add.d            t7,   a2,   a3
    xvilvl.b         xr26, xr29, xr28
    xvilvh.b         xr27, xr29, xr28
    xvilvl.b         xr7,  xr30, xr31
    xvst             xr26, a2,   0
    vst              vr7,  a2,   32
    xvpermi.d        xr8,  xr7,  0x4E
    add.d            a0,   a0,   t1
    xvst             xr27, t7,   0
    vst              vr8,  t7,   32
    addi.d           t0,   t0,   -1
    add.d            a2,   t7,   a3
    blt              zero, t0,   .lasx_loopV_48x64
    fld.d        f24,   sp,    0
    fld.d        f25,   sp,    8
    fld.d        f26,   sp,    16
    fld.d        f27,   sp,    24
    fld.d        f28,   sp,    32
    fld.d        f29,   sp,    40
    fld.d        f30,   sp,    48
    fld.d        f31,   sp,    56
    addi.d       sp,    sp,    64
endfunc

.macro FILTER_VERT_PP_32xN_LASX  h
function x265_interp_8tap_vert_pp_32x\h\()_lasx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_lumaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  \h/2
    sub.d        t6,    a0,    t2  //src -= 3 * srcStride
    xvldrepl.b   xr16,  t5,    0
    xvldrepl.b   xr17,  t5,    2
    xvldrepl.b   xr18,  t5,    4
    xvldrepl.b   xr19,  t5,    6
    xvldrepl.b   xr20,  t5,    8
    xvldrepl.b   xr21,  t5,    10
    xvldrepl.b   xr22,  t5,    12
    xvldrepl.b   xr23,  t5,    14

    add.d        a0,    t6,    t3
    slli.d       t7,    a3,    1
    xvld         xr0,   t6,    0    //0
    xvldx        xr1,   t6,    a1   //1
    xvldx        xr2,   t6,    t1   //2
    xvldx        xr3,   t6,    t2   //3

    xvld         xr4,   a0,    0    //4
    xvldx        xr5,   a0,    a1   //5
    xvldx        xr6,   a0,    t1   //6
    add.d        t6,    a0,    t2

.lasx_loopV_32x\h:
    xvld         xr7,   t6,    0   //7
    xvldx        xr8,   t6,    a1  //8
    XMULW4_H  xr0, xr1, xr16, xr16, xr10, xr11, xr12, xr13
    XMADDW4_H xr1, xr2, xr17, xr17, xr10, xr11, xr12, xr13
    XMADDW4_H xr2, xr3, xr18, xr18, xr10, xr11, xr12, xr13
    XMADDW4_H xr3, xr4, xr19, xr19, xr10, xr11, xr12, xr13
    XMADDW4_H xr4, xr5, xr20, xr20, xr10, xr11, xr12, xr13
    XMADDW4_H xr5, xr6, xr21, xr21, xr10, xr11, xr12, xr13
    XMADDW4_H xr6, xr7, xr22, xr22, xr10, xr11, xr12, xr13
    XMADDW4_H xr7, xr8, xr23, xr23, xr10, xr11, xr12, xr13

    xvor.v           xr0,  xr2,  xr2
    xvor.v           xr1,  xr3,  xr3
    xvor.v           xr2,  xr4,  xr4
    xvor.v           xr3,  xr5,  xr5
    xvor.v           xr4,  xr6,  xr6
    xvor.v           xr5,  xr7,  xr7
    xvor.v           xr6,  xr8,  xr8

    xvssrarni.bu.h   xr12, xr10, 6
    xvssrarni.bu.h   xr13, xr11, 6
    xvilvl.b         xr14, xr13, xr12
    xvilvh.b         xr15, xr13, xr12
    xvst             xr14, a2,   0
    xvstx            xr15, a2,   a3
    add.d            t6,   t6,   t1
    addi.d           t0,   t0,   -1
    add.d            a2,   a2,   t7
    blt              zero, t0,   .lasx_loopV_32x\h
endfunc
.endm

FILTER_VERT_PP_32xN_LASX 8
FILTER_VERT_PP_32xN_LASX 16
FILTER_VERT_PP_32xN_LASX 24
FILTER_VERT_PP_32xN_LASX 32
FILTER_VERT_PP_32xN_LASX 64

.macro FILTER_VERT_PP_64xN_LASX  h
function x265_interp_8tap_vert_pp_64x\h\()_lasx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_lumaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  \h
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride
    addi.d       sp,    sp,    -32
    fst.d        f24,   sp,    0
    fst.d        f25,   sp,    8
    fst.d        f26,   sp,    16
    fst.d        f27,   sp,    24

    xvldrepl.b   xr16,  t5,    0
    xvldrepl.b   xr17,  t5,    2
    xvldrepl.b   xr18,  t5,    4
    xvldrepl.b   xr19,  t5,    6
    xvldrepl.b   xr20,  t5,    8
    xvldrepl.b   xr21,  t5,    10
    xvldrepl.b   xr22,  t5,    12
    xvldrepl.b   xr23,  t5,    14

    addi.d       t6,    a0,    32
    xvld         xr0,   a0,    0    //0
    xvldx        xr1,   a0,    a1   //1
    xvldx        xr2,   a0,    t1   //2
    xvldx        xr3,   a0,    t2   //3

    add.d        a0,    a0,    t3
    xvld         xr8,   t6,    0
    xvldx        xr9,   t6,    a1
    xvldx        xr10,  t6,    t1
    xvldx        xr11,  t6,    t2
    addi.d       t6,    a0,    32

    xvld         xr4,   a0,    0    //4
    xvldx        xr5,   a0,    a1   //5
    xvldx        xr6,   a0,    t1   //6

    xvld         xr12,  t6,    0
    xvldx        xr13,  t6,    a1
    xvldx        xr14,  t6,    t1
    add.d        a0,    a0,    t2
.lasx_loopV_64x\h:
    xvld         xr7,   a0,    0   //7
    xvld         xr15,  a0,    32  //7
    XMULW4_H  xr0, xr8, xr16, xr16, xr24, xr25, xr26, xr27
    XMADDW4_H xr1, xr9, xr17, xr17, xr24, xr25, xr26, xr27
    XMADDW4_H xr2, xr10, xr18, xr18, xr24, xr25, xr26, xr27
    XMADDW4_H xr3, xr11, xr19, xr19, xr24, xr25, xr26, xr27
    XMADDW4_H xr4, xr12, xr20, xr20, xr24, xr25, xr26, xr27
    XMADDW4_H xr5, xr13, xr21, xr21, xr24, xr25, xr26, xr27
    XMADDW4_H xr6, xr14, xr22, xr22, xr24, xr25, xr26, xr27
    XMADDW4_H xr7, xr15, xr23, xr23, xr24, xr25, xr26, xr27

    xvor.v           xr0,  xr1,  xr1
    xvor.v           xr1,  xr2,  xr2
    xvor.v           xr2,  xr3,  xr3
    xvor.v           xr3,  xr4,  xr4
    xvor.v           xr4,  xr5,  xr5
    xvor.v           xr5,  xr6,  xr6
    xvor.v           xr6,  xr7,  xr7

    xvssrarni.bu.h   xr26, xr24, 6
    xvssrarni.bu.h   xr27, xr25, 6

    xvor.v           xr8,  xr9,  xr9
    xvor.v           xr9,  xr10, xr10
    xvor.v           xr10, xr11, xr11
    xvor.v           xr11, xr12, xr12
    xvor.v           xr12, xr13, xr13
    xvor.v           xr13, xr14, xr14
    xvor.v           xr14, xr15, xr15

    xvilvl.b         xr24, xr27, xr26
    xvilvh.b         xr25, xr27, xr26
    xvst             xr24, a2,   0
    xvst             xr25, a2,   32
    add.d            a0,   a0,   a1
    addi.d           t0,   t0,   -1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .lasx_loopV_64x\h
    fld.d        f24,   sp,    0
    fld.d        f25,   sp,    8
    fld.d        f26,   sp,    16
    fld.d        f27,   sp,    24
    addi.d       sp,    sp,    32
endfunc
.endm

FILTER_VERT_PP_64xN_LASX 16
FILTER_VERT_PP_64xN_LASX 32
FILTER_VERT_PP_64xN_LASX 48
FILTER_VERT_PP_64xN_LASX 64

function x265_interp_8tap_vert_ps_4x4_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    slli.d       a3,    a3,    1
    la.local     t6,    g_lumaFilter
    la.local     t4,    h_psOffset
    addi.d       sp,    sp,    -8
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride
    fst.d        f24,   sp,    0
    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vldrepl.b    vr20,  t5,    8
    vldrepl.b    vr21,  t5,    10
    vldrepl.b    vr22,  t5,    12
    vldrepl.b    vr23,  t5,    14
    vld          vr24,  t4,    0

    add.d        t6,    a0,    t3
    fld.s        f0,    a0,    0    //0
    fldx.s       f1,    a0,    a1   //1
    fldx.s       f2,    a0,    t1   //2
    fldx.s       f3,    a0,    t2   //3

    fld.s        f4,    t6,    0    //4
    fldx.s       f5,    t6,    a1   //5
    fldx.s       f6,    t6,    t1   //6
    fldx.s       f7,    t6,    t2   //7
    add.d        a0,    t6,    t3

    vilvl.b      vr8,   vr1,   vr0  //0, 1
    vilvl.b      vr9,   vr3,   vr2  //2, 3
    vilvl.b      vr10,  vr2,   vr1  //1, 2
    vilvl.b      vr11,  vr4,   vr3  //3, 4
    vilvl.b      vr12,  vr5,   vr4  //4, 5
    vilvl.b      vr13,  vr7,   vr6  //6, 7
    vilvl.b      vr14,  vr6,   vr5  //5, 6

    vilvl.d      vr0,   vr9,   vr8  //0,1,2,3
    vilvl.d      vr1,   vr11,  vr10 //1,2,3,4
    vilvl.d      vr2,   vr12,  vr9  //2,3,4,5
    vilvl.d      vr3,   vr14,  vr11 //3,4,5,6
    vilvl.d      vr4,   vr13,  vr12 //4,5,6,7

    fld.s        f8,    a0,    0    //8
    fldx.s       f9,    a0,    a1   //9
    fldx.s       f10,   a0,    t1   //10

    vilvl.b      vr15,  vr8,   vr7  //7, 8
    vilvl.b      vr11,  vr9,   vr8  //8, 9
    vilvl.b      vr12,  vr10,  vr9  //9, 10

    vilvl.d      vr5,   vr15,  vr14 //5,6,7,8
    vilvl.d      vr6,   vr11,  vr13 //6,7,8,9
    vilvl.d      vr7,   vr12,  vr15 //7,8,9,10

    vor.v        vr9,   vr24,  vr24
    vor.v        vr10,  vr24,  vr24
    VMADDW4_H vr0, vr1, vr16, vr17, vr9, vr10, vr9, vr10
    VMADDW4_H vr2, vr3, vr18, vr19, vr9, vr10, vr9, vr10
    VMADDW4_H vr4, vr5, vr20, vr21, vr9, vr10, vr9, vr10
    VMADDW4_H vr6, vr7, vr22, vr23, vr9, vr10, vr9, vr10
    vstelm.d         vr9,  a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.d         vr10, a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.d         vr9,  a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.d         vr10, a2,   0,   1
    fld.d            f24,  sp,   0
    addi.d           sp,   sp,   8
endfunc

function x265_interp_8tap_vert_ps_4x8_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    slli.d       a3,    a3,    1
    la.local     t6,    g_lumaFilter
    la.local     t4,    h_psOffset
    addi.d       sp,    sp,    -8
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride
    fst.d        f24,   sp,    0
    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vldrepl.b    vr20,  t5,    8
    vldrepl.b    vr21,  t5,    10
    vldrepl.b    vr22,  t5,    12
    vldrepl.b    vr23,  t5,    14
    vld          vr24,  t4,    0

    add.d        t6,    a0,    t3
    fld.s        f0,    a0,    0    //0
    fldx.s       f1,    a0,    a1   //1
    fldx.s       f2,    a0,    t1   //2
    fldx.s       f3,    a0,    t2   //3

    fld.s        f4,    t6,    0    //4
    fldx.s       f5,    t6,    a1   //5
    fldx.s       f6,    t6,    t1   //6
    fldx.s       f7,    t6,    t2   //7
    add.d        a0,    t6,    t3

    vilvl.b      vr8,   vr1,   vr0  //0, 1
    vilvl.b      vr9,   vr3,   vr2  //2, 3
    vilvl.b      vr10,  vr2,   vr1  //1, 2
    vilvl.b      vr11,  vr4,   vr3  //3, 4
    vilvl.b      vr12,  vr5,   vr4  //4, 5
    vilvl.b      vr13,  vr7,   vr6  //6, 7
    vilvl.b      vr14,  vr6,   vr5  //5, 6

    vilvl.d      vr0,   vr9,   vr8  //0,1,2,3
    vilvl.d      vr1,   vr11,  vr10 //1,2,3,4
    vilvl.d      vr2,   vr12,  vr9  //2,3,4,5
    vilvl.d      vr3,   vr14,  vr11 //3,4,5,6
    vilvl.d      vr4,   vr13,  vr12 //4,5,6,7

    add.d        t6,    a0,    t3
    fld.s        f8,    a0,    0    //8
    fldx.s       f9,    a0,    a1   //9
    fldx.s       f10,   a0,    t1   //10

    vilvl.b      vr15,  vr8,   vr7  //7, 8
    vilvl.b      vr11,  vr9,   vr8  //8, 9
    vilvl.b      vr12,  vr10,  vr9  //9, 10

    vilvl.d      vr5,   vr15,  vr14 //5,6,7,8
    vilvl.d      vr6,   vr11,  vr13 //6,7,8,9
    vilvl.d      vr7,   vr12,  vr15 //7,8,9,10

.irp x, vr8, vr9, vr13, vr14
    vor.v        \x,    vr24,  vr24
.endr
    VMADDW4_H vr0, vr4, vr16, vr16, vr8, vr9, vr13, vr14
    VMADDW4_H vr1, vr5, vr17, vr17, vr8, vr9, vr13, vr14
    VMADDW4_H vr2, vr6, vr18, vr18, vr8, vr9, vr13, vr14
    VMADDW4_H vr3, vr7, vr19, vr19, vr8, vr9, vr13, vr14

    fldx.s       f0,    a0,    t2   //11
    fld.s        f1,    t6,    0    //12
    fldx.s       f2,    t6,    a1   //13
    fldx.s       f3,    t6,    t1   //14

    vilvl.b      vr15,  vr0,   vr10  //10, 11
    vilvl.b      vr0,   vr1,   vr0   //11, 12
    vilvl.d      vr11,  vr15,  vr11  //8,9,10,11
    vilvl.d      vr12,  vr0,   vr12  //9,10,11,12

    VMADDW4_H vr4, vr11, vr20, vr20, vr8, vr9, vr13, vr14
    VMADDW4_H vr5, vr12, vr21, vr21, vr8, vr9, vr13, vr14

    vilvl.b      vr4,   vr2,   vr1  //12, 13
    vilvl.b      vr5,   vr3,   vr2  //13, 14
    vilvl.d      vr1,   vr4,   vr15 //10,11,12,13
    vilvl.d      vr2,   vr5,   vr0  //11,12,13,14

    VMADDW4_H vr6, vr1, vr22, vr22, vr8, vr9, vr13, vr14
    VMADDW4_H vr7, vr2, vr23, vr23, vr8, vr9, vr13, vr14

    vstelm.d         vr8,  a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.d         vr9,  a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.d         vr8,  a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.d         vr9,  a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.d         vr13, a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.d         vr14, a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.d         vr13, a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.d         vr14, a2,   0,   1
    fld.d            f24,  sp,   0
    addi.d           sp,   sp,   8
endfunc

function x265_interp_8tap_vert_ps_4x16_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    slli.d       a3,    a3,    1
    la.local     t6,    g_lumaFilter
    la.local     t4,    h_psOffset
    addi.d       sp,    sp,    -8
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride
    fst.d        f24,   sp,    0
    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vldrepl.b    vr20,  t5,    8
    vldrepl.b    vr21,  t5,    10
    vldrepl.b    vr22,  t5,    12
    vldrepl.b    vr23,  t5,    14
    vld          vr24,  t4,    0

    add.d        t6,    a0,    t3
    fld.s        f0,    a0,    0    //0
    fldx.s       f1,    a0,    a1   //1
    fldx.s       f2,    a0,    t1   //2
    fldx.s       f3,    a0,    t2   //3

    fld.s        f4,    t6,    0    //4
    fldx.s       f5,    t6,    a1   //5
    fldx.s       f6,    t6,    t1   //6
    fldx.s       f7,    t6,    t2   //7
    add.d        a0,    t6,    t3

    vilvl.b      vr8,   vr1,   vr0  //0, 1
    vilvl.b      vr9,   vr3,   vr2  //2, 3
    vilvl.b      vr10,  vr2,   vr1  //1, 2
    vilvl.b      vr11,  vr4,   vr3  //3, 4
    vilvl.b      vr12,  vr5,   vr4  //4, 5
    vilvl.b      vr13,  vr7,   vr6  //6, 7
    vilvl.b      vr14,  vr6,   vr5  //5, 6

    vilvl.d      vr0,   vr9,   vr8  //0,1,2,3
    vilvl.d      vr1,   vr11,  vr10 //1,2,3,4
    vilvl.d      vr2,   vr12,  vr9  //2,3,4,5
    vilvl.d      vr3,   vr14,  vr11 //3,4,5,6
    vilvl.d      vr4,   vr13,  vr12 //4,5,6,7

    add.d        t6,    a0,    t3
    fld.s        f8,    a0,    0    //8
    fldx.s       f9,    a0,    a1   //9
    fldx.s       f10,   a0,    t1   //10

    vilvl.b      vr15,  vr8,   vr7  //7, 8
    vilvl.b      vr11,  vr9,   vr8  //8, 9
    vilvl.b      vr12,  vr10,  vr9  //9, 10

    vilvl.d      vr5,   vr15,  vr14 //5,6,7,8
    vilvl.d      vr6,   vr11,  vr13 //6,7,8,9
    vilvl.d      vr7,   vr12,  vr15 //7,8,9,10

.irp x, vr8, vr9, vr13, vr14
    vor.v        \x,    vr24,  vr24
.endr
    VMADDW4_H vr0, vr4, vr16, vr16, vr8, vr9, vr13, vr14
    VMADDW4_H vr1, vr5, vr17, vr17, vr8, vr9, vr13, vr14
    VMADDW4_H vr2, vr6, vr18, vr18, vr8, vr9, vr13, vr14
    VMADDW4_H vr3, vr7, vr19, vr19, vr8, vr9, vr13, vr14

    fldx.s       f0,    a0,    t2   //11
    fld.s        f1,    t6,    0    //12
    fldx.s       f2,    t6,    a1   //13
    fldx.s       f3,    t6,    t1   //14

    add.d        a0,    t6,    t3
    vilvl.b      vr15,  vr0,   vr10  //10, 11
    vilvl.b      vr0,   vr1,   vr0   //11, 12
    vilvl.d      vr11,  vr15,  vr11  //8,9,10,11
    vilvl.d      vr12,  vr0,   vr12  //9,10,11,12

    VMADDW4_H vr4, vr11, vr20, vr20, vr8, vr9, vr13, vr14
    VMADDW4_H vr5, vr12, vr21, vr21, vr8, vr9, vr13, vr14

    vilvl.b      vr4,   vr2,   vr1  //12, 13
    vilvl.b      vr5,   vr3,   vr2  //13, 14
    vilvl.d      vr1,   vr4,   vr15 //10,11,12,13
    vilvl.d      vr2,   vr5,   vr0  //11,12,13,14

    VMADDW4_H vr6, vr1, vr22, vr22, vr8, vr9, vr13, vr14
    VMADDW4_H vr7, vr2, vr23, vr23, vr8, vr9, vr13, vr14

    vstelm.d         vr8,  a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.d         vr9,  a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.d         vr8,  a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.d         vr9,  a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.d         vr13, a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.d         vr14, a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.d         vr13, a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.d         vr14, a2,   0,   1
    add.d            a2,   a2,   a3

    fldx.s       f6,    t6,    t2   //15
    fld.s        f7,    a0,    0    //16
    fldx.s       f10,   a0,    a1   //17
    add.d        t6,    a0,    t3
    vilvl.b      vr8,   vr6,   vr3  //14, 15
    vilvl.b      vr9,   vr7,   vr6  //15, 16

    vilvl.d      vr4,   vr8,   vr4  //12,13,14,15
    vilvl.d      vr5,   vr9,   vr5  //13,14,15,16

.irp x, vr0, vr3, vr13, vr14
    vor.v        \x,    vr24,  vr24
.endr
    VMADDW4_H vr11, vr4, vr16, vr16, vr0, vr3, vr13, vr14
    VMADDW4_H vr12, vr5, vr17, vr17, vr0, vr3, vr13, vr14

    fldx.s       f11,   a0,    t1   //18
    fldx.s       f12,   a0,    t2   //19
    vilvl.b      vr7,   vr10,  vr7  //16, 17
    vilvl.b      vr15,  vr11,  vr10 //17, 18
    vilvl.d      vr8,   vr7,   vr8  //14,15,16,17
    vilvl.d      vr9,   vr15,  vr9  //15,16,17,18

    VMADDW4_H vr1, vr8, vr18, vr18, vr0, vr3, vr13, vr14
    VMADDW4_H vr2, vr9, vr19, vr19, vr0, vr3, vr13, vr14

    fld.s        f1,    t6,    0    //20
    fldx.s       f2,    t6,    a1   //21

    vilvl.b      vr11,  vr12,  vr11 //18,19
    vilvl.b      vr6,   vr1,   vr12 //19,20
    vilvl.d      vr7,   vr11,  vr7  //16,17,18,19
    vilvl.d      vr15,  vr6,   vr15 //17,18,19,20

    VMADDW4_H vr4, vr7, vr20, vr20, vr0, vr3, vr13, vr14
    VMADDW4_H vr5, vr15, vr21, vr21, vr0, vr3, vr13, vr14

    fldx.s       f4,    t6,    t1   //22
    vilvl.b      vr1,   vr2,   vr1  //20, 21
    vilvl.b      vr5,   vr4,   vr2  //21, 22
    vilvl.d      vr11,  vr1,   vr11 //18,19,20,21
    vilvl.d      vr6,   vr5,   vr6  //19,20,21,22

    VMADDW4_H vr8, vr11, vr22, vr22, vr0, vr3, vr13, vr14
    VMADDW4_H vr9, vr6, vr23, vr23, vr0, vr3, vr13, vr14

    vstelm.d         vr0,  a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.d         vr3,  a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.d         vr0,  a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.d         vr3,  a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.d         vr13, a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.d         vr14, a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.d         vr13, a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.d         vr14, a2,   0,   1
    fld.d            f24,  sp,   0
    addi.d           sp,   sp,   8
endfunc

.macro FILTER_VERT_PS_8xN  h
function x265_interp_8tap_vert_ps_8x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    slli.d       a3,    a3,    1
    la.local     t6,    g_lumaFilter
    la.local     t4,    h_psOffset
    addi.d       sp,    sp,    -32
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    sub.d        t6,    a0,    t2  //src -= 3 * srcStride
    addi.d       t0,    zero,  \h/4
    fst.d        f24,   sp,    0
    fst.d        f25,   sp,    8
    fst.d        f26,   sp,    16
    fst.d        f27,   sp,    24
    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vldrepl.b    vr20,  t5,    8
    vldrepl.b    vr21,  t5,    10
    vldrepl.b    vr22,  t5,    12
    vldrepl.b    vr23,  t5,    14
    vld          vr27,  t4,    0

    add.d        a0,    t6,    t3
    fld.d        f8,    t6,    0    //0
    fldx.d       f9,    t6,    a1   //1
    fldx.d       f10,   t6,    t1   //2
    fldx.d       f11,   t6,    t2   //3

    fld.d        f12,   a0,    0    //4
    fldx.d       f13,   a0,    a1   //5
    fldx.d       f14,   a0,    t1   //6

    add.d        t6,    a0,    t2
    vilvl.b      vr0,   vr9,   vr8  //0,1
    vilvl.b      vr1,   vr10,  vr9  //1,2
    vilvl.b      vr2,   vr11,  vr10 //2,3
    vilvl.b      vr3,   vr12,  vr11 //3,4
    vilvl.b      vr4,   vr13,  vr12 //4,5
    vilvl.b      vr5,   vr14,  vr13 //5,6
.loopV_ps_8x\h:
.irp x, vr10, vr11, vr12, vr13
    vor.v        \x,    vr27,  vr27
.endr
    fld.d        f15,   t6,    0    //7
    fldx.d       f24,   t6,    a1   //8
    fldx.d       f25,   t6,    t1   //9
    fldx.d       f26,   t6,    t2   //10
    VMADDW4_H vr0, vr2, vr16, vr16, vr10, vr11, vr12, vr13
    vilvl.b      vr6,   vr15,  vr14 //6,7
    vilvl.b      vr7,   vr24,  vr15 //7,8
    vilvl.b      vr8,   vr25,  vr24 //8,9
    vilvl.b      vr9,   vr26,  vr25 //9,10

    VMADDW4_H vr1, vr3, vr17, vr17, vr10, vr11, vr12, vr13
    VMADDW4_H vr2, vr4, vr18, vr18, vr10, vr11, vr12, vr13
    VMADDW4_H vr3, vr5, vr19, vr19, vr10, vr11, vr12, vr13
    VMADDW4_H vr4, vr6, vr20, vr20, vr10, vr11, vr12, vr13
    VMADDW4_H vr5, vr7, vr21, vr21, vr10, vr11, vr12, vr13
    VMADDW4_H vr6, vr8, vr22, vr22, vr10, vr11, vr12, vr13
    VMADDW4_H vr7, vr9, vr23, vr23, vr10, vr11, vr12, vr13

    vor.v            vr0,  vr4,  vr4
    vor.v            vr1,  vr5,  vr5
    vor.v            vr2,  vr6,  vr6
    vor.v            vr3,  vr7,  vr7
    vor.v            vr4,  vr8,  vr8
    vor.v            vr5,  vr9,  vr9
    vor.v            vr14, vr26, vr26
    vst              vr10, a2,   0
    add.d            a2,   a2,   a3
    vst              vr11, a2,   0
    add.d            a2,   a2,   a3
    vst              vr12, a2,   0
    add.d            a2,   a2,   a3
    vst              vr13, a2,   0
    add.d            t6,   t6,   t3
    add.d            a2,   a2,   a3
    addi.d           t0,   t0,   -1
    blt              zero, t0,   .loopV_ps_8x\h
    fld.d            f24,  sp,   0
    fld.d            f25,  sp,   8
    fld.d            f26,  sp,   16
    fld.d            f27,  sp,   24
    addi.d           sp,   sp,   32
endfunc
.endm

FILTER_VERT_PS_8xN 4
FILTER_VERT_PS_8xN 8
FILTER_VERT_PS_8xN 16
FILTER_VERT_PS_8xN 32

function x265_interp_8tap_vert_ps_12x16_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    slli.d       a3,    a3,    1
    la.local     t6,    g_lumaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    sub.d        t6,    a0,    t2  //src -= 3 * srcStride
    addi.d       t0,    zero,  8
    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vldrepl.b    vr20,  t5,    8
    vldrepl.b    vr21,  t5,    10
    vldrepl.b    vr22,  t5,    12
    vldrepl.b    vr23,  t5,    14
    vld          vr15,  t4,    0

    add.d        a0,    t6,    t3
    vld          vr0,   t6,    0    //0
    vldx         vr1,   t6,    a1   //1
    vldx         vr2,   t6,    t1   //2
    vldx         vr3,   t6,    t2   //3

    vld          vr4,   a0,    0    //4
    vldx         vr5,   a0,    a1   //5
    vldx         vr6,   a0,    t1   //6
    add.d        t6,    a0,    t2

.loopV_ps_12x16:
    vld          vr7,   t6,    0   //7
    vldx         vr8,   t6,    a1  //8
.irp x, vr10, vr11, vr12, vr13
    vor.v        \x,    vr15,  vr15
.endr
    VMADDW4_H vr0, vr1, vr16, vr16, vr10, vr11, vr12, vr13
    VMADDW4_H vr1, vr2, vr17, vr17, vr10, vr11, vr12, vr13
    VMADDW4_H vr2, vr3, vr18, vr18, vr10, vr11, vr12, vr13
    VMADDW4_H vr3, vr4, vr19, vr19, vr10, vr11, vr12, vr13
    VMADDW4_H vr4, vr5, vr20, vr20, vr10, vr11, vr12, vr13
    VMADDW4_H vr5, vr6, vr21, vr21, vr10, vr11, vr12, vr13
    VMADDW4_H vr6, vr7, vr22, vr22, vr10, vr11, vr12, vr13
    VMADDW4_H vr7, vr8, vr23, vr23, vr10, vr11, vr12, vr13

    vor.v            vr0,  vr2,  vr2
    vor.v            vr1,  vr3,  vr3
    vor.v            vr2,  vr4,  vr4
    vor.v            vr3,  vr5,  vr5
    vor.v            vr4,  vr6,  vr6
    vor.v            vr5,  vr7,  vr7
    vor.v            vr6,  vr8,  vr8

    vilvl.h          vr9,  vr11, vr10  //0,1,2,3,4,5,6,7
    vilvh.h          vr14, vr11, vr10  //8,9,10,11
    vilvl.h          vr10, vr13, vr12
    vilvh.h          vr11, vr13, vr12

    vst              vr9,  a2,   0
    vstelm.d         vr14, a2,   16,  0
    add.d            a2,   a2,   a3
    vst              vr10, a2,   0
    vstelm.d         vr11, a2,   16,  0
    add.d            t6,   t6,   t1
    add.d            a2,   a2,   a3
    addi.d           t0,   t0,   -1
    blt              zero, t0,   .loopV_ps_12x16
endfunc

.macro FILTER_VERT_PS_16xN  h
function x265_interp_8tap_vert_ps_16x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    slli.d       a3,    a3,    1
    la.local     t6,    g_lumaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  \h/2
    sub.d        t6,    a0,    t2  //src -= 3 * srcStride
    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vldrepl.b    vr20,  t5,    8
    vldrepl.b    vr21,  t5,    10
    vldrepl.b    vr22,  t5,    12
    vldrepl.b    vr23,  t5,    14
    vld          vr15,  t4,    0

    add.d        a0,    t6,    t3
    vld          vr0,   t6,    0    //0
    vldx         vr1,   t6,    a1   //1
    vldx         vr2,   t6,    t1   //2
    vldx         vr3,   t6,    t2   //3

    vld          vr4,   a0,    0    //4
    vldx         vr5,   a0,    a1   //5
    vldx         vr6,   a0,    t1   //6
    add.d        t6,    a0,    t2

.loopV_ps_16x\h:
    vld          vr7,   t6,    0   //7
    vldx         vr8,   t6,    a1  //8
.irp x, vr10, vr11, vr12, vr13
    vor.v        \x,    vr15,  vr15
.endr
    VMADDW4_H vr0, vr1, vr16, vr16, vr10, vr11, vr12, vr13
    VMADDW4_H vr1, vr2, vr17, vr17, vr10, vr11, vr12, vr13
    VMADDW4_H vr2, vr3, vr18, vr18, vr10, vr11, vr12, vr13
    VMADDW4_H vr3, vr4, vr19, vr19, vr10, vr11, vr12, vr13
    VMADDW4_H vr4, vr5, vr20, vr20, vr10, vr11, vr12, vr13
    VMADDW4_H vr5, vr6, vr21, vr21, vr10, vr11, vr12, vr13
    VMADDW4_H vr6, vr7, vr22, vr22, vr10, vr11, vr12, vr13
    VMADDW4_H vr7, vr8, vr23, vr23, vr10, vr11, vr12, vr13

    vor.v            vr0,  vr2,  vr2
    vor.v            vr1,  vr3,  vr3
    vor.v            vr2,  vr4,  vr4
    vor.v            vr3,  vr5,  vr5
    vor.v            vr4,  vr6,  vr6
    vor.v            vr5,  vr7,  vr7
    vor.v            vr6,  vr8,  vr8

    vilvl.h          vr9,  vr11, vr10
    vilvh.h          vr14, vr11, vr10
    vilvl.h          vr7,  vr13, vr12
    vilvh.h          vr8,  vr13, vr12
    vst              vr9,  a2,   0
    vst              vr14, a2,   16
    add.d            a2,   a2,   a3
    vst              vr7,  a2,   0
    vst              vr8,  a2,   16
    add.d            t6,   t6,   t1
    addi.d           t0,   t0,   -1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_ps_16x\h
endfunc
.endm

FILTER_VERT_PS_16xN 4
FILTER_VERT_PS_16xN 8
FILTER_VERT_PS_16xN 16
FILTER_VERT_PS_16xN 12
FILTER_VERT_PS_16xN 32
FILTER_VERT_PS_16xN 64

function x265_interp_8tap_vert_ps_24x32_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    slli.d       a3,    a3,    1
    la.local     t6,    g_lumaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  16
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride
    addi.d       sp,    sp,    -64
    fst.d        f24,   sp,    0
    fst.d        f25,   sp,    8
    fst.d        f26,   sp,    16
    fst.d        f27,   sp,    24
    fst.d        f28,   sp,    32
    fst.d        f29,   sp,    40
    fst.d        f30,   sp,    48
    fst.d        f31,   sp,    56

    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vldrepl.b    vr20,  t5,    8
    vldrepl.b    vr21,  t5,    10
    vldrepl.b    vr22,  t5,    12
    vldrepl.b    vr23,  t5,    14

    addi.d       t6,    a0,    16
    vld          vr0,   a0,    0    //0
    vldx         vr1,   a0,    a1   //1
    vldx         vr2,   a0,    t1   //2
    vldx         vr3,   a0,    t2   //3

    add.d        a0,    a0,    t3
    fld.d        f30,   t6,    0
    fldx.d       f10,   t6,    a1
    fldx.d       f31,   t6,    t1
    fldx.d       f12,   t6,    t2
    addi.d       t6,    a0,    16

    vilvl.b      vr9,   vr10,  vr30  //0,1
    vilvl.b      vr10,  vr31,  vr10  //1,2
    vilvl.b      vr11,  vr12,  vr31  //2,3

    vld          vr4,   a0,    0    //4
    vldx         vr5,   a0,    a1   //5
    vldx         vr6,   a0,    t1   //6

    fld.d        f30,   t6,    0
    fldx.d       f14,   t6,    a1
    fldx.d       f15,   t6,    t1

    vilvl.b      vr12,  vr30,  vr12  //3,4
    vilvl.b      vr13,  vr14,  vr30  //4,5
    vilvl.b      vr14,  vr15,  vr14  //5,6
    add.d        a0,    a0,    t2
.loopV_ps_24x32:
    addi.d       t6,    a0,    16
    vld          vr7,   a0,    0   //7
    vldx         vr8,   a0,    a1  //8
    fld.d        f28,   t6,    0
    fldx.d       f29,   t6,    a1
    vld          vr24,  t4,    0
    vilvl.b      vr30,  vr28,  vr15  //6,7
    vilvl.b      vr31,  vr29,  vr28  //7,8
    vor.v        vr15,  vr29,  vr29
    vor.v        vr25,  vr24,  vr24
    vor.v        vr26,  vr24,  vr24
    vor.v        vr27,  vr24,  vr24
    vor.v        vr28,  vr24,  vr24
    vor.v        vr29,  vr24,  vr24

    VMADDW4_H vr0, vr1, vr16, vr16, vr24, vr25, vr26, vr27
    vmaddwev.h.bu.b vr28, vr9, vr16
    vmaddwod.h.bu.b vr29, vr9, vr16
    VMADDW4_H vr1, vr2, vr17, vr17, vr24, vr25, vr26, vr27
    vmaddwev.h.bu.b vr28, vr10, vr17
    vmaddwod.h.bu.b vr29, vr10, vr17
    VMADDW4_H vr2, vr3, vr18, vr18, vr24, vr25, vr26, vr27
    vmaddwev.h.bu.b vr28, vr11, vr18
    vmaddwod.h.bu.b vr29, vr11, vr18
    VMADDW4_H vr3, vr4, vr19, vr19, vr24, vr25, vr26, vr27
    vmaddwev.h.bu.b vr28, vr12, vr19
    vmaddwod.h.bu.b vr29, vr12, vr19
    VMADDW4_H vr4, vr5, vr20, vr20, vr24, vr25, vr26, vr27
    vmaddwev.h.bu.b vr28, vr13, vr20
    vmaddwod.h.bu.b vr29, vr13, vr20
    VMADDW4_H vr5, vr6, vr21, vr21, vr24, vr25, vr26, vr27
    vmaddwev.h.bu.b vr28, vr14, vr21
    vmaddwod.h.bu.b vr29, vr14, vr21
    VMADDW4_H vr6, vr7, vr22, vr22, vr24, vr25, vr26, vr27
    vmaddwev.h.bu.b vr28, vr30, vr22
    vmaddwod.h.bu.b vr29, vr30, vr22
    VMADDW4_H vr7, vr8, vr23, vr23, vr24, vr25, vr26, vr27
    vmaddwev.h.bu.b vr28, vr31, vr23
    vmaddwod.h.bu.b vr29, vr31, vr23

    vor.v            vr0,  vr2,  vr2
    vor.v            vr1,  vr3,  vr3
    vor.v            vr2,  vr4,  vr4
    vor.v            vr3,  vr5,  vr5
    vor.v            vr4,  vr6,  vr6
    vor.v            vr5,  vr7,  vr7
    vor.v            vr6,  vr8,  vr8

    vor.v            vr9,  vr11, vr11
    vor.v            vr10, vr12, vr12
    vor.v            vr11, vr13, vr13
    vor.v            vr12, vr14, vr14
    vor.v            vr13, vr15, vr15
    vor.v            vr13, vr30, vr30
    vor.v            vr14, vr31, vr31

    vilvl.h          vr7,  vr25, vr24
    vilvh.h          vr8,  vr25, vr24
    vilvl.h          vr30, vr27, vr26
    vilvh.h          vr31, vr27, vr26

    vst              vr7,  a2,   0
    vst              vr8,  a2,   16
    vst              vr28, a2,   32
    add.d            a2,   a2,   a3
    add.d            a0,   a0,   t1
    addi.d           t0,   t0,   -1
    vst              vr30, a2,   0
    vst              vr31, a2,   16
    vst              vr29, a2,   32
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_ps_24x32
    fld.d        f24,   sp,    0
    fld.d        f25,   sp,    8
    fld.d        f26,   sp,    16
    fld.d        f27,   sp,    24
    fld.d        f28,   sp,    32
    fld.d        f29,   sp,    40
    fld.d        f30,   sp,    48
    fld.d        f31,   sp,    56
    addi.d       sp,    sp,    64
endfunc

.macro FILTER_VERT_PS_32xN  h
function x265_interp_8tap_vert_ps_32x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    slli.d       a3,    a3,    1
    la.local     t6,    g_lumaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  \h
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride
    addi.d       sp,    sp,    -40
    fst.d        f24,   sp,    0
    fst.d        f25,   sp,    8
    fst.d        f26,   sp,    16
    fst.d        f27,   sp,    24
    fst.d        f28,   sp,    32

    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vldrepl.b    vr20,  t5,    8
    vldrepl.b    vr21,  t5,    10
    vldrepl.b    vr22,  t5,    12
    vldrepl.b    vr23,  t5,    14
    vld          vr28,  t4,    0

    addi.d       t6,    a0,    16
    vld          vr0,   a0,    0    //0
    vldx         vr1,   a0,    a1   //1
    vldx         vr2,   a0,    t1   //2
    vldx         vr3,   a0,    t2   //3

    add.d        a0,    a0,    t3
    vld          vr8,   t6,    0
    vldx         vr9,   t6,    a1
    vldx         vr10,  t6,    t1
    vldx         vr11,  t6,    t2
    addi.d       t6,    a0,    16

    vld          vr4,   a0,    0    //4
    vldx         vr5,   a0,    a1   //5
    vldx         vr6,   a0,    t1   //6

    vld          vr12,  t6,    0
    vldx         vr13,  t6,    a1
    vldx         vr14,  t6,    t1
    add.d        a0,    a0,    t2
.loopV_ps_32x\h:
    vld          vr7,   a0,    0   //7
    vld          vr15,  a0,    16  //7
.irp x, vr24, vr25, vr26, vr27
    vor.v        \x,    vr28,  vr28
.endr
    VMADDW4_H vr0, vr8, vr16, vr16, vr24, vr25, vr26, vr27
    VMADDW4_H vr1, vr9, vr17, vr17, vr24, vr25, vr26, vr27
    VMADDW4_H vr2, vr10, vr18, vr18, vr24, vr25, vr26, vr27
    VMADDW4_H vr3, vr11, vr19, vr19, vr24, vr25, vr26, vr27
    VMADDW4_H vr4, vr12, vr20, vr20, vr24, vr25, vr26, vr27
    VMADDW4_H vr5, vr13, vr21, vr21, vr24, vr25, vr26, vr27
    VMADDW4_H vr6, vr14, vr22, vr22, vr24, vr25, vr26, vr27
    VMADDW4_H vr7, vr15, vr23, vr23, vr24, vr25, vr26, vr27

    vor.v            vr0,  vr1,  vr1
    vor.v            vr1,  vr2,  vr2
    vor.v            vr2,  vr3,  vr3
    vor.v            vr3,  vr4,  vr4
    vor.v            vr4,  vr5,  vr5
    vor.v            vr5,  vr6,  vr6
    vor.v            vr6,  vr7,  vr7

    vor.v            vr8,  vr9,  vr9
    vor.v            vr9,  vr10, vr10
    vor.v            vr10, vr11, vr11
    vor.v            vr11, vr12, vr12
    vor.v            vr12, vr13, vr13
    vor.v            vr13, vr14, vr14
    vor.v            vr14, vr15, vr15

    vilvl.h          vr7,  vr25, vr24
    vilvh.h          vr24, vr25, vr24
    vilvl.h          vr15, vr27, vr26
    vilvh.h          vr26, vr27, vr26
    vst              vr7,  a2,   0
    vst              vr24, a2,   16
    vst              vr15, a2,   32
    vst              vr26, a2,   48
    add.d            a0,   a0,   a1
    addi.d           t0,   t0,   -1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_ps_32x\h
    fld.d        f24,   sp,    0
    fld.d        f25,   sp,    8
    fld.d        f26,   sp,    16
    fld.d        f27,   sp,    24
    fld.d        f28,   sp,    32
    addi.d       sp,    sp,    40
endfunc
.endm

FILTER_VERT_PS_32xN 8
FILTER_VERT_PS_32xN 16
FILTER_VERT_PS_32xN 24
FILTER_VERT_PS_32xN 32
FILTER_VERT_PS_32xN 64

function x265_interp_8tap_vert_ps_48x64_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    slli.d       a3,    a3,    1
    la.local     t6,    g_lumaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  64
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride

    vld          vr15,  t4,    0
    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vldrepl.b    vr20,  t5,    8
    vldrepl.b    vr21,  t5,    10
    vldrepl.b    vr22,  t5,    12
    vldrepl.b    vr23,  t5,    14

    vld          vr0,   a0,    0
    vld          vr1,   a0,    16
    vld          vr2,   a0,    32
.loopV_ps_48x64:
    add.d        t5,    a0,    a1
    vor.v        vr8,   vr15,  vr15
    vor.v        vr9,   vr15,  vr15
    vor.v        vr10,  vr15,  vr15
    vor.v        vr11,  vr15,  vr15
    vor.v        vr12,  vr15,  vr15
    vor.v        vr13,  vr15,  vr15
    VMADDW4_H vr0, vr1, vr16, vr16, vr8, vr9, vr10, vr11
    vmaddwev.h.bu.b  vr12,  vr2,  vr16
    vmaddwod.h.bu.b  vr13,  vr2,  vr16
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    add.d        t5,    t5,    a1
    vor.v        vr0,   vr4,   vr4
    vor.v        vr1,   vr5,   vr5
    vor.v        vr2,   vr6,   vr6
    VMADDW4_H vr4, vr5, vr17, vr17, vr8, vr9, vr10, vr11
    vmaddwev.h.bu.b vr12, vr6,  vr17
    vmaddwod.h.bu.b vr13, vr6,  vr17
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    add.d        t5,    t5,    a1
    VMADDW4_H vr4, vr5, vr18, vr18, vr8, vr9, vr10, vr11
    vmaddwev.h.bu.b vr12, vr6,  vr18
    vmaddwod.h.bu.b vr13, vr6,  vr18
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    add.d        t5,    t5,    a1
    VMADDW4_H vr4, vr5, vr19, vr19, vr8, vr9, vr10, vr11
    vmaddwev.h.bu.b vr12, vr6,  vr19
    vmaddwod.h.bu.b vr13, vr6,  vr19
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    add.d        t5,    t5,    a1
    VMADDW4_H vr4, vr5, vr20, vr20, vr8, vr9, vr10, vr11
    vmaddwev.h.bu.b vr12, vr6,  vr20
    vmaddwod.h.bu.b vr13, vr6,  vr20
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    add.d        t5,    t5,    a1
    VMADDW4_H vr4, vr5, vr21, vr21, vr8, vr9, vr10, vr11
    vmaddwev.h.bu.b vr12, vr6,  vr21
    vmaddwod.h.bu.b vr13, vr6,  vr21
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    add.d        t5,    t5,    a1
    VMADDW4_H vr4, vr5, vr22, vr22, vr8, vr9, vr10, vr11
    vmaddwev.h.bu.b vr12, vr6,  vr22
    vmaddwod.h.bu.b vr13, vr6,  vr22
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    VMADDW4_H vr4, vr5, vr23, vr23, vr8, vr9, vr10, vr11
    vmaddwev.h.bu.b vr12, vr6,  vr23
    vmaddwod.h.bu.b vr13, vr6,  vr23

    vilvl.h          vr4,  vr9,  vr8
    vilvh.h          vr5,  vr9,  vr8
    vilvl.h          vr6,  vr11, vr10
    vilvh.h          vr7,  vr11, vr10
    vilvl.h          vr8,  vr13, vr12
    vilvh.h          vr9,  vr13, vr12

    vst              vr4,  a2,   0
    vst              vr5,  a2,   16
    vst              vr6,  a2,   32
    vst              vr7,  a2,   48
    vst              vr8,  a2,   64
    vst              vr9,  a2,   80
    addi.d           t0,   t0,   -1
    add.d            a0,   a0,   a1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_ps_48x64
endfunc

.macro FILTER_VERT_PS_64xN  h
function x265_interp_8tap_vert_ps_64x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    slli.d       a3,    a3,    1
    la.local     t6,    g_lumaFilter
    la.local     t4,    h_psOffset
    addi.d       sp,    sp,    -8
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  \h
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride
    fst.d        f24,   sp,    0

    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vldrepl.b    vr20,  t5,    8
    vldrepl.b    vr21,  t5,    10
    vldrepl.b    vr22,  t5,    12
    vldrepl.b    vr23,  t5,    14
    vld          vr24,  t4,    0

    vld          vr0,   a0,    0
    vld          vr1,   a0,    16
    vld          vr2,   a0,    32
    vld          vr3,   a0,    48
.loopV_ps_64x\h:
    add.d        t5,    a0,    a1
.irp x, vr8, vr9, vr10, vr11, vr12, vr13, vr14, vr15
    vor.v        \x,    vr24,  vr24
.endr
    VMADDW4_H vr0, vr1, vr16, vr16, vr8, vr9, vr10, vr11
    VMADDW4_H vr2, vr3, vr16, vr16, vr12, vr13, vr14, vr15
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    vld          vr7,   t5,    48
    add.d        t5,    t5,    a1
    vor.v        vr0,   vr4,   vr4
    vor.v        vr1,   vr5,   vr5
    vor.v        vr2,   vr6,   vr6
    vor.v        vr3,   vr7,   vr7
    VMADDW4_H vr4, vr5, vr17, vr17, vr8, vr9, vr10, vr11
    VMADDW4_H vr6, vr7, vr17, vr17, vr12, vr13, vr14, vr15
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    vld          vr7,   t5,    48
    add.d        t5,    t5,    a1
    VMADDW4_H vr4, vr5, vr18, vr18, vr8, vr9, vr10, vr11
    VMADDW4_H vr6, vr7, vr18, vr18, vr12, vr13, vr14, vr15
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    vld          vr7,   t5,    48
    add.d        t5,    t5,    a1
    VMADDW4_H vr4, vr5, vr19, vr19, vr8, vr9, vr10, vr11
    VMADDW4_H vr6, vr7, vr19, vr19, vr12, vr13, vr14, vr15
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    vld          vr7,   t5,    48
    add.d        t5,    t5,    a1
    VMADDW4_H vr4, vr5, vr20, vr20, vr8, vr9, vr10, vr11
    VMADDW4_H vr6, vr7, vr20, vr20, vr12, vr13, vr14, vr15
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    vld          vr7,   t5,    48
    add.d        t5,    t5,    a1
    VMADDW4_H vr4, vr5, vr21, vr21, vr8, vr9, vr10, vr11
    VMADDW4_H vr6, vr7, vr21, vr21, vr12, vr13, vr14, vr15
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    vld          vr7,   t5,    48
    add.d        t5,    t5,    a1
    VMADDW4_H vr4, vr5, vr22, vr22, vr8, vr9, vr10, vr11
    VMADDW4_H vr6, vr7, vr22, vr22, vr12, vr13, vr14, vr15
    vld          vr4,   t5,    0
    vld          vr5,   t5,    16
    vld          vr6,   t5,    32
    vld          vr7,   t5,    48
    VMADDW4_H vr4, vr5, vr23, vr23, vr8, vr9, vr10, vr11
    VMADDW4_H vr6, vr7, vr23, vr23, vr12, vr13, vr14, vr15

    vilvl.h          vr4,  vr9,  vr8
    vilvh.h          vr5,  vr9,  vr8
    vilvl.h          vr6,  vr11, vr10
    vilvh.h          vr7,  vr11, vr10
    vilvl.h          vr8,  vr13, vr12
    vilvh.h          vr9,  vr13, vr12
    vilvl.h          vr10, vr15, vr14
    vilvh.h          vr11, vr15, vr14
    vst              vr4,  a2,   0
    vst              vr5,  a2,   16
    vst              vr6,  a2,   32
    vst              vr7,  a2,   48
    vst              vr8,  a2,   64
    vst              vr9,  a2,   80
    vst              vr10, a2,   96
    vst              vr11, a2,   112
    addi.d           t0,   t0,   -1
    add.d            a0,   a0,   a1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_ps_64x\h
    fld.d            f24,  sp,   0
    addi.d           sp,   sp,   8
endfunc
.endm

FILTER_VERT_PS_64xN 16
FILTER_VERT_PS_64xN 32
FILTER_VERT_PS_64xN 48
FILTER_VERT_PS_64xN 64

.macro FILTER_VERT_PS_16xN_LASX  h
function x265_interp_8tap_vert_ps_16x\h\()_lasx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    slli.d       a3,    a3,    1
    la.local     t6,    g_lumaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  \h/2
    sub.d        t6,    a0,    t2  //src -= 3 * srcStride
    xvldrepl.b   xr16,  t5,    0
    xvldrepl.b   xr17,  t5,    2
    xvldrepl.b   xr18,  t5,    4
    xvldrepl.b   xr19,  t5,    6
    xvldrepl.b   xr20,  t5,    8
    xvldrepl.b   xr21,  t5,    10
    xvldrepl.b   xr22,  t5,    12
    xvldrepl.b   xr23,  t5,    14
    xvld         xr15,  t4,    0

    slli.d       t7,    a3,    1
    add.d        a0,    t6,    t3
    vld          vr0,   t6,    0    //0
    vldx         vr1,   t6,    a1   //1
    vldx         vr2,   t6,    t1   //2
    vldx         vr3,   t6,    t2   //3

    vld          vr4,   a0,    0    //4
    vldx         vr5,   a0,    a1   //5
    vldx         vr6,   a0,    t1   //6
    add.d        t6,    a0,    t2
    xvpermi.q    xr0,   xr1,   2
    xvpermi.q    xr1,   xr2,   2
    xvpermi.q    xr2,   xr3,   2
    xvpermi.q    xr3,   xr4,   2
    xvpermi.q    xr4,   xr5,   2
    xvpermi.q    xr5,   xr6,   2
.lasx_loopV_ps_16x\h:
    vld          vr7,   t6,    0   //7
    vldx         vr8,   t6,    a1  //8
    xvpermi.q    xr6,   xr7,   2
    xvpermi.q    xr7,   xr8,   2
    xvor.v       xr10,  xr15,  xr15
    xvor.v       xr11,  xr15,  xr15
    XMADDW4_H xr0, xr1, xr16, xr17, xr10, xr11, xr10, xr11
    XMADDW4_H xr2, xr3, xr18, xr19, xr10, xr11, xr10, xr11
    XMADDW4_H xr4, xr5, xr20, xr21, xr10, xr11, xr10, xr11
    XMADDW4_H xr6, xr7, xr22, xr23, xr10, xr11, xr10, xr11

    xvor.v           xr0,  xr2,  xr2
    xvor.v           xr1,  xr3,  xr3
    xvor.v           xr2,  xr4,  xr4
    xvor.v           xr3,  xr5,  xr5
    xvor.v           xr4,  xr6,  xr6
    xvor.v           xr5,  xr7,  xr7
    xvor.v           xr6,  xr8,  xr8

    xvilvl.h         xr12, xr11, xr10
    xvilvh.h         xr13, xr11, xr10
    xvor.v           xr9,  xr12, xr12
    xvpermi.q        xr12, xr13, 0x2
    xvpermi.q        xr9,  xr13, 0x13

    xvst             xr12, a2,   0
    xvstx            xr9,  a2,   a3
    addi.d           t0,   t0,   -1
    add.d            t6,   t6,   t1
    add.d            a2,   a2,   t7
    blt              zero, t0,   .lasx_loopV_ps_16x\h
endfunc
.endm

FILTER_VERT_PS_16xN_LASX  4
FILTER_VERT_PS_16xN_LASX  8
FILTER_VERT_PS_16xN_LASX  12
FILTER_VERT_PS_16xN_LASX  16
FILTER_VERT_PS_16xN_LASX  32
FILTER_VERT_PS_16xN_LASX  64

function x265_interp_8tap_vert_ps_24x32_lasx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    slli.d       a3,    a3,    1
    la.local     t6,    g_lumaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  16
    sub.d        t6,    a0,    t2  //src -= 3 * srcStride
    xvldrepl.b   xr16,  t5,    0
    xvldrepl.b   xr17,  t5,    2
    xvldrepl.b   xr18,  t5,    4
    xvldrepl.b   xr19,  t5,    6
    xvldrepl.b   xr20,  t5,    8
    xvldrepl.b   xr21,  t5,    10
    xvldrepl.b   xr22,  t5,    12
    xvldrepl.b   xr23,  t5,    14
    xvld         xr15,  t4,    0

    add.d        a0,    t6,    t3
    xvld         xr0,   t6,    0    //0
    xvldx        xr1,   t6,    a1   //1
    xvldx        xr2,   t6,    t1   //2
    xvldx        xr3,   t6,    t2   //3

    xvld         xr4,   a0,    0    //4
    xvldx        xr5,   a0,    a1   //5
    xvldx        xr6,   a0,    t1   //6
    add.d        t6,    a0,    t2

.lasx_loopV_ps_24x32:
    xvld         xr7,   t6,    0   //7
    xvldx        xr8,   t6,    a1  //8
.irp x, xr10, xr11, xr12, xr13
    xvor.v       \x,    xr15,  xr15
.endr
    XMADDW4_H xr0, xr1, xr16, xr16, xr10, xr11, xr12, xr13
    XMADDW4_H xr1, xr2, xr17, xr17, xr10, xr11, xr12, xr13
    XMADDW4_H xr2, xr3, xr18, xr18, xr10, xr11, xr12, xr13
    XMADDW4_H xr3, xr4, xr19, xr19, xr10, xr11, xr12, xr13
    XMADDW4_H xr4, xr5, xr20, xr20, xr10, xr11, xr12, xr13
    XMADDW4_H xr5, xr6, xr21, xr21, xr10, xr11, xr12, xr13
    XMADDW4_H xr6, xr7, xr22, xr22, xr10, xr11, xr12, xr13
    XMADDW4_H xr7, xr8, xr23, xr23, xr10, xr11, xr12, xr13

    xvor.v           xr0,  xr2,  xr2
    xvor.v           xr1,  xr3,  xr3
    xvor.v           xr2,  xr4,  xr4
    xvor.v           xr3,  xr5,  xr5
    xvor.v           xr4,  xr6,  xr6
    xvor.v           xr5,  xr7,  xr7
    xvor.v           xr6,  xr8,  xr8

    xvpermi.d        xr10, xr10, 0xD8
    xvpermi.d        xr11, xr11, 0xD8
    xvpermi.d        xr12, xr12, 0xD8
    xvpermi.d        xr13, xr13, 0xD8
    xvilvl.h         xr9,  xr11, xr10
    xvilvh.h         xr14, xr11, xr10
    xvilvl.h         xr7,  xr13, xr12
    xvilvh.h         xr8,  xr13, xr12

    xvst             xr9,  a2,   0
    vst              vr14, a2,   32
    add.d            a2,   a2,   a3
    xvst             xr7,  a2,   0
    vst              vr8,  a2,   32
    addi.d           t0,   t0,   -1
    add.d            t6,   t6,   t1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .lasx_loopV_ps_24x32
endfunc

function x265_interp_8tap_vert_ps_48x64_lasx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    slli.d       a3,    a3,    1
    la.local     t6,    g_lumaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  32
    addi.d       sp,    sp,    -64
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride
    fst.d        f24,   sp,    0
    fst.d        f25,   sp,    8
    fst.d        f26,   sp,    16
    fst.d        f27,   sp,    24
    fst.d        f28,   sp,    32
    fst.d        f29,   sp,    40
    fst.d        f30,   sp,    48
    fst.d        f31,   sp,    56
    xvldrepl.b   xr16,  t5,    0
    xvldrepl.b   xr17,  t5,    2
    xvldrepl.b   xr18,  t5,    4
    xvldrepl.b   xr19,  t5,    6
    xvldrepl.b   xr20,  t5,    8
    xvldrepl.b   xr21,  t5,    10
    xvldrepl.b   xr22,  t5,    12
    xvldrepl.b   xr23,  t5,    14

    addi.d       t6,    a0,    32
    xvld         xr0,   a0,    0    //0
    xvldx        xr1,   a0,    a1   //1
    xvldx        xr2,   a0,    t1   //2
    xvldx        xr3,   a0,    t2   //3

    add.d        a0,    a0,    t3
    vld          vr9,   t6,    0
    vldx         vr10,  t6,    a1
    vldx         vr11,  t6,    t1
    vldx         vr12,  t6,    t2
    addi.d       t6,    a0,    32

    xvld         xr4,   a0,    0    //4
    xvldx        xr5,   a0,    a1   //5
    xvldx        xr6,   a0,    t1   //6

    vld          vr13,  t6,    0
    vldx         vr14,  t6,    a1
    vldx         vr15,  t6,    t1
    add.d        a0,    a0,    t2
    xvpermi.q    xr9,   xr10,  0x2
    xvpermi.q    xr10,  xr11,  0x2
    xvpermi.q    xr11,  xr12,  0x2
    xvpermi.q    xr12,  xr13,  0x2
    xvpermi.q    xr13,  xr14,  0x2
    xvpermi.q    xr14,  xr15,  0x2
.lasx_loopV_ps_48x64:
    addi.d       t6,    a0,    32
    xvld         xr26,  t4,    0
    xvld         xr7,   a0,    0   //7
    xvldx        xr8,   a0,    a1  //8
    vld          vr24,  t6,    0
    vldx         vr25,  t6,    a1
.irp x, xr27, xr28, xr29, xr30, xr31
    xvor.v       \x,    xr26,  xr26
.endr
    xvpermi.q    xr15,  xr24,  0x2
    xvpermi.q    xr24,  xr25,  0x2
    XMADDW4_H xr0,  xr1,  xr16, xr16, xr26, xr27, xr28, xr29
    XMADDW4_H xr9,  xr1,  xr16, xr17, xr30, xr31, xr26, xr27
    XMADDW4_H xr2,  xr10, xr17, xr17, xr28, xr29, xr30, xr31
    XMADDW4_H xr2,  xr3,  xr18, xr18, xr26, xr27, xr28, xr29
    XMADDW4_H xr11, xr3,  xr18, xr19, xr30, xr31, xr26, xr27
    XMADDW4_H xr4,  xr12, xr19, xr19, xr28, xr29, xr30, xr31
    XMADDW4_H xr4,  xr5,  xr20, xr20, xr26, xr27, xr28, xr29
    XMADDW4_H xr13, xr5,  xr20, xr21, xr30, xr31, xr26, xr27
    XMADDW4_H xr6,  xr14, xr21, xr21, xr28, xr29, xr30, xr31
    XMADDW4_H xr6,  xr7,  xr22, xr22, xr26, xr27, xr28, xr29
    XMADDW4_H xr15, xr7,  xr22, xr23, xr30, xr31, xr26, xr27
    XMADDW4_H xr8,  xr24, xr23, xr23, xr28, xr29, xr30, xr31

    xvor.v           xr0,  xr2,  xr2
    xvor.v           xr1,  xr3,  xr3
    xvor.v           xr2,  xr4,  xr4
    xvor.v           xr3,  xr5,  xr5
    xvor.v           xr4,  xr6,  xr6
    xvor.v           xr5,  xr7,  xr7
    xvor.v           xr6,  xr8,  xr8
    xvor.v           xr9,  xr11, xr11
    xvor.v           xr10, xr12, xr12
    xvor.v           xr11, xr13, xr13
    xvor.v           xr12, xr14, xr14
    xvor.v           xr13, xr15, xr15
    xvor.v           xr14, xr24, xr24
    xvor.v           xr15, xr25, xr25

    xvpermi.d        xr26, xr26, 0xD8
    xvpermi.d        xr27, xr27, 0xD8
    xvpermi.d        xr28, xr28, 0xD8
    xvpermi.d        xr29, xr29, 0xD8
    xvilvl.h         xr7,  xr27, xr26
    xvilvh.h         xr8,  xr27, xr26
    xvilvl.h         xr24, xr29, xr28
    xvilvh.h         xr25, xr29, xr28
    xvilvl.h         xr26, xr31, xr30
    xvilvh.h         xr27, xr31, xr30
    xvor.v           xr28, xr26, xr26
    xvpermi.q        xr26, xr27, 0x2
    xvpermi.q        xr28, xr27, 0x13

    xvst             xr7,  a2,   0
    xvst             xr8,  a2,   32
    xvst             xr26, a2,   64
    add.d            a2,   a2,   a3
    xvst             xr24, a2,   0
    xvst             xr25, a2,   32
    xvst             xr28, a2,   64
    addi.d           t0,   t0,   -1
    add.d            a0,   a0,   t1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .lasx_loopV_ps_48x64
    fld.d        f24,   sp,    0
    fld.d        f25,   sp,    8
    fld.d        f26,   sp,    16
    fld.d        f27,   sp,    24
    fld.d        f28,   sp,    32
    fld.d        f29,   sp,    40
    fld.d        f30,   sp,    48
    fld.d        f31,   sp,    56
    addi.d       sp,    sp,    64
endfunc

.macro FILTER_VERT_PS_32xN_LASX  h
function x265_interp_8tap_vert_ps_32x\h\()_lasx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    slli.d       a3,    a3,    1
    la.local     t6,    g_lumaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  \h/2
    sub.d        t6,    a0,    t2  //src -= 3 * srcStride
    xvldrepl.b   xr16,  t5,    0
    xvldrepl.b   xr17,  t5,    2
    xvldrepl.b   xr18,  t5,    4
    xvldrepl.b   xr19,  t5,    6
    xvldrepl.b   xr20,  t5,    8
    xvldrepl.b   xr21,  t5,    10
    xvldrepl.b   xr22,  t5,    12
    xvldrepl.b   xr23,  t5,    14
    xvld         xr15,  t4,    0

    add.d        a0,    t6,    t3
    xvld         xr0,   t6,    0    //0
    xvldx        xr1,   t6,    a1   //1
    xvldx        xr2,   t6,    t1   //2
    xvldx        xr3,   t6,    t2   //3

    xvld         xr4,   a0,    0    //4
    xvldx        xr5,   a0,    a1   //5
    xvldx        xr6,   a0,    t1   //6
    add.d        t6,    a0,    t2

.lasx_loopV_ps_32x\h:
    xvld         xr7,   t6,    0   //7
    xvldx        xr8,   t6,    a1  //8
.irp x, xr10, xr11, xr12, xr13
    xvor.v       \x,    xr15,  xr15
.endr
    XMADDW4_H xr0, xr1, xr16, xr16, xr10, xr11, xr12, xr13
    XMADDW4_H xr1, xr2, xr17, xr17, xr10, xr11, xr12, xr13
    XMADDW4_H xr2, xr3, xr18, xr18, xr10, xr11, xr12, xr13
    XMADDW4_H xr3, xr4, xr19, xr19, xr10, xr11, xr12, xr13
    XMADDW4_H xr4, xr5, xr20, xr20, xr10, xr11, xr12, xr13
    XMADDW4_H xr5, xr6, xr21, xr21, xr10, xr11, xr12, xr13
    XMADDW4_H xr6, xr7, xr22, xr22, xr10, xr11, xr12, xr13
    XMADDW4_H xr7, xr8, xr23, xr23, xr10, xr11, xr12, xr13

    xvor.v           xr0,  xr2,  xr2
    xvor.v           xr1,  xr3,  xr3
    xvor.v           xr2,  xr4,  xr4
    xvor.v           xr3,  xr5,  xr5
    xvor.v           xr4,  xr6,  xr6
    xvor.v           xr5,  xr7,  xr7
    xvor.v           xr6,  xr8,  xr8

    xvpermi.d        xr10, xr10, 0xD8
    xvpermi.d        xr11, xr11, 0xD8
    xvpermi.d        xr12, xr12, 0xD8
    xvpermi.d        xr13, xr13, 0xD8
    xvilvl.h         xr9,  xr11, xr10
    xvilvh.h         xr14, xr11, xr10
    xvilvl.h         xr7,  xr13, xr12
    xvilvh.h         xr8,  xr13, xr12

    xvst             xr9,  a2,   0
    xvst             xr14, a2,   32
    add.d            a2,   a2,   a3
    xvst             xr7,  a2,   0
    xvst             xr8,  a2,   32
    addi.d           t0,   t0,   -1
    add.d            t6,   t6,   t1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .lasx_loopV_ps_32x\h
endfunc
.endm

FILTER_VERT_PS_32xN_LASX 8
FILTER_VERT_PS_32xN_LASX 16
FILTER_VERT_PS_32xN_LASX 24
FILTER_VERT_PS_32xN_LASX 32
FILTER_VERT_PS_32xN_LASX 64

.macro FILTER_VERT_PS_64xN_LASX  h
function x265_interp_8tap_vert_ps_64x\h\()_lasx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    slli.d       a3,    a3,    1
    la.local     t6,    g_lumaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  \h
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride
    addi.d       sp,    sp,    -40
    fst.d        f24,   sp,    0
    fst.d        f25,   sp,    8
    fst.d        f26,   sp,    16
    fst.d        f27,   sp,    24
    fst.d        f28,   sp,    32

    xvldrepl.b   xr16,  t5,    0
    xvldrepl.b   xr17,  t5,    2
    xvldrepl.b   xr18,  t5,    4
    xvldrepl.b   xr19,  t5,    6
    xvldrepl.b   xr20,  t5,    8
    xvldrepl.b   xr21,  t5,    10
    xvldrepl.b   xr22,  t5,    12
    xvldrepl.b   xr23,  t5,    14
    xvld         xr28,  t4,    0

    addi.d       t6,    a0,    32
    xvld         xr0,   a0,    0    //0
    xvldx        xr1,   a0,    a1   //1
    xvldx        xr2,   a0,    t1   //2
    xvldx        xr3,   a0,    t2   //3

    add.d        a0,    a0,    t3
    xvld         xr8,   t6,    0
    xvldx        xr9,   t6,    a1
    xvldx        xr10,  t6,    t1
    xvldx        xr11,  t6,    t2
    addi.d       t6,    a0,    32

    xvld         xr4,   a0,    0    //4
    xvldx        xr5,   a0,    a1   //5
    xvldx        xr6,   a0,    t1   //6

    xvld         xr12,  t6,    0
    xvldx        xr13,  t6,    a1
    xvldx        xr14,  t6,    t1
    add.d        a0,    a0,    t2
.lasx_loopV_ps_64x\h:
    xvld         xr7,   a0,    0   //7
    xvld         xr15,  a0,    32  //7
.irp x, xr24, xr25, xr26, xr27
    xvor.v       \x,    xr28,  xr28
.endr
    XMADDW4_H xr0, xr8, xr16, xr16, xr24, xr25, xr26, xr27
    XMADDW4_H xr1, xr9, xr17, xr17, xr24, xr25, xr26, xr27
    XMADDW4_H xr2, xr10, xr18, xr18, xr24, xr25, xr26, xr27
    XMADDW4_H xr3, xr11, xr19, xr19, xr24, xr25, xr26, xr27
    XMADDW4_H xr4, xr12, xr20, xr20, xr24, xr25, xr26, xr27
    XMADDW4_H xr5, xr13, xr21, xr21, xr24, xr25, xr26, xr27
    XMADDW4_H xr6, xr14, xr22, xr22, xr24, xr25, xr26, xr27
    XMADDW4_H xr7, xr15, xr23, xr23, xr24, xr25, xr26, xr27

    xvor.v           xr0,  xr1,  xr1
    xvor.v           xr1,  xr2,  xr2
    xvor.v           xr2,  xr3,  xr3
    xvor.v           xr3,  xr4,  xr4
    xvor.v           xr4,  xr5,  xr5
    xvor.v           xr5,  xr6,  xr6
    xvor.v           xr6,  xr7,  xr7

    xvpermi.d        xr24, xr24, 0xD8
    xvpermi.d        xr25, xr25, 0xD8
    xvpermi.d        xr26, xr26, 0xD8
    xvpermi.d        xr27, xr27, 0xD8
    xvor.v           xr8,  xr9,  xr9
    xvor.v           xr9,  xr10, xr10
    xvor.v           xr10, xr11, xr11
    xvor.v           xr11, xr12, xr12
    xvor.v           xr12, xr13, xr13
    xvor.v           xr13, xr14, xr14
    xvor.v           xr14, xr15, xr15
    xvilvl.h         xr7,  xr25, xr24
    xvilvh.h         xr24, xr25, xr24
    xvilvl.h         xr15, xr27, xr26
    xvilvh.h         xr26, xr27, xr26
    xvst             xr7,  a2,   0
    xvst             xr24, a2,   32
    xvst             xr15, a2,   64
    xvst             xr26, a2,   96
    add.d            a0,   a0,   a1
    addi.d           t0,   t0,   -1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .lasx_loopV_ps_64x\h
    fld.d        f24,   sp,    0
    fld.d        f25,   sp,    8
    fld.d        f26,   sp,    16
    fld.d        f27,   sp,    24
    fld.d        f28,   sp,    32
    addi.d       sp,    sp,    40
endfunc
.endm

FILTER_VERT_PS_64xN_LASX 16
FILTER_VERT_PS_64xN_LASX 32
FILTER_VERT_PS_64xN_LASX 48
FILTER_VERT_PS_64xN_LASX 64

.macro FILTER_TO_SHORT_2xN  h
function x265_filterPixelToShort_2x\h\()_lsx
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    slli.d       a3,    a3,    1
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    addi.d       t0,    zero,  \h/4
    vld          vr10,  t4,    0
.loop_short_2x\h:
    fld.s        f0,    a0,     0
    fldx.s       f1,    a0,     a1
    fldx.s       f2,    a0,     t1
    fldx.s       f3,    a0,     t2
    vilvl.h      vr4,   vr1,    vr0
    vilvl.h      vr5,   vr3,    vr2
    vilvl.w      vr6,   vr5,    vr4
    add.d        a0,    a0,     t3
    vsllwil.hu.bu vr7,  vr6,  6
    vadd.h       vr8,   vr7,    vr10
    addi.d       t0,    t0,     -1
    vstelm.w     vr8,   a2,     0,   0
    add.d        a2,    a2,     a3
    vstelm.w     vr8,   a2,     0,   1
    add.d        a2,    a2,     a3
    vstelm.w     vr8,   a2,     0,   2
    add.d        a2,    a2,     a3
    vstelm.w     vr8,   a2,     0,   3
    add.d        a2,    a2,     a3
    blt          zero,  t0,     .loop_short_2x\h
endfunc
.endm

FILTER_TO_SHORT_2xN 4
FILTER_TO_SHORT_2xN 8
FILTER_TO_SHORT_2xN 16

.macro FILTER_TO_SHORT_4xN  h
function x265_filterPixelToShort_4x\h\()_lsx
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       a3,    a3,    1
    la.local     t4,    h_psOffset
    addi.d       t0,    zero,  \h/2
    vld          vr10,  t4,    0
.loop_short_4x\h:
    fld.s        f0,    a0,     0
    fldx.s       f1,    a0,     a1
    vilvl.w      vr4,   vr1,    vr0
    add.d        a0,    a0,     t1
    vsllwil.hu.bu vr5,  vr4,  6
    vadd.h       vr6,   vr5,    vr10
    addi.d       t0,    t0,     -1
    vstelm.d     vr6,   a2,     0,   0
    add.d        a2,    a2,     a3
    vstelm.d     vr6,   a2,     0,   1
    add.d        a2,    a2,     a3
    blt          zero,  t0,     .loop_short_4x\h
endfunc
.endm

FILTER_TO_SHORT_4xN 2
FILTER_TO_SHORT_4xN 4
FILTER_TO_SHORT_4xN 8
FILTER_TO_SHORT_4xN 16
FILTER_TO_SHORT_4xN 32

.macro FILTER_TO_SHORT_6xN  h
function x265_filterPixelToShort_6x\h\()_lsx
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       a3,    a3,    1
    la.local     t4,    h_psOffset
    addi.d       t0,    zero,  \h/2
    vld          vr10,  t4,    0
.loop_short_6x\h:
    fld.d        f0,    a0,     0
    fldx.d       f1,    a0,     a1
    addi.d       t0,    t0,     -1
    vsllwil.hu.bu vr2,  vr0,  6
    vsllwil.hu.bu vr3,  vr1,  6
    vadd.h       vr4,   vr2,    vr10
    vadd.h       vr5,   vr3,    vr10
    vstelm.d     vr4,   a2,     0,    0
    vstelm.w     vr4,   a2,     8,    2
    add.d        a2,    a2,     a3
    add.d        a0,    a0,     t1
    vstelm.d     vr5,   a2,     0,    0
    vstelm.w     vr5,   a2,     8,    2
    add.d        a2,    a2,     a3
    blt          zero,  t0,     .loop_short_6x\h
endfunc
.endm

FILTER_TO_SHORT_6xN 8
FILTER_TO_SHORT_6xN 16

.macro FILTER_TO_SHORT_8xN  h
function x265_filterPixelToShort_8x\h\()_lsx
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t2,    a3,    1
    slli.d       t3,    a3,    2
    la.local     t4,    h_psOffset
    addi.d       t0,    zero,  \h/2
    vld          vr10,  t4,    0
.loop_short_8x\h:
    fld.d        f0,    a0,     0
    fldx.d       f1,    a0,     a1
    addi.d       t0,    t0,     -1
    vsllwil.hu.bu vr2,  vr0,  6
    vsllwil.hu.bu vr3,  vr1,  6
    vadd.h       vr4,   vr2,    vr10
    vadd.h       vr5,   vr3,    vr10
    vst          vr4,   a2,     0
    vstx         vr5,   a2,     t2
    add.d        a0,    a0,     t1
    add.d        a2,    a2,     t3
    blt          zero,  t0,     .loop_short_8x\h
endfunc
.endm

FILTER_TO_SHORT_8xN 2
FILTER_TO_SHORT_8xN 4
FILTER_TO_SHORT_8xN 6
FILTER_TO_SHORT_8xN 8
FILTER_TO_SHORT_8xN 12
FILTER_TO_SHORT_8xN 16
FILTER_TO_SHORT_8xN 32
FILTER_TO_SHORT_8xN 64

.macro FILTER_TO_SHORT_12xN  h
function x265_filterPixelToShort_12x\h\()_lsx
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t2,    a3,    1
    la.local     t4,    h_psOffset
    addi.d       t0,    zero,  \h/2
    vld          vr10,  t4,    0
.loop_short_12x\h:
    vld          vr0,   a0,     0
    vldx         vr1,   a0,     a1
    addi.d       t0,    t0,     -1
    vilvh.w      vr2,   vr1,    vr0
    vsllwil.hu.bu vr3,  vr0,  6
    vsllwil.hu.bu vr4,  vr1,  6
    vsllwil.hu.bu vr5,  vr2,  6
    vadd.h       vr6,   vr3,    vr10
    vadd.h       vr7,   vr4,    vr10
    vadd.h       vr8,   vr5,    vr10

    vst          vr6,   a2,     0
    vstelm.d     vr8,   a2,     16,   0
    add.d        a0,    a0,     t1
    add.d        a2,    a2,     t2
    vst          vr7,   a2,     0
    vstelm.d     vr8,   a2,     16,   1
    add.d        a2,    a2,     t2
    blt          zero,  t0,     .loop_short_12x\h
endfunc
.endm

FILTER_TO_SHORT_12xN 16
FILTER_TO_SHORT_12xN 32

.macro FILTER_TO_SHORT_WxN  w, h, rep
function x265_filterPixelToShort_\w\()x\h\()_lsx
    slli.d       t1,    a1,    1   //src_stride*2
    slli.d       t3,    a1,    2   //src_stride*4
    slli.d       a3,    a3,    1   //dst_stride
    la.local     t7,    h_psOffset
    add.d        t2,    a1,    t1  //src_stride*3
    addi.d       t0,    zero,  \h/4
    slli.d       a4,    a3,    2   //dst_stride*4
    vld          vr9,   t7,    0
.loop_short_\w\()x\h:
    move         t7,    a0
    move         t8,    a2
.rept \rep
    vld          vr0,   t7,    0
    vldx         vr1,   t7,    a1
    vldx         vr2,   t7,    t1
    vldx         vr3,   t7,    t2

    vexth.hu.bu  vr4,   vr0
    vexth.hu.bu  vr5,   vr1
    vexth.hu.bu  vr6,   vr2
    vexth.hu.bu  vr7,   vr3

    vsllwil.hu.bu vr10, vr0,  6
    vsllwil.hu.bu vr11, vr1,  6
    vsllwil.hu.bu vr12, vr2,  6
    vsllwil.hu.bu vr13, vr3,  6

    vslli.h      vr14,  vr4,  6
    vslli.h      vr15,  vr5,  6
    vslli.h      vr16,  vr6,  6
    vslli.h      vr17,  vr7,  6

    vadd.h       vr0,   vr10, vr9
    vadd.h       vr1,   vr11, vr9
    vadd.h       vr2,   vr12, vr9
    vadd.h       vr3,   vr13, vr9

    vadd.h       vr4,   vr14, vr9
    vadd.h       vr5,   vr15, vr9
    vadd.h       vr6,   vr16, vr9
    vadd.h       vr7,   vr17, vr9

    add.d        t4,    t8,   a3
    vst          vr0,   t8,   0
    vst          vr4,   t8,   16
    add.d        t5,    t4,   a3
    vst          vr1,   t4,   0
    vst          vr5,   t4,   16
    add.d        t6,    t5,   a3
    vst          vr2,   t5,   0
    vst          vr6,   t5,   16
    vst          vr3,   t6,   0
    vst          vr7,   t6,   16
    addi.d       t7,    t7,   16
    addi.d       t8,    t8,   32
.endr
    addi.d       t0,    t0,   -1
    add.d        a0,    a0,   t3
    add.d        a2,    a2,   a4
    blt          zero,  t0,   .loop_short_\w\()x\h
endfunc
.endm

FILTER_TO_SHORT_WxN 16, 4,  1
FILTER_TO_SHORT_WxN 16, 8,  1
FILTER_TO_SHORT_WxN 16, 12, 1
FILTER_TO_SHORT_WxN 16, 16, 1
FILTER_TO_SHORT_WxN 16, 24, 1
FILTER_TO_SHORT_WxN 16, 32, 1
FILTER_TO_SHORT_WxN 16, 64, 1

FILTER_TO_SHORT_WxN 32, 8,  2
FILTER_TO_SHORT_WxN 32, 16, 2
FILTER_TO_SHORT_WxN 32, 24, 2
FILTER_TO_SHORT_WxN 32, 32, 2
FILTER_TO_SHORT_WxN 32, 48, 2
FILTER_TO_SHORT_WxN 32, 64, 2

FILTER_TO_SHORT_WxN 48, 64, 3

FILTER_TO_SHORT_WxN 64, 16, 4
FILTER_TO_SHORT_WxN 64, 32, 4
FILTER_TO_SHORT_WxN 64, 48, 4
FILTER_TO_SHORT_WxN 64, 64, 4

.macro FILTER_TO_SHORT_WxN_LASX  w, h, rep
function x265_filterPixelToShort_\w\()x\h\()_lasx
    slli.d       t1,    a1,    1   //src_stride*2
    slli.d       t3,    a1,    2   //src_stride*4
    slli.d       a3,    a3,    1   //dst_stride
    la.local     t7,    h_psOffset
    add.d        t2,    a1,    t1  //src_stride*3
    addi.d       t0,    zero,  \h/4
    slli.d       t4,    a3,    1   //dst_stride*2
    slli.d       t6,    a3,    2   //dst_stride*4
    add.d        t5,    t4,    a3  //dst_stride*3
    xvld         xr9,   t7,    0
.loop_short_lasx_\w\()x\h:
    move         t7,    a0
    move         t8,    a2
.rept \rep
    vld          vr0,   t7,    0
    vldx         vr1,   t7,    a1
    vldx         vr2,   t7,    t1
    vldx         vr3,   t7,    t2

    vext2xv.hu.bu xr4,  xr0
    vext2xv.hu.bu xr5,  xr1
    vext2xv.hu.bu xr6,  xr2
    vext2xv.hu.bu xr7,  xr3

    xvslli.h     xr10,  xr4,  6
    xvslli.h     xr11,  xr5,  6
    xvslli.h     xr12,  xr6,  6
    xvslli.h     xr13,  xr7,  6

    xvadd.h      xr0,   xr10, xr9
    xvadd.h      xr1,   xr11, xr9
    xvadd.h      xr2,   xr12, xr9
    xvadd.h      xr3,   xr13, xr9

    xvst         xr0,   t8,   0
    xvstx        xr1,   t8,   a3
    xvstx        xr2,   t8,   t4
    xvstx        xr3,   t8,   t5
    addi.d       t7,    t7,   16
    addi.d       t8,    t8,   32
.endr
    addi.d       t0,    t0,   -1
    add.d        a0,    a0,   t3
    add.d        a2,    a2,   t6
    blt          zero,  t0,   .loop_short_lasx_\w\()x\h
endfunc
.endm

FILTER_TO_SHORT_WxN_LASX 16, 4,  1
FILTER_TO_SHORT_WxN_LASX 16, 8,  1
FILTER_TO_SHORT_WxN_LASX 16, 12, 1
FILTER_TO_SHORT_WxN_LASX 16, 16, 1
FILTER_TO_SHORT_WxN_LASX 16, 24, 1
FILTER_TO_SHORT_WxN_LASX 16, 32, 1
FILTER_TO_SHORT_WxN_LASX 16, 64, 1

FILTER_TO_SHORT_WxN_LASX 32, 8,  2
FILTER_TO_SHORT_WxN_LASX 32, 16, 2
FILTER_TO_SHORT_WxN_LASX 32, 24, 2
FILTER_TO_SHORT_WxN_LASX 32, 32, 2
FILTER_TO_SHORT_WxN_LASX 32, 48, 2
FILTER_TO_SHORT_WxN_LASX 32, 64, 2

FILTER_TO_SHORT_WxN_LASX 48, 64, 3

FILTER_TO_SHORT_WxN_LASX 64, 16, 4
FILTER_TO_SHORT_WxN_LASX 64, 32, 4
FILTER_TO_SHORT_WxN_LASX 64, 48, 4
FILTER_TO_SHORT_WxN_LASX 64, 64, 4

.macro FILTER_TO_SHORT_24xN  h
function x265_filterPixelToShort_24x\h\()_lsx
    slli.d       t1,    a1,    1   //src_stride*2
    slli.d       t3,    a1,    2   //src_stride*4
    slli.d       a3,    a3,    1   //dst_stride
    la.local     t7,    h_psOffset
    add.d        t2,    a1,    t1  //src_stride*3
    addi.d       t0,    zero,  \h/4
    slli.d       a4,    a3,    2   //dst_stride*4
    vld          vr9,   t7,    0
.loop_short_24x\h:
    addi.d       t7,    a0,    16
    vld          vr0,   a0,    0
    vldx         vr1,   a0,    a1
    vldx         vr2,   a0,    t1
    vldx         vr3,   a0,    t2
    fld.d        f18,   t7,    0
    fldx.d       f19,   t7,    a1
    fldx.d       f20,   t7,    t1
    fldx.d       f21,   t7,    t2

    vexth.hu.bu  vr4,   vr0
    vexth.hu.bu  vr5,   vr1
    vexth.hu.bu  vr6,   vr2
    vexth.hu.bu  vr7,   vr3

    vsllwil.hu.bu vr10, vr0,  6
    vsllwil.hu.bu vr11, vr1,  6
    vsllwil.hu.bu vr12, vr2,  6
    vsllwil.hu.bu vr13, vr3,  6

    vslli.h      vr14,  vr4,  6
    vslli.h      vr15,  vr5,  6
    vslli.h      vr16,  vr6,  6
    vslli.h      vr17,  vr7,  6

    vsllwil.hu.bu vr18, vr18, 6
    vsllwil.hu.bu vr19, vr19, 6
    vsllwil.hu.bu vr20, vr20, 6
    vsllwil.hu.bu vr21, vr21, 6

    vadd.h       vr0,   vr10, vr9
    vadd.h       vr1,   vr11, vr9
    vadd.h       vr2,   vr12, vr9
    vadd.h       vr3,   vr13, vr9

    vadd.h       vr4,   vr14, vr9
    vadd.h       vr5,   vr15, vr9
    vadd.h       vr6,   vr16, vr9
    vadd.h       vr7,   vr17, vr9

    vadd.h       vr18,  vr18, vr9
    vadd.h       vr19,  vr19, vr9
    vadd.h       vr20,  vr20, vr9
    vadd.h       vr21,  vr21, vr9

    add.d        t4,    a2,   a3
    vst          vr0,   a2,   0
    vst          vr4,   a2,   16
    vst          vr18,  a2,   32
    add.d        t5,    t4,   a3
    vst          vr1,   t4,   0
    vst          vr5,   t4,   16
    vst          vr19,  t4,   32
    add.d        t6,    t5,   a3
    vst          vr2,   t5,   0
    vst          vr6,   t5,   16
    vst          vr20,  t5,   32
    vst          vr3,   t6,   0
    vst          vr7,   t6,   16
    vst          vr21,  t6,   32
    addi.d       t0,    t0,   -1
    add.d        a0,    a0,   t3
    add.d        a2,    a2,   a4
    blt          zero,  t0,   .loop_short_24x\h
endfunc
.endm

FILTER_TO_SHORT_24xN  32
FILTER_TO_SHORT_24xN  64

.macro FILTER_TO_SHORT_24xN_LASX  h
function x265_filterPixelToShort_24x\h\()_lasx
    slli.d       t1,    a1,    1   //src_stride*2
    slli.d       t3,    a1,    2   //src_stride*4
    slli.d       a3,    a3,    1   //dst_stride
    la.local     t7,    h_psOffset
    add.d        t2,    a1,    t1  //src_stride*3
    addi.d       t0,    zero,  \h/4
    slli.d       a4,    a3,    2   //dst_stride*4
    xvld         xr9,   t7,    0
.loop_short_lasx_24x\h:
    xvld         xr0,   a0,    0
    xvldx        xr1,   a0,    a1
    xvldx        xr2,   a0,    t1
    xvldx        xr3,   a0,    t2

    xvpermi.d    xr0,   xr0,   0xD8
    xvpermi.d    xr1,   xr1,   0xD8
    xvpermi.d    xr2,   xr2,   0xD8
    xvpermi.d    xr3,   xr3,   0xD8
    xvilvh.d     xr4,   xr1,   xr0
    xvilvh.d     xr5,   xr3,   xr2

    xvsllwil.hu.bu xr10, xr0,  6
    xvsllwil.hu.bu xr11, xr1,  6
    vext2xv.hu.bu  xr14, xr4
    vext2xv.hu.bu  xr15, xr5
    xvsllwil.hu.bu xr12, xr2,  6
    xvsllwil.hu.bu xr13, xr3,  6

    xvslli.h       xr16, xr14, 6
    xvslli.h       xr17, xr15, 6

    xvadd.h        xr0,  xr10, xr9
    xvadd.h        xr1,  xr11, xr9
    xvadd.h        xr2,  xr12, xr9
    xvadd.h        xr3,  xr13, xr9
    xvadd.h        xr4,  xr16, xr9
    xvadd.h        xr5,  xr17, xr9

    add.d          t4,   a2,   a3
    xvst           xr0,  a2,   0
    vst            vr4,  a2,   32
    xvpermi.d      xr6,  xr4,  0x4E
    xvpermi.d      xr7,  xr5,  0x4E
    add.d          t5,   t4,   a3
    xvst           xr1,  t4,   0
    vst            vr6,  t4,   32
    add.d          t6,   t5,   a3
    xvst           xr2,  t5,   0
    vst            vr5,  t5,   32
    xvst           xr3,  t6,   0
    vst            vr7,  t6,   32
    addi.d         t0,    t0,   -1
    add.d          a0,    a0,   t3
    add.d          a2,    a2,   a4
    blt            zero,  t0,   .loop_short_lasx_24x\h
endfunc
.endm

FILTER_TO_SHORT_24xN_LASX  32
FILTER_TO_SHORT_24xN_LASX  64

.macro VMULW4_W  in0, in1, mul0, mul1, out0, out1, out2, out3
    vmulwev.w.h   \out0,  \in0,  \mul0
    vmulwod.w.h   \out1,  \in0,  \mul0
    vmulwev.w.h   \out2,  \in1,  \mul1
    vmulwod.w.h   \out3,  \in1,  \mul1
.endm

.macro VMADD4_W  in0, in1, mul0, mul1, out0, out1, out2, out3
    vmaddwev.w.h   \out0,  \in0,  \mul0
    vmaddwod.w.h   \out1,  \in0,  \mul0
    vmaddwev.w.h   \out2,  \in1,  \mul1
    vmaddwod.w.h   \out3,  \in1,  \mul1
.endm

.macro FILTER_HV_PP_4xN  h
function x265_interp_8tap_hv_pp_4x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t8,    a5,    4
    la.local     t6,    g_lumaFilter
    la.local     t5,    h_psOffset
    vldx         vr10,  t6,    t7
    vld          vr11,  t5,    0   //-8192
    addi.d       t0,    zero,  \h/2
    addi.d       sp,    sp,    -(8 * (\h + 7))
    alsl.d       t1,    a1,    a1,   1
    addi.d       t2,    t0,    3
    sub.d        a0,    a0,    t1
    addi.d       t6,    t6,    128

    fld.d        f0,    a0,    -3
    fld.d        f1,    a0,    -2
    fld.d        f2,    a0,    -1
    fld.d        f3,    a0,    0
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    VMULW4_H  vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    vhaddw.w.h   vr6,   vr6,   vr6
    vhaddw.w.h   vr7,   vr7,   vr7
    vhaddw.w.h   vr8,   vr8,   vr8
    vhaddw.w.h   vr9,   vr9,   vr9
    vpickev.h    vr12,  vr7,   vr6
    vpickev.h    vr13,  vr9,   vr8
    vhaddw.w.h   vr12,  vr12,  vr12
    vhaddw.w.h   vr13,  vr13,  vr13
    vpickev.h    vr14,  vr13,  vr12
    vhaddw.w.h   vr14,  vr14,  vr14
    vpickev.h    vr20,  vr11,  vr14
    vadd.h       vr21,  vr20,  vr11
    add.d        a0,    a0,    a1
    fst.d        f21,   sp,    0
    addi.d       t3,    sp,    8
.loop_hv_ps_4x\h:
    fld.d        f0,    a0,    -3
    fld.d        f1,    a0,    -2
    fld.d        f2,    a0,    -1
    fld.d        f3,    a0,    0
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    add.d        a0,    a0,    a1
    VMULW4_H  vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    fld.d        f16,    a0,   -3
    fld.d        f17,    a0,   -2
    fld.d        f18,    a0,   -1
    fld.d        f19,    a0,   0
    vilvl.b      vr4,   vr17,  vr16
    vilvl.b      vr5,   vr19,  vr18
    add.d        a0,    a0,    a1
    VMULW4_H  vr4, vr5, vr10, vr10, vr12, vr13, vr14, vr15

    PROCESS_LUMA vr6, vr7, vr8, vr9, vr12, vr13, vr14, vr15, \
                 vr20, vr16, vr17, vr18, vr19

    vadd.h       vr21,  vr20,  vr11
    addi.d       t2,    t2,    -1
    vstelm.d     vr21,  t3,    0,    0
    vstelm.d     vr21,  t3,    8,    1
    addi.d       t3,    t3,    16
    blt          zero,  t2,    .loop_hv_ps_4x\h
    add.d        t7,    t6,    t8
    vld          vr11,  t5,    32  //526336
    vldrepl.h    vr16,  t7,    0
    vldrepl.h    vr17,  t7,    2
    vldrepl.h    vr18,  t7,    4
    vldrepl.h    vr19,  t7,    6
    vldrepl.h    vr20,  t7,    8
    vldrepl.h    vr21,  t7,    10
    vldrepl.h    vr22,  t7,    12
    vldrepl.h    vr23,  t7,    14
    addi.d       t3,    sp,    64
    vld          vr0,   sp,    0   //0, 1
    vld          vr1,   sp,    8   //1, 2
    vld          vr2,   sp,    16  //2, 3
    vld          vr3,   sp,    24  //3, 4
    vld          vr4,   sp,    32  //4, 5
    vld          vr5,   sp,    40  //5, 6
    vld          vr6,   sp,    48  //6, 7
    vld          vr7,   sp,    56  //7, 8
.loop_hv_sp_4x\h:
    vld          vr8,   t3,    0   //8, 9
    vld          vr9,   t3,    8   //9, 10
    vor.v        vr12,  vr11,  vr11
    vor.v        vr13,  vr11,  vr11
    VMADD4_W vr0, vr1, vr16, vr17, vr12, vr13, vr12, vr13
    VMADD4_W vr2, vr3, vr18, vr19, vr12, vr13, vr12, vr13
    VMADD4_W vr4, vr5, vr20, vr21, vr12, vr13, vr12, vr13
    VMADD4_W vr6, vr7, vr22, vr23, vr12, vr13, vr12, vr13
    vssrani.h.w   vr13, vr12, 12
    vor.v         vr0,  vr2,  vr2
    vor.v         vr1,  vr3,  vr3
    vssrani.bu.h  vr10, vr13, 0
    vor.v         vr2,  vr4,  vr4
    vor.v         vr3,  vr5,  vr5
    vbsrl.v       vr14, vr10, 4
    vor.v         vr4,  vr6,  vr6
    vor.v         vr5,  vr7,  vr7
    vilvl.b       vr15, vr14, vr10
    vor.v         vr6,  vr8,  vr8
    vor.v         vr7,  vr9,  vr9
    vstelm.w      vr15, a2,   0,  0
    addi.d        t0,   t0,   -1
    add.d         a2,   a2,   a3
    addi.d        t3,   t3,   16
    vstelm.w      vr15, a2,   0,  1
    add.d         a2,   a2,   a3
    blt           zero, t0,   .loop_hv_sp_4x\h
    addi.d        sp,   sp,   8 * (\h + 7)
endfunc
.endm

FILTER_HV_PP_4xN  4
FILTER_HV_PP_4xN  8
FILTER_HV_PP_4xN  16

.macro FILTER_HV_PP_8xN  h
function x265_interp_8tap_hv_pp_8x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t8,    a5,    4
    la.local     t6,    g_lumaFilter
    la.local     t5,    h_psOffset
    vldx         vr10,  t6,    t7
    vld          vr11,  t5,    0
    addi.d       t0,    zero,  \h/2
    addi.d       sp,    sp,    -(16 * (\h + 7))
    alsl.d       t1,    a1,    a1,   1
    sub.d        a0,    a0,    t1
    addi.d       t2,    t0,    3
    addi.d       t6,    t6,    128

    fld.d        f0,    a0,    -3
    fld.d        f1,    a0,    -2
    fld.d        f2,    a0,    -1
    fld.d        f3,    a0,    0
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    VMULW4_H  vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    fld.d        f0,    a0,    1
    fld.d        f1,    a0,    2
    fld.d        f2,    a0,    3
    fld.d        f3,    a0,    4
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    add.d        a0,    a0,    a1
    VMULW4_H  vr4, vr5, vr10, vr10, vr12, vr13, vr14, vr15

    PROCESS_LUMA vr6, vr7, vr8, vr9, vr12, vr13, vr14, vr15, \
                 vr20, vr16, vr17, vr18, vr19

    vadd.h       vr21,  vr20,  vr11
    vst          vr21,  sp,    0
    addi.d       t3,    sp,    16
.loop_hv_ps_8x\h:
    fld.d        f0,    a0,    -3
    fld.d        f1,    a0,    -2
    fld.d        f2,    a0,    -1
    fld.d        f3,    a0,    0
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    VMULW4_H  vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    fld.d        f0,    a0,    1
    fld.d        f1,    a0,    2
    fld.d        f2,    a0,    3
    fld.d        f3,    a0,    4
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    add.d        a0,    a0,    a1
    VMULW4_H  vr4, vr5, vr10, vr10, vr12, vr13, vr14, vr15

    PROCESS_LUMA vr6, vr7, vr8, vr9, vr12, vr13, vr14, vr15, \
                 vr20, vr16, vr17, vr18, vr19

    fld.d        f0,    a0,    -3
    fld.d        f1,    a0,    -2
    fld.d        f2,    a0,    -1
    fld.d        f3,    a0,    0
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    VMULW4_H  vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    fld.d        f0,    a0,    1
    fld.d        f1,    a0,    2
    fld.d        f2,    a0,    3
    fld.d        f3,    a0,    4
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    add.d        a0,    a0,    a1
    VMULW4_H  vr4, vr5, vr10, vr10, vr12, vr13, vr14, vr15

    PROCESS_LUMA vr6, vr7, vr8, vr9, vr12, vr13, vr14, vr15, \
                 vr21, vr16, vr17, vr18, vr19

    vadd.h       vr20,  vr20,  vr11
    vadd.h       vr21,  vr21,  vr11
    vst          vr20,  t3,    0
    vst          vr21,  t3,    16
    addi.d       t2,    t2,    -1
    addi.d       t3,    t3,    32
    blt          zero,  t2,    .loop_hv_ps_8x\h
    add.d        t7,    t6,    t8
    vld          vr11,  t5,    32
    vldrepl.h    vr16,  t7,    0
    vldrepl.h    vr17,  t7,    2
    vldrepl.h    vr18,  t7,    4
    vldrepl.h    vr19,  t7,    6
    vldrepl.h    vr20,  t7,    8
    vldrepl.h    vr21,  t7,    10
    vldrepl.h    vr22,  t7,    12
    vldrepl.h    vr23,  t7,    14
    addi.d       t3,    sp,    128
    vld          vr0,   sp,    0
    vld          vr1,   sp,    16
    vld          vr2,   sp,    32
    vld          vr3,   sp,    48
    vld          vr4,   sp,    64
    vld          vr5,   sp,    80
    vld          vr6,   sp,    96
    vld          vr7,   sp,    112
.loop_hv_sp_8x\h:
    vld          vr8,   t3,    0
    vld          vr9,   t3,    16
.irp x, vr10, vr12, vr13, vr14
    vor.v        \x,    vr11,  vr11
.endr
    VMADD4_W vr0, vr1, vr16, vr16, vr10, vr12, vr13, vr14
    VMADD4_W vr1, vr2, vr17, vr17, vr10, vr12, vr13, vr14
    VMADD4_W vr2, vr3, vr18, vr18, vr10, vr12, vr13, vr14
    VMADD4_W vr3, vr4, vr19, vr19, vr10, vr12, vr13, vr14
    VMADD4_W vr4, vr5, vr20, vr20, vr10, vr12, vr13, vr14
    VMADD4_W vr5, vr6, vr21, vr21, vr10, vr12, vr13, vr14
    VMADD4_W vr6, vr7, vr22, vr22, vr10, vr12, vr13, vr14
    VMADD4_W vr7, vr8, vr23, vr23, vr10, vr12, vr13, vr14
    vssrani.h.w  vr13,  vr10,  12
    vssrani.h.w  vr14,  vr12,  12
    vor.v        vr0,   vr2,   vr2
    vor.v        vr1,   vr3,   vr3
    vor.v        vr2,   vr4,   vr4
    vor.v        vr3,   vr5,   vr5
    vssrani.bu.h vr14,  vr13,  0
    vor.v        vr4,   vr6,   vr6
    vor.v        vr5,   vr7,   vr7
    vbsrl.v      vr15,  vr14,  8
    vor.v        vr6,   vr8,   vr8
    vor.v        vr7,   vr9,   vr9
    vilvl.b      vr10,  vr15,  vr14
    addi.d       t0,    t0,    -1
    addi.d       t3,    t3,    32
    fst.d        f10,   a2,    0
    add.d        a2,    a2,    a3
    vstelm.d     vr10,  a2,    0,    1
    add.d        a2,    a2,    a3
    blt          zero,  t0,    .loop_hv_sp_8x\h
    addi.d       sp,    sp,    16 * (\h + 7)
endfunc
.endm

FILTER_HV_PP_8xN 4
FILTER_HV_PP_8xN 8
FILTER_HV_PP_8xN 16
FILTER_HV_PP_8xN 32

.macro PROCESS_LUMA_HV in0, in1, in2, in3, in4, in5, in6, in7, out0,   \
                       tmp0, tmp1, tmp2, tmp3
    vhaddw.w.h   \in0,   \in0,  \in0
    vhaddw.w.h   \in1,   \in1,  \in1
    vhaddw.w.h   \in2,   \in2,  \in2
    vhaddw.w.h   \in3,   \in3,  \in3
    vhaddw.w.h   \in4,   \in4,  \in4
    vhaddw.w.h   \in5,   \in5,  \in5
    vhaddw.w.h   \in6,   \in6,  \in6
    vhaddw.w.h   \in7,   \in7,  \in7
    vpickev.h    \tmp0,  \in1,  \in0
    vpickev.h    \tmp1,  \in3,  \in2
    vpickev.h    \tmp2,  \in5,  \in4
    vpickev.h    \tmp3,  \in7,  \in6
    vhaddw.w.h   \tmp0,  \tmp0, \tmp0
    vhaddw.w.h   \tmp1,  \tmp1, \tmp1
    vhaddw.w.h   \tmp2,  \tmp2, \tmp2
    vhaddw.w.h   \tmp3,  \tmp3, \tmp3
    vpickev.h    \in0,   \tmp1, \tmp0
    vpickev.h    \in1,   \tmp3, \tmp2
    vhaddw.w.h   \in0,   \in0,  \in0
    vhaddw.w.h   \in1,   \in1,  \in1
    vpackev.h    \out0,  \in1,  \in0
.endm

function x265_interp_8tap_hv_pp_12x16_lsx
    slli.d       t7,    a4,    5
    slli.d       t8,    a5,    4
    la.local     t6,    g_lumaFilter
    la.local     t5,    h_psOffset
    vldx         vr10,  t6,    t7
    vld          vr11,  t5,    0
    addi.d       t0,    zero,  16
    alsl.d       t1,    a1,    a1,   1
    addi.d       sp,    sp,    -(24*23)-32
    sub.d        a0,    a0,    t1
    addi.d       t2,    t0,    7
    fst.d        f24,   sp,    0
    fst.d        f25,   sp,    8
    fst.d        f26,   sp,    16
    fst.d        f27,   sp,    24
    addi.d       t3,    sp,    32
    addi.d       t4,    sp,    (16*23)+32
    addi.d       t6,    t6,    128
.loop_hv_ps_12x16:
    vld          vr0,   a0,    -3
    vld          vr1,   a0,    -2
    vld          vr2,   a0,    -1
    vld          vr3,   a0,    0
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    vilvh.b      vr21,  vr1,   vr0
    vilvh.b      vr22,  vr3,   vr2
    VMULW4_H  vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    fld.d        f0,    a0,    1
    fld.d        f1,    a0,    2
    fld.d        f2,    a0,    3
    fld.d        f3,    a0,    4
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    add.d        a0,    a0,    a1
    VMULW4_H  vr4, vr5, vr10, vr10, vr12, vr13, vr14, vr15

    PROCESS_LUMA_HV vr6, vr7, vr8, vr9, vr12, vr13, vr14, vr15, \
                    vr20, vr16, vr17, vr18, vr19

    VMULW4_H vr21, vr22, vr10, vr10, vr6, vr7, vr8, vr9

    vhaddw.w.h   vr6,   vr6,   vr6
    vhaddw.w.h   vr7,   vr7,   vr7
    vhaddw.w.h   vr8,   vr8,   vr8
    vhaddw.w.h   vr9,   vr9,   vr9
    vpickev.h    vr12,  vr7,   vr6
    vpickev.h    vr13,  vr9,   vr8
    vhaddw.w.h   vr12,  vr12,  vr12
    vhaddw.w.h   vr13,  vr13,  vr13
    vpickev.h    vr14,  vr13,  vr12
    vhaddw.w.h   vr14,  vr14,  vr14
    vpickev.h    vr21,  vr11,  vr14

    vadd.h       vr20,  vr20,  vr11
    vadd.h       vr21,  vr21,  vr11
    vst          vr20,  t3,    0
    fst.d        f21,   t4,    0
    addi.d       t2,    t2,    -1
    addi.d       t3,    t3,    16
    addi.d       t4,    t4,    8
    blt          zero,  t2,    .loop_hv_ps_12x16
    add.d        t7,    t6,    t8
    vld          vr11,  t5,    32
    vldrepl.h    vr16,  t7,    0
    vldrepl.h    vr17,  t7,    2
    vldrepl.h    vr18,  t7,    4
    vldrepl.h    vr19,  t7,    6
    vldrepl.h    vr20,  t7,    8
    vldrepl.h    vr21,  t7,    10
    vldrepl.h    vr22,  t7,    12
    vldrepl.h    vr23,  t7,    14
    addi.d       t3,    sp,    128+32
    addi.d       t4,    sp,    (16*23)+32
    vld          vr0,   sp,    32   //0,0
    vld          vr1,   sp,    16+32  //1,1
    vld          vr2,   sp,    32+32  //2,2
    vld          vr3,   sp,    48+32  //3,3
    vld          vr4,   sp,    64+32  //4,4
    vld          vr5,   sp,    80+32  //5,5
    vld          vr6,   sp,    96+32  //6,6
    vld          vr7,   sp,    112+32 //7,7
.loop_hv_sp_12x16:
    vld          vr8,   t4,    0   //0,1
    vld          vr9,   t4,    16  //2,3
    vld          vr10,  t4,    32  //4,5
    vld          vr12,  t4,    48  //6,7
    vilvl.h      vr13,  vr9,   vr8  //0, 2, 0, 2
    vilvh.h      vr14,  vr9,   vr8  //1, 3, 1, 3
    vilvl.h      vr24,  vr12,  vr10 //4, 6, 4, 6
    vilvh.h      vr25,  vr12,  vr10 //5, 7, 5, 7
    vor.v        vr15,  vr11,  vr11
    vor.v        vr26,  vr11,  vr11
    vor.v        vr27,  vr11,  vr11
    vmaddwev.w.h vr15,  vr0,   vr16  //0
    vmaddwod.w.h vr26,  vr0,   vr16
    vmaddwev.w.h vr27,  vr13,  vr16
    vmaddwev.w.h vr15,  vr1,   vr17  //1
    vmaddwod.w.h vr26,  vr1,   vr17
    vmaddwev.w.h vr27,  vr14,  vr17
    vmaddwev.w.h vr15,  vr2,   vr18  //2
    vmaddwod.w.h vr26,  vr2,   vr18
    vmaddwod.w.h vr27,  vr13,  vr18
    vmaddwev.w.h vr15,  vr3,   vr19  //3
    vmaddwod.w.h vr26,  vr3,   vr19
    vmaddwod.w.h vr27,  vr14,  vr19
    vmaddwev.w.h vr15,  vr4,   vr20  //4
    vmaddwod.w.h vr26,  vr4,   vr20
    vmaddwev.w.h vr27,  vr24,  vr20
    vmaddwev.w.h vr15,  vr5,   vr21  //5
    vmaddwod.w.h vr26,  vr5,   vr21
    vmaddwev.w.h vr27,  vr25,  vr21
    vmaddwev.w.h vr15,  vr6,   vr22  //6
    vmaddwod.w.h vr26,  vr6,   vr22
    vmaddwod.w.h vr27,  vr24,  vr22
    vmaddwev.w.h vr15,  vr7,   vr23  //7
    vmaddwod.w.h vr26,  vr7,   vr23
    vmaddwod.w.h vr27,  vr25,  vr23
    vor.v        vr0,   vr1,   vr1
    vor.v        vr1,   vr2,   vr2
    vor.v        vr2,   vr3,   vr3
    vor.v        vr3,   vr4,   vr4
    vssrani.h.w  vr26,  vr15,  12
    vssrani.h.w  vr8,   vr27,  12
    vor.v        vr4,   vr5,   vr5
    vor.v        vr5,   vr6,   vr6
    vor.v        vr6,   vr7,   vr7
    vssrani.bu.h vr8,   vr26,  0
    vld          vr7,   t3,    0
    addi.d       t4,    t4,    8
    addi.d       t3,    t3,    16
    vstelm.d     vr8,   a2,    0,    0
    vstelm.w     vr8,   a2,    8,    2
    addi.d       t0,    t0,    -1
    add.d        a2,    a2,    a3
    blt          zero,  t0,    .loop_hv_sp_12x16
    fld.d        f24,   sp,    0
    fld.d        f25,   sp,    8
    fld.d        f26,   sp,    16
    fld.d        f27,   sp,    24
    addi.d       sp,    sp,    (24*23)+32
endfunc

function x265_interp_8tap_hv_pp_24x32_lsx
    slli.d       t7,    a4,    5
    slli.d       t8,    a5,    4
    la.local     t6,    g_lumaFilter
    la.local     t5,    h_psOffset
    vldx         vr10,  t6,    t7
    vld          vr11,  t5,    0
    addi.d       t2,    zero,  7 + 32
    addi.d       t0,    zero,  32
    alsl.d       t1,    a1,    a1,   1
    addi.d       t4,    zero,  39 * 48
    sub.d        a0,    a0,    t1
    sub.d        sp,    sp,    t4
    addi.d       t6,    t6,    128
    move         t7,    sp
.loop_hv_ps_24x32:
    vld          vr0,   a0,    -3
    vld          vr1,   a0,    -2
    vld          vr2,   a0,    -1
    vld          vr3,   a0,    0
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    VMULW4_H vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    vld          vr20,  a0,    1
    vld          vr21,  a0,    2
    vld          vr22,  a0,    3
    vld          vr23,  a0,    4
    vilvl.b      vr4,   vr21,  vr20
    vilvl.b      vr5,   vr23,  vr22
    VMULW4_H vr4, vr5, vr10, vr10, vr12, vr13, vr14, vr15

    PROCESS_LUMA_HV vr6, vr7, vr8, vr9, vr12, vr13, vr14, vr15, \
                    vr19, vr16, vr17, vr18, vr4

    vilvh.b      vr4,   vr1,   vr0
    vilvh.b      vr5,   vr3,   vr2
    VMULW4_H vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    vilvh.b      vr4,   vr21,  vr20
    vilvh.b      vr5,   vr23,  vr22
    VMULW4_H vr4, vr5, vr10, vr10, vr12, vr13, vr14, vr15

    PROCESS_LUMA_HV vr6, vr7, vr8, vr9, vr12, vr13, vr14, vr15, \
                    vr20, vr16, vr17, vr18, vr4

    fld.d        f0,    a0,    13
    fld.d        f1,    a0,    14
    fld.d        f2,    a0,    15
    fld.d        f3,    a0,    16
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    VMULW4_H vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    fld.d        f0,    a0,    17
    fld.d        f1,    a0,    18
    fld.d        f2,    a0,    19
    fld.d        f3,    a0,    20
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    VMULW4_H vr4, vr5, vr10, vr10, vr12, vr13, vr14, vr15

    PROCESS_LUMA_HV vr6, vr7, vr8, vr9, vr12, vr13, vr14, vr15, \
                    vr21, vr16, vr17, vr18, vr4

    vadd.h       vr19,  vr19,  vr11
    vadd.h       vr20,  vr20,  vr11
    vadd.h       vr21,  vr21,  vr11

    vst          vr19,  t7,    0
    vst          vr20,  t7,    16
    vst          vr21,  t7,    32
    addi.d       t7,    t7,    48
    addi.d       t2,    t2,    -1
    add.d        a0,    a0,    a1
    blt          zero,  t2,    .loop_hv_ps_24x32
    add.d        t6,    t6,    t8
    move         t7,    sp
    vld          vr11,  t5,    32
    vldrepl.h    vr16,  t6,    0
    vldrepl.h    vr17,  t6,    2
    vldrepl.h    vr18,  t6,    4
    vldrepl.h    vr19,  t6,    6
    vldrepl.h    vr20,  t6,    8
    vldrepl.h    vr21,  t6,    10
    vldrepl.h    vr22,  t6,    12
    vldrepl.h    vr23,  t6,    14
.loop_hv_sp_24x32:
.irp x, vr8, vr9, vr12, vr13, vr14, vr15
    vor.v        \x,    vr11,  vr11
.endr
    vld          vr0,   t7,    0
    vld          vr1,   t7,    16
    vld          vr2,   t7,    32
    vld          vr3,   t7,    0  + 48
    vld          vr4,   t7,    16 + 48
    vld          vr5,   t7,    32 + 48
    VMADD4_W vr0, vr1, vr16, vr16, vr8, vr9, vr12, vr13
    VMADD4_W vr2, vr3, vr16, vr17, vr14, vr15, vr8, vr9
    VMADD4_W vr4, vr5, vr17, vr17, vr12, vr13, vr14, vr15
    vld          vr0,   t7,    0  + 48 * 2
    vld          vr1,   t7,    16 + 48 * 2
    vld          vr2,   t7,    32 + 48 * 2
    vld          vr3,   t7,    0  + 48 * 3
    vld          vr4,   t7,    16 + 48 * 3
    vld          vr5,   t7,    32 + 48 * 3
    VMADD4_W vr0, vr1, vr18, vr18, vr8, vr9, vr12, vr13
    VMADD4_W vr2, vr3, vr18, vr19, vr14, vr15, vr8, vr9
    VMADD4_W vr4, vr5, vr19, vr19, vr12, vr13, vr14, vr15
    vld          vr0,   t7,    0  + 48 * 4
    vld          vr1,   t7,    16 + 48 * 4
    vld          vr2,   t7,    32 + 48 * 4
    vld          vr3,   t7,    0  + 48 * 5
    vld          vr4,   t7,    16 + 48 * 5
    vld          vr5,   t7,    32 + 48 * 5
    VMADD4_W vr0, vr1, vr20, vr20, vr8, vr9, vr12, vr13
    VMADD4_W vr2, vr3, vr20, vr21, vr14, vr15, vr8, vr9
    VMADD4_W vr4, vr5, vr21, vr21, vr12, vr13, vr14, vr15
    vld          vr0,   t7,    0  + 48 * 6
    vld          vr1,   t7,    16 + 48 * 6
    vld          vr2,   t7,    32 + 48 * 6
    vld          vr3,   t7,    0  + 48 * 7
    vld          vr4,   t7,    16 + 48 * 7
    vld          vr5,   t7,    32 + 48 * 7
    VMADD4_W vr0, vr1, vr22, vr22, vr8, vr9, vr12, vr13
    VMADD4_W vr2, vr3, vr22, vr23, vr14, vr15, vr8, vr9
    VMADD4_W vr4, vr5, vr23, vr23, vr12, vr13, vr14, vr15
    vssrani.h.w  vr9,   vr8,   12
    vssrani.h.w  vr13,  vr12,  12
    vssrani.h.w  vr15,  vr14,  12
    addi.d       t7,    t7,    48
    vssrani.bu.h vr13,  vr9,   0
    vssrani.bu.h vr14,  vr15,  0
    vst          vr13,  a2,    0
    vstelm.d     vr14,  a2,    16,   0
    addi.d       t0,    t0,    -1
    add.d        a2,    a2,    a3
    blt          zero,  t0,    .loop_hv_sp_24x32
    add.d        sp,    sp,    t4
endfunc

.macro FILTER_HV_PP_WxN  w, h, rep, s
function x265_interp_8tap_hv_pp_\w\()x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t8,    a5,    4
    la.local     t6,    g_lumaFilter
    la.local     t5,    h_psOffset
    addi.d       sp,    sp,    -8
    vldx         vr10,  t6,    t7
    vld          vr11,  t5,    0
    addi.d       t0,    zero,  \h
    alsl.d       t1,    a1,    a1,   1
    addi.d       t2,    t0,    7
    fst.d        f24,   sp,    0
    addi.d       t3,    zero,  \s
    mul.d        t4,    t3,    t2
    sub.d        a0,    a0,    t1
    addi.d       t6,    t6,    128
    sub.d        sp,    sp,    t4
    move         t7,    sp
.loop_hv_ps_\w\()x\h:
    move         t1,    a0
.rept \rep
    vld          vr0,   t1,    -3
    vld          vr1,   t1,    -2
    vld          vr2,   t1,    -1
    vld          vr3,   t1,    0
    vld          vr21,  t1,    1
    vld          vr22,  t1,    2
    vld          vr23,  t1,    3
    vld          vr24,  t1,    4
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    vilvl.b      vr16,  vr22,  vr21
    vilvl.b      vr17,  vr24,  vr23
    VMULW4_H vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    VMULW4_H vr16, vr17, vr10, vr10, vr12, vr13, vr14, vr15

    PROCESS_LUMA_HV vr6, vr7, vr8, vr9, vr12, vr13, vr14, vr15, \
                    vr20, vr16, vr17, vr18, vr19

    vilvh.b      vr4,   vr1,   vr0
    vilvh.b      vr5,   vr3,   vr2
    vilvh.b      vr16,  vr22,  vr21
    vilvh.b      vr17,  vr24,  vr23
    VMULW4_H vr4, vr5, vr10, vr10, vr6, vr7, vr8, vr9
    VMULW4_H vr16, vr17, vr10, vr10, vr12, vr13, vr14, vr15

    PROCESS_LUMA_HV vr6, vr7, vr8, vr9, vr12, vr13, vr14, vr15, \
                    vr21, vr16, vr17, vr18, vr19

    vadd.h       vr20,  vr20,  vr11
    vadd.h       vr21,  vr21,  vr11

    addi.d       t1,    t1,    16
    vst          vr20,  t7,    0
    vst          vr21,  t7,    16
    addi.d       t7,    t7,    32
.endr
    addi.d       t2,    t2,    -1
    add.d        a0,    a0,    a1
    blt          zero,  t2,    .loop_hv_ps_\w\()x\h
    add.d        t6,    t6,    t8
    move         t7,    sp
    vld          vr11,  t5,    32
    vldrepl.h    vr16,  t6,    0
    vldrepl.h    vr17,  t6,    2
    vldrepl.h    vr18,  t6,    4
    vldrepl.h    vr19,  t6,    6
    vldrepl.h    vr20,  t6,    8
    vldrepl.h    vr21,  t6,    10
    vldrepl.h    vr22,  t6,    12
    vldrepl.h    vr23,  t6,    14
.loop_hv_sp_\w\()x\h:
    move         t2,    a2
.rept \rep
    vor.v        vr8,   vr11,  vr11
    vor.v        vr9,   vr11,  vr11
    vor.v        vr12,  vr11,  vr11
    vor.v        vr13,  vr11,  vr11
    vld          vr0,   t7,    0
    vld          vr1,   t7,    16
    vld          vr2,   t7,    0  + \s
    vld          vr3,   t7,    16 + \s
    vld          vr4,   t7,    0  + \s * 2
    vld          vr5,   t7,    16 + \s * 2
    vld          vr6,   t7,    0  + \s * 3
    vld          vr7,   t7,    16 + \s * 3
    VMADD4_W vr0, vr1, vr16, vr16, vr8, vr9, vr12, vr13
    VMADD4_W vr2, vr3, vr17, vr17, vr8, vr9, vr12, vr13
    VMADD4_W vr4, vr5, vr18, vr18, vr8, vr9, vr12, vr13
    VMADD4_W vr6, vr7, vr19, vr19, vr8, vr9, vr12, vr13
    vld          vr0,   t7,    0  + \s * 4
    vld          vr1,   t7,    16 + \s * 4
    vld          vr2,   t7,    0  + \s * 5
    vld          vr3,   t7,    16 + \s * 5
    vld          vr4,   t7,    0  + \s * 6
    vld          vr5,   t7,    16 + \s * 6
    vld          vr6,   t7,    0  + \s * 7
    vld          vr7,   t7,    16 + \s * 7
    VMADD4_W vr0, vr1, vr20, vr20, vr8, vr9, vr12, vr13
    VMADD4_W vr2, vr3, vr21, vr21, vr8, vr9, vr12, vr13
    VMADD4_W vr4, vr5, vr22, vr22, vr8, vr9, vr12, vr13
    VMADD4_W vr6, vr7, vr23, vr23, vr8, vr9, vr12, vr13
    vssrani.h.w  vr9,   vr8,   12
    vssrani.h.w  vr13,  vr12,  12
    addi.d       t7,    t7,    32
    vssrani.bu.h vr13,  vr9,   0
    vst          vr13,  t2,    0
    addi.d       t2,    t2,    16
.endr
    addi.d       t0,    t0,    -1
    add.d        a2,    a2,    a3
    blt          zero,  t0,    .loop_hv_sp_\w\()x\h
    add.d        sp,    sp,    t4
    fld.d        f24,   sp,    0
    addi.d       sp,    sp,    8
endfunc
.endm

FILTER_HV_PP_WxN 16, 4,  1, 32
FILTER_HV_PP_WxN 16, 8,  1, 32
FILTER_HV_PP_WxN 16, 12, 1, 32
FILTER_HV_PP_WxN 16, 16, 1, 32
FILTER_HV_PP_WxN 16, 32, 1, 32
FILTER_HV_PP_WxN 16, 64, 1, 32
FILTER_HV_PP_WxN 32, 8,  2, 64
FILTER_HV_PP_WxN 32, 16, 2, 64
FILTER_HV_PP_WxN 32, 24, 2, 64
FILTER_HV_PP_WxN 32, 32, 2, 64
FILTER_HV_PP_WxN 32, 64, 2, 64
FILTER_HV_PP_WxN 48, 64, 3, 96
FILTER_HV_PP_WxN 64, 16, 4, 128
FILTER_HV_PP_WxN 64, 32, 4, 128
FILTER_HV_PP_WxN 64, 48, 4, 128
FILTER_HV_PP_WxN 64, 64, 4, 128

.macro PROCESS_LUMA_LASX in0, in1, in2, in3, in4, in5, in6, in7, out0, out1 \
                         tmp0, tmp1, tmp2, tmp3
    xvhaddw.w.h   \in0,   \in0,  \in0
    xvhaddw.w.h   \in1,   \in1,  \in1
    xvhaddw.w.h   \in2,   \in2,  \in2
    xvhaddw.w.h   \in3,   \in3,  \in3
    xvhaddw.w.h   \in4,   \in4,  \in4
    xvhaddw.w.h   \in5,   \in5,  \in5
    xvhaddw.w.h   \in6,   \in6,  \in6
    xvhaddw.w.h   \in7,   \in7,  \in7
    xvpickev.h    \tmp0,  \in1,  \in0
    xvpickev.h    \tmp1,  \in3,  \in2
    xvpickev.h    \tmp2,  \in5,  \in4
    xvpickev.h    \tmp3,  \in7,  \in6
    xvhaddw.w.h   \tmp0,  \tmp0, \tmp0
    xvhaddw.w.h   \tmp1,  \tmp1, \tmp1
    xvhaddw.w.h   \tmp2,  \tmp2, \tmp2
    xvhaddw.w.h   \tmp3,  \tmp3, \tmp3
    xvpickev.h    \in0,   \tmp1, \tmp0
    xvpickev.h    \in1,   \tmp3, \tmp2
    xvhaddw.w.h   \out0,  \in0,  \in0
    xvhaddw.w.h   \out1,  \in1,  \in1
.endm

.macro XMULW4_W  in0, in1, mul0, mul1, out0, out1, out2, out3
    xvmulwev.w.h   \out0,  \in0,  \mul0
    xvmulwod.w.h   \out1,  \in0,  \mul0
    xvmulwev.w.h   \out2,  \in1,  \mul1
    xvmulwod.w.h   \out3,  \in1,  \mul1
.endm

.macro XMADD4_W  in0, in1, mul0, mul1, out0, out1, out2, out3
    xvmaddwev.w.h   \out0,  \in0,  \mul0
    xvmaddwod.w.h   \out1,  \in0,  \mul0
    xvmaddwev.w.h   \out2,  \in1,  \mul1
    xvmaddwod.w.h   \out3,  \in1,  \mul1
.endm

.macro FILTER_HV_PP_16xN_LASX  h
function x265_interp_8tap_hv_pp_16x\h\()_lasx
    slli.d       t7,    a4,    5
    slli.d       t8,    a5,    4
    la.local     t6,    g_lumaFilter
    la.local     t5,    h_psOffset
    xvldx        xr10,  t6,    t7
    xvld         xr11,  t5,    0
    addi.d       t0,    zero,  \h
    alsl.d       t1,    a1,    a1,   1
    addi.d       t2,    t0,    7
    addi.d       t3,    zero,  32
    mul.d        t4,    t3,    t2
    sub.d        a0,    a0,    t1
    addi.d       t6,    t6,    128
    sub.d        sp,    sp,    t4
    move         t7,    sp
.loop_hv_ps_lasx_16x\h:
    vld          vr0,   a0,    -3
    vld          vr1,   a0,    -2
    vld          vr2,   a0,    -1
    vld          vr3,   a0,    0
    vld          vr20,  a0,    1
    vld          vr21,  a0,    2
    vld          vr22,  a0,    3
    vld          vr23,  a0,    4
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    vilvl.b      vr6,   vr21,  vr20
    vilvl.b      vr7,   vr23,  vr22
    vilvh.b      vr8,   vr1,   vr0
    vilvh.b      vr9,   vr3,   vr2
    vilvh.b      vr12,  vr21,  vr20
    vilvh.b      vr13,  vr23,  vr22

    xvpermi.q    xr8,   xr4,   0x20
    xvpermi.q    xr9,   xr5,   0x20
    xvpermi.q    xr12,  xr6,   0x20
    xvpermi.q    xr13,  xr7,   0x20

    XMULW4_H xr8, xr9, xr10, xr10, xr4, xr5, xr6, xr7
    XMULW4_H xr12, xr13, xr10, xr10, xr14, xr15, xr16, xr17

    PROCESS_LUMA_LASX xr4, xr5, xr6, xr7, xr14, xr15, xr16, xr17, \
                      xr20, xr21, xr4, xr5, xr6, xr7

    xvpackev.h   xr0,   xr21,  xr20
    xvadd.h      xr2,   xr0,   xr11

    xvst         xr2,   t7,    0
    addi.d       t7,    t7,    32
    addi.d       t2,    t2,    -1
    add.d        a0,    a0,    a1
    blt          zero,  t2,    .loop_hv_ps_lasx_16x\h
    add.d        t6,    t6,    t8
    slli.d       t2,    a3,    1
    move         t7,    sp
    xvld         xr11,  t5,    32
    xvldrepl.h   xr16,  t6,    0
    xvldrepl.h   xr17,  t6,    2
    xvldrepl.h   xr18,  t6,    4
    xvldrepl.h   xr19,  t6,    6
    xvldrepl.h   xr20,  t6,    8
    xvldrepl.h   xr21,  t6,    10
    xvldrepl.h   xr22,  t6,    12
    xvldrepl.h   xr23,  t6,    14
.loop_hv_sp_lasx_16x\h:
    xvor.v       xr12,  xr11,  xr11
    xvor.v       xr13,  xr11,  xr11
    xvor.v       xr14,  xr11,  xr11
    xvor.v       xr15,  xr11,  xr11
    xvld         xr0,   t7,    0
    xvld         xr1,   t7,    32 * 1
    xvld         xr2,   t7,    32 * 2
    xvld         xr3,   t7,    32 * 3
    xvld         xr4,   t7,    32 * 4
    xvld         xr5,   t7,    32 * 5
    xvld         xr6,   t7,    32 * 6
    xvld         xr7,   t7,    32 * 7
    xvld         xr8,   t7,    32 * 8
    XMADD4_W xr0, xr1, xr16, xr16, xr12, xr13, xr14, xr15
    XMADD4_W xr1, xr2, xr17, xr17, xr12, xr13, xr14, xr15
    XMADD4_W xr2, xr3, xr18, xr18, xr12, xr13, xr14, xr15
    XMADD4_W xr3, xr4, xr19, xr19, xr12, xr13, xr14, xr15
    XMADD4_W xr4, xr5, xr20, xr20, xr12, xr13, xr14, xr15
    XMADD4_W xr5, xr6, xr21, xr21, xr12, xr13, xr14, xr15
    XMADD4_W xr6, xr7, xr22, xr22, xr12, xr13, xr14, xr15
    XMADD4_W xr7, xr8, xr23, xr23, xr12, xr13, xr14, xr15
    xvssrani.h.w  xr13,  xr12,  12
    xvssrani.h.w  xr15,  xr14,  12
    addi.d        t7,    t7,    64
    xvssrani.bu.h xr15,  xr13,  0
    addi.d        t0,    t0,    -2
    xvpermi.d     xr13,  xr15,  0xD8
    xvpermi.d     xr14,  xr15,  0x8D
    vst           vr13,  a2,    0
    vstx          vr14,  a2,    a3
    add.d         a2,    a2,    t2
    blt           zero,  t0,    .loop_hv_sp_lasx_16x\h
    add.d         sp,    sp,    t4
endfunc
.endm

FILTER_HV_PP_16xN_LASX  4
FILTER_HV_PP_16xN_LASX  8
FILTER_HV_PP_16xN_LASX  12
FILTER_HV_PP_16xN_LASX  16
FILTER_HV_PP_16xN_LASX  32
FILTER_HV_PP_16xN_LASX  64

function x265_interp_8tap_hv_pp_24x32_lasx
    slli.d       t7,    a4,    5
    slli.d       t8,    a5,    4
    la.local     t6,    g_lumaFilter
    la.local     t5,    h_psOffset
    xvldx        xr10,  t6,    t7
    xvld         xr11,  t5,    0
    addi.d       t0,    zero,  32
    alsl.d       t1,    a1,    a1,   1
    addi.d       t2,    t0,    7
    addi.d       t3,    zero,  48
    mul.d        t4,    t3,    t2
    sub.d        a0,    a0,    t1
    addi.d       t6,    t6,    128
    sub.d        sp,    sp,    t4
    move         t7,    sp
.loop_hv_ps_lasx_24x32:
    xvld         xr0,   a0,    -3
    xvld         xr1,   a0,    -2
    xvld         xr2,   a0,    -1
    xvld         xr3,   a0,    0
    xvld         xr20,  a0,    1
    xvld         xr21,  a0,    2
    xvld         xr22,  a0,    3
    xvld         xr23,  a0,    4
    xvilvl.b     xr4,   xr1,   xr0
    xvilvl.b     xr5,   xr3,   xr2
    xvilvl.b     xr6,   xr21,  xr20
    xvilvl.b     xr7,   xr23,  xr22
    xvilvh.b     xr8,   xr1,   xr0
    xvilvh.b     xr9,   xr3,   xr2
    xvilvh.b     xr12,  xr21,  xr20
    xvilvh.b     xr13,  xr23,  xr22

    xvpermi.q    xr12,  xr8,   0x20
    xvpermi.q    xr13,  xr9,   0x20
    XMULW4_H xr4, xr5, xr10, xr10, xr0, xr1, xr2, xr3
    XMULW4_H xr6, xr7, xr10, xr10, xr14, xr15, xr16, xr17

    PROCESS_LUMA_LASX xr0, xr1, xr2, xr3, xr14, xr15, xr16, xr17, \
                      xr20, xr21, xr4, xr5, xr6, xr7

    XMULW4_H xr12, xr13, xr10, xr10, xr14, xr15, xr16, xr17
.irp x, xr14, xr15, xr16, xr17
    xvhaddw.w.h  \x,    \x,    \x
.endr
    xvpickev.h   xr4,   xr15,  xr14
    xvpickev.h   xr5,   xr17,  xr16
    xvhaddw.w.h  xr4,   xr4,   xr4
    xvhaddw.w.h  xr5,   xr5,   xr5
    xvpickev.h   xr6,   xr5,   xr4
    xvhaddw.w.h  xr22,  xr6,   xr6
    xvpermi.d    xr0,   xr20,  0x4E
    xvpermi.d    xr1,   xr21,  0x4E
    xvpermi.q    xr20,  xr22,  0x2
    xvpermi.q    xr21,  xr22,  0x12

    xvpackev.h   xr2,   xr21,  xr20
    vpickev.h    vr3,   vr1,   vr0

    xvadd.h      xr4,   xr2,   xr11
    xvadd.h      xr5,   xr3,   xr11

    xvst         xr4,   t7,    0
    vst          vr5,   t7,    32
    addi.d       t7,    t7,    48
    addi.d       t2,    t2,    -1
    add.d        a0,    a0,    a1
    blt          zero,  t2,    .loop_hv_ps_lasx_24x32
    add.d        t6,    t6,    t8
    move         t7,    sp
    xvld         xr11,  t5,    32
    xvldrepl.h   xr16,  t6,    0
    xvldrepl.h   xr17,  t6,    2
    xvldrepl.h   xr18,  t6,    4
    xvldrepl.h   xr19,  t6,    6
    xvldrepl.h   xr20,  t6,    8
    xvldrepl.h   xr21,  t6,    10
    xvldrepl.h   xr22,  t6,    12
    xvldrepl.h   xr23,  t6,    14
.loop_hv_sp_lasx_24x32:
    xvor.v       xr8,   xr11,  xr11
    xvor.v       xr9,   xr11,  xr11
    xvor.v       xr12,  xr11,  xr11
    xvld         xr0,   t7,    0
    vld          vr1,   t7,    32
    xvld         xr2,   t7,    0  + 48
    vld          vr3,   t7,    32 + 48
    xvld         xr4,   t7,    0  + 48 * 2
    vld          vr5,   t7,    32 + 48 * 2
    xvld         xr6,   t7,    0  + 48 * 3
    vld          vr7,   t7,    32 + 48 * 3
.irp x, xr1, xr3, xr5, xr7
    xvpermi.d    \x,    \x,    0xD8
.endr
    xvilvl.h     xr13,  xr3,   xr1
    xvilvl.h     xr14,  xr7,   xr5

    xvmaddwev.w.h xr8,  xr0,   xr16
    xvmaddwod.w.h xr9,  xr0,   xr16
    xvmaddwev.w.h xr12, xr13,  xr16
    xvmaddwev.w.h xr8,  xr2,   xr17
    xvmaddwod.w.h xr9,  xr2,   xr17
    xvmaddwod.w.h xr12, xr13,  xr17
    xvmaddwev.w.h xr8,  xr4,   xr18
    xvmaddwod.w.h xr9,  xr4,   xr18
    xvmaddwev.w.h xr12, xr14,  xr18
    xvmaddwev.w.h xr8,  xr6,   xr19
    xvmaddwod.w.h xr9,  xr6,   xr19
    xvmaddwod.w.h xr12, xr14,  xr19

    xvld         xr0,   t7,    0  + 48 * 4
    vld          vr1,   t7,    32 + 48 * 4
    xvld         xr2,   t7,    0  + 48 * 5
    vld          vr3,   t7,    32 + 48 * 5
    xvld         xr4,   t7,    0  + 48 * 6
    vld          vr5,   t7,    32 + 48 * 6
    xvld         xr6,   t7,    0  + 48 * 7
    vld          vr7,   t7,    32 + 48 * 7
.irp x, xr1, xr3, xr5, xr7
    xvpermi.d    \x,    \x,    0xD8
.endr
    xvilvl.h     xr13,  xr3,   xr1
    xvilvl.h     xr14,  xr7,   xr5

    xvmaddwev.w.h xr8,  xr0,   xr20
    xvmaddwod.w.h xr9,  xr0,   xr20
    xvmaddwev.w.h xr12, xr13,  xr20
    xvmaddwev.w.h xr8,  xr2,   xr21
    xvmaddwod.w.h xr9,  xr2,   xr21
    xvmaddwod.w.h xr12, xr13,  xr21
    xvmaddwev.w.h xr8,  xr4,   xr22
    xvmaddwod.w.h xr9,  xr4,   xr22
    xvmaddwev.w.h xr12, xr14,  xr22
    xvmaddwev.w.h xr8,  xr6,   xr23
    xvmaddwod.w.h xr9,  xr6,   xr23
    xvmaddwod.w.h xr12, xr14,  xr23

    xvpermi.d     xr13,  xr12,  0x4E
    xvssrani.h.w  xr9,   xr8,   12
    xvssrani.h.w  xr13,  xr12,  12
    addi.d        t7,    t7,    48
    xvssrani.bu.h xr13,  xr9,   0
    addi.d        t0,    t0,    -1
    xvpermi.d     xr14,  xr13,  0xD8
    vst           vr14,  a2,    0
    xvstelm.d     xr14,  a2,    16,  2
    add.d         a2,    a2,    a3
    blt           zero,  t0,    .loop_hv_sp_lasx_24x32
    add.d         sp,    sp,    t4
endfunc

function x265_interp_8tap_hv_pp_48x64_lasx
    slli.d       t7,    a4,    5
    slli.d       t8,    a5,    4
    la.local     t6,    g_lumaFilter
    la.local     t5,    h_psOffset
    xvldx        xr10,  t6,    t7
    xvld         xr11,  t5,    0
    addi.d       t0,    zero,  64
    alsl.d       t1,    a1,    a1,   1
    addi.d       t2,    t0,    7
    addi.d       t3,    zero,  96
    mul.d        t4,    t3,    t2
    sub.d        a0,    a0,    t1
    addi.d       t6,    t6,    128
    sub.d        sp,    sp,    t4
    move         t7,    sp
.loop_hv_ps_lasx_48x64:
    xvld         xr0,   a0,    -3
    xvld         xr1,   a0,    -2
    xvld         xr2,   a0,    -1
    xvld         xr3,   a0,    0
    xvld         xr20,  a0,    1
    xvld         xr21,  a0,    2
    xvld         xr22,  a0,    3
    xvld         xr23,  a0,    4
    xvilvl.b     xr4,   xr1,   xr0
    xvilvl.b     xr5,   xr3,   xr2
    xvilvl.b     xr6,   xr21,  xr20
    xvilvl.b     xr7,   xr23,  xr22
    xvilvh.b     xr8,   xr1,   xr0
    xvilvh.b     xr9,   xr3,   xr2
    xvilvh.b     xr12,  xr21,  xr20
    xvilvh.b     xr13,  xr23,  xr22

    XMULW4_H xr4, xr5, xr10, xr10, xr0, xr1, xr2, xr3
    XMULW4_H xr6, xr7, xr10, xr10, xr14, xr15, xr16, xr17

    PROCESS_LUMA_LASX xr0, xr1, xr2, xr3, xr14, xr15, xr16, xr17, \
                      xr20, xr21, xr4, xr5, xr6, xr7

    XMULW4_H xr8, xr9, xr10, xr10, xr0, xr1, xr2, xr3
    XMULW4_H xr12, xr13, xr10, xr10, xr14, xr15, xr16, xr17

    PROCESS_LUMA_LASX xr0, xr1, xr2, xr3, xr14, xr15, xr16, xr17, \
                      xr22, xr23, xr4, xr5, xr6, xr7

    xvpackev.h   xr0,   xr21,  xr20
    xvpackev.h   xr1,   xr23,  xr22
    xvadd.h      xr2,   xr0,   xr11
    xvadd.h      xr3,   xr1,   xr11
    xvor.v       xr4,   xr2,   xr2
    xvpermi.q    xr2,   xr3,   0x2
    xvpermi.q    xr4,   xr3,   0x13

    xvst         xr2,   t7,    0
    xvst         xr4,   t7,    32

    vld          vr0,   a0,    29
    vld          vr1,   a0,    30
    vld          vr2,   a0,    31
    vld          vr3,   a0,    32
    vld          vr20,  a0,    33
    vld          vr21,  a0,    34
    vld          vr22,  a0,    35
    vld          vr23,  a0,    36
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    vilvl.b      vr6,   vr21,  vr20
    vilvl.b      vr7,   vr23,  vr22
    vilvh.b      vr8,   vr1,   vr0
    vilvh.b      vr9,   vr3,   vr2
    vilvh.b      vr12,  vr21,  vr20
    vilvh.b      vr13,  vr23,  vr22

    xvpermi.q    xr8,   xr4,   0x20
    xvpermi.q    xr9,   xr5,   0x20
    xvpermi.q    xr12,  xr6,   0x20
    xvpermi.q    xr13,  xr7,   0x20

    XMULW4_H xr8, xr9, xr10, xr10, xr4, xr5, xr6, xr7
    XMULW4_H xr12, xr13, xr10, xr10, xr14, xr15, xr16, xr17

    PROCESS_LUMA_LASX xr4, xr5, xr6, xr7, xr14, xr15, xr16, xr17, \
                      xr20, xr21, xr4, xr5, xr6, xr7

    xvpackev.h   xr0,   xr21,  xr20
    xvadd.h      xr2,   xr0,   xr11

    xvst         xr2,   t7,    64
    addi.d       t7,    t7,    96
    addi.d       t2,    t2,    -1
    add.d        a0,    a0,    a1
    blt          zero,  t2,    .loop_hv_ps_lasx_48x64
    add.d        t6,    t6,    t8
    move         t7,    sp
    xvld         xr11,  t5,    32
    xvldrepl.h   xr16,  t6,    0
    xvldrepl.h   xr17,  t6,    2
    xvldrepl.h   xr18,  t6,    4
    xvldrepl.h   xr19,  t6,    6
    xvldrepl.h   xr20,  t6,    8
    xvldrepl.h   xr21,  t6,    10
    xvldrepl.h   xr22,  t6,    12
    xvldrepl.h   xr23,  t6,    14
.loop_hv_sp_lasx_48x64:
.irp x, xr8, xr9, xr12, xr13, xr14, xr15
    xvor.v       \x,    xr11,  xr11
.endr
    xvld         xr0,   t7,    0
    xvld         xr1,   t7,    32
    xvld         xr2,   t7,    64
    xvld         xr3,   t7,    0  + 96
    xvld         xr4,   t7,    32 + 96
    xvld         xr5,   t7,    64 + 96
    XMADD4_W xr0, xr1, xr16, xr16, xr8, xr9, xr12, xr13
    xvmaddwev.w.h xr14,  xr2,  xr16
    xvmaddwod.w.h xr15,  xr2,  xr16
    XMADD4_W xr3, xr4, xr17, xr17, xr8, xr9, xr12, xr13
    xvmaddwev.w.h xr14,  xr5,  xr17
    xvmaddwod.w.h xr15,  xr5,  xr17
    xvld         xr0,   t7,    0  + 96 * 2
    xvld         xr1,   t7,    32 + 96 * 2
    xvld         xr2,   t7,    64 + 96 * 2
    xvld         xr3,   t7,    0  + 96 * 3
    xvld         xr4,   t7,    32 + 96 * 3
    xvld         xr5,   t7,    64 + 96 * 3
    XMADD4_W xr0, xr1, xr18, xr18, xr8, xr9, xr12, xr13
    xvmaddwev.w.h xr14,  xr2,  xr18
    xvmaddwod.w.h xr15,  xr2,  xr18
    XMADD4_W xr3, xr4, xr19, xr19, xr8, xr9, xr12, xr13
    xvmaddwev.w.h xr14,  xr5,  xr19
    xvmaddwod.w.h xr15,  xr5,  xr19
    xvld         xr0,   t7,    0  + 96 * 4
    xvld         xr1,   t7,    32 + 96 * 4
    xvld         xr2,   t7,    64 + 96 * 4
    xvld         xr3,   t7,    0  + 96 * 5
    xvld         xr4,   t7,    32 + 96 * 5
    xvld         xr5,   t7,    64 + 96 * 5
    XMADD4_W xr0, xr1, xr20, xr20, xr8, xr9, xr12, xr13
    xvmaddwev.w.h xr14,  xr2,  xr20
    xvmaddwod.w.h xr15,  xr2,  xr20
    XMADD4_W xr3, xr4, xr21, xr21, xr8, xr9, xr12, xr13
    xvmaddwev.w.h xr14,  xr5,  xr21
    xvmaddwod.w.h xr15,  xr5,  xr21
    xvld         xr0,   t7,    0  + 96 * 6
    xvld         xr1,   t7,    32 + 96 * 6
    xvld         xr2,   t7,    64 + 96 * 6
    xvld         xr3,   t7,    0  + 96 * 7
    xvld         xr4,   t7,    32 + 96 * 7
    xvld         xr5,   t7,    64 + 96 * 7
    XMADD4_W xr0, xr1, xr22, xr22, xr8, xr9, xr12, xr13
    xvmaddwev.w.h xr14,  xr2,  xr22
    xvmaddwod.w.h xr15,  xr2,  xr22
    XMADD4_W xr3, xr4, xr23, xr23, xr8, xr9, xr12, xr13
    xvmaddwev.w.h xr14,  xr5,  xr23
    xvmaddwod.w.h xr15,  xr5,  xr23

    xvssrani.h.w  xr9,   xr8,  12
    xvssrani.h.w  xr13,  xr12, 12
    xvssrani.h.w  xr15,  xr14, 12

    xvssrani.bu.h xr13,  xr9,   0
    xvssrani.bu.h xr7,   xr15,  0
    xvpermi.d     xr8,   xr13,  0xD8
    xvpermi.d     xr9,   xr7,   0xD8
    xvst          xr8,   a2,    0
    vst           vr9,   a2,    32
    addi.d        t0,    t0,    -1
    addi.d        t7,    t7,    96
    add.d         a2,    a2,    a3
    blt           zero,  t0,    .loop_hv_sp_lasx_48x64
    add.d         sp,    sp,    t4
endfunc

.macro FILTER_HV_PP_WxN_LASX  w, h, rep, s
function x265_interp_8tap_hv_pp_\w\()x\h\()_lasx
    slli.d       t7,    a4,    5
    slli.d       t8,    a5,    4
    la.local     t6,    g_lumaFilter
    la.local     t5,    h_psOffset
    xvldx        xr10,  t6,    t7
    xvld         xr11,  t5,    0
    addi.d       t0,    zero,  \h
    alsl.d       t1,    a1,    a1,   1
    addi.d       t2,    t0,    7
    addi.d       t3,    zero,  \s
    mul.d        t4,    t3,    t2
    sub.d        a0,    a0,    t1
    addi.d       t6,    t6,    128
    sub.d        sp,    sp,    t4
    move         t7,    sp
.loop_hv_ps_lasx_\w\()x\h:
    move         t1,    a0
.rept \rep
    xvld         xr0,   t1,    -3
    xvld         xr1,   t1,    -2
    xvld         xr2,   t1,    -1
    xvld         xr3,   t1,    0
    xvld         xr20,  t1,    1
    xvld         xr21,  t1,    2
    xvld         xr22,  t1,    3
    xvld         xr23,  t1,    4
    xvilvl.b     xr4,   xr1,   xr0
    xvilvl.b     xr5,   xr3,   xr2
    xvilvl.b     xr6,   xr21,  xr20
    xvilvl.b     xr7,   xr23,  xr22
    xvilvh.b     xr8,   xr1,   xr0
    xvilvh.b     xr9,   xr3,   xr2
    xvilvh.b     xr12,  xr21,  xr20
    xvilvh.b     xr13,  xr23,  xr22

    XMULW4_H xr4, xr5, xr10, xr10, xr0, xr1, xr2, xr3
    XMULW4_H xr6, xr7, xr10, xr10, xr14, xr15, xr16, xr17

    PROCESS_LUMA_LASX xr0, xr1, xr2, xr3, xr14, xr15, xr16, xr17, \
                      xr20, xr21, xr4, xr5, xr6, xr7

    XMULW4_H xr8, xr9, xr10, xr10, xr0, xr1, xr2, xr3
    XMULW4_H xr12, xr13, xr10, xr10, xr14, xr15, xr16, xr17

    PROCESS_LUMA_LASX xr0, xr1, xr2, xr3, xr14, xr15, xr16, xr17, \
                      xr22, xr23, xr4, xr5, xr6, xr7

    xvpackev.h   xr0,   xr21,  xr20
    xvpackev.h   xr1,   xr23,  xr22
    xvadd.h      xr2,   xr0,   xr11
    xvadd.h      xr3,   xr1,   xr11
    xvor.v       xr4,   xr2,   xr2
    xvpermi.q    xr2,   xr3,   0x2
    xvpermi.q    xr4,   xr3,   0x13

    addi.d       t1,    t1,    32
    xvst         xr2,   t7,    0
    xvst         xr4,   t7,    32
    addi.d       t7,    t7,    64
.endr
    addi.d       t2,    t2,    -1
    add.d        a0,    a0,    a1
    blt          zero,  t2,    .loop_hv_ps_lasx_\w\()x\h
    add.d        t6,    t6,    t8
    move         t7,    sp
    xvld         xr11,  t5,    32
    xvldrepl.h   xr16,  t6,    0
    xvldrepl.h   xr17,  t6,    2
    xvldrepl.h   xr18,  t6,    4
    xvldrepl.h   xr19,  t6,    6
    xvldrepl.h   xr20,  t6,    8
    xvldrepl.h   xr21,  t6,    10
    xvldrepl.h   xr22,  t6,    12
    xvldrepl.h   xr23,  t6,    14
.loop_hv_sp_lasx_\w\()x\h:
    move         t2,    a2
.rept \rep
    xvor.v       xr8,   xr11,  xr11
    xvor.v       xr9,   xr11,  xr11
    xvor.v       xr12,  xr11,  xr11
    xvor.v       xr13,  xr11,  xr11
    xvld         xr0,   t7,    0
    xvld         xr1,   t7,    32
    xvld         xr2,   t7,    0  + \s
    xvld         xr3,   t7,    32 + \s
    xvld         xr4,   t7,    0  + \s * 2
    xvld         xr5,   t7,    32 + \s * 2
    xvld         xr6,   t7,    0  + \s * 3
    xvld         xr7,   t7,    32 + \s * 3
    XMADD4_W xr0, xr1, xr16, xr16, xr8, xr9, xr12, xr13
    XMADD4_W xr2, xr3, xr17, xr17, xr8, xr9, xr12, xr13
    XMADD4_W xr4, xr5, xr18, xr18, xr8, xr9, xr12, xr13
    XMADD4_W xr6, xr7, xr19, xr19, xr8, xr9, xr12, xr13
    xvld         xr0,   t7,    0  + \s * 4
    xvld         xr1,   t7,    32 + \s * 4
    xvld         xr2,   t7,    0  + \s * 5
    xvld         xr3,   t7,    32 + \s * 5
    xvld         xr4,   t7,    0  + \s * 6
    xvld         xr5,   t7,    32 + \s * 6
    xvld         xr6,   t7,    0  + \s * 7
    xvld         xr7,   t7,    32 + \s * 7
    XMADD4_W xr0, xr1, xr20, xr20, xr8, xr9, xr12, xr13
    XMADD4_W xr2, xr3, xr21, xr21, xr8, xr9, xr12, xr13
    XMADD4_W xr4, xr5, xr22, xr22, xr8, xr9, xr12, xr13
    XMADD4_W xr6, xr7, xr23, xr23, xr8, xr9, xr12, xr13
    xvssrani.h.w  xr9,   xr8,   12
    xvssrani.h.w  xr13,  xr12,  12
    addi.d        t7,    t7,    64
    xvssrani.bu.h xr13,  xr9,   0
    xvpermi.d     xr14,  xr13,  0xD8
    xvst          xr14,  t2,    0
    addi.d        t2,    t2,    32
.endr
    addi.d        t0,    t0,    -1
    add.d         a2,    a2,    a3
    blt           zero,  t0,    .loop_hv_sp_lasx_\w\()x\h
    add.d         sp,    sp,    t4
endfunc
.endm

FILTER_HV_PP_WxN_LASX 32, 8,  1, 64
FILTER_HV_PP_WxN_LASX 32, 16, 1, 64
FILTER_HV_PP_WxN_LASX 32, 24, 1, 64
FILTER_HV_PP_WxN_LASX 32, 32, 1, 64
FILTER_HV_PP_WxN_LASX 32, 64, 1, 64
FILTER_HV_PP_WxN_LASX 64, 16, 2, 128
FILTER_HV_PP_WxN_LASX 64, 32, 2, 128
FILTER_HV_PP_WxN_LASX 64, 48, 2, 128
FILTER_HV_PP_WxN_LASX 64, 64, 2, 128

.macro FILTER_HORIZ_LUMA_16xN_LASX  h
function x265_interp_8tap_horiz_pp_16x\h\()_lasx
    slli.d       t7,    a4,    5
    la.local     t6,    g_lumaFilter
    xvldx        xr10,  t6,    t7
    addi.d       t0,    zero,  \h
.loopH_lasx_16x\h:
    vld          vr0,   a0,    -3
    vld          vr1,   a0,    -2
    vld          vr2,   a0,    -1
    vld          vr3,   a0,    0
    vld          vr20,  a0,    1
    vld          vr21,  a0,    2
    vld          vr22,  a0,    3
    vld          vr23,  a0,    4
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    vilvl.b      vr6,   vr21,  vr20
    vilvl.b      vr7,   vr23,  vr22
    vilvh.b      vr8,   vr1,   vr0
    vilvh.b      vr9,   vr3,   vr2
    vilvh.b      vr12,  vr21,  vr20
    vilvh.b      vr13,  vr23,  vr22

    xvpermi.q    xr8,   xr4,   0x20
    xvpermi.q    xr9,   xr5,   0x20
    xvpermi.q    xr12,  xr6,   0x20
    xvpermi.q    xr13,  xr7,   0x20

    XMULW4_H xr8, xr9, xr10, xr10, xr4, xr5, xr6, xr7
    XMULW4_H xr12, xr13, xr10, xr10, xr14, xr15, xr16, xr17

    PROCESS_LUMA_LASX xr4, xr5, xr6, xr7, xr14, xr15, xr16, xr17, \
                      xr20, xr21, xr4, xr5, xr6, xr7

    xvpickev.h     xr0,  xr21,  xr20
    xvssrarni.bu.h xr1,  xr0,   6
    addi.d         t0,   t0,    -1
    xvpermi.d      xr2,  xr1,   0xD8
    add.d          a0,   a0,    a1
    vst            vr2,  a2,    0
    add.d          a2,   a2,    a3
    blt            zero, t0,    .loopH_lasx_16x\h
endfunc
.endm

FILTER_HORIZ_LUMA_16xN_LASX 4
FILTER_HORIZ_LUMA_16xN_LASX 8
FILTER_HORIZ_LUMA_16xN_LASX 12
FILTER_HORIZ_LUMA_16xN_LASX 16
FILTER_HORIZ_LUMA_16xN_LASX 32
FILTER_HORIZ_LUMA_16xN_LASX 64

function x265_interp_8tap_horiz_pp_24x32_lasx
    slli.d       t7,    a4,    5
    la.local     t6,    g_lumaFilter
    xvldx        xr10,  t6,    t7
    addi.d       t0,    zero,  32
.loopH_lasx_24x32:
    xvld          xr0,   a0,    -3
    xvld          xr1,   a0,    -2
    xvld          xr2,   a0,    -1
    xvld          xr3,   a0,    0
    xvld          xr20,  a0,    1
    xvld          xr21,  a0,    2
    xvld          xr22,  a0,    3
    xvld          xr23,  a0,    4
    xvilvl.b      xr4,   xr1,   xr0
    xvilvl.b      xr5,   xr3,   xr2
    xvilvl.b      xr6,   xr21,  xr20
    xvilvl.b      xr7,   xr23,  xr22
    xvilvh.b      xr8,   xr1,   xr0
    xvilvh.b      xr9,   xr3,   xr2
    xvilvh.b      xr12,  xr21,  xr20
    xvilvh.b      xr13,  xr23,  xr22

    xvpermi.q    xr12,  xr8,   0x20
    xvpermi.q    xr13,  xr9,   0x20

    XMULW4_H xr4, xr5, xr10, xr10, xr0, xr1, xr2, xr3
    XMULW4_H xr6, xr7, xr10, xr10, xr14, xr15, xr16, xr17

    PROCESS_LUMA_LASX xr0, xr1, xr2, xr3, xr14, xr15, xr16, xr17, \
                      xr20, xr21, xr4, xr5, xr6, xr7

    XMULW4_H xr12, xr13, xr10, xr10, xr14, xr15, xr16, xr17
.irp x, xr14, xr15, xr16, xr17
    xvhaddw.w.h  \x,    \x,    \x
.endr
    xvpickev.h   xr4,   xr15,  xr14
    xvpickev.h   xr5,   xr17,  xr16
    xvhaddw.w.h  xr4,   xr4,   xr4
    xvhaddw.w.h  xr5,   xr5,   xr5
    xvpickev.h   xr6,   xr5,   xr4
    xvhaddw.w.h  xr22,  xr6,   xr6
    xvpermi.d    xr0,   xr22,  0x4E

    xvpickev.h   xr2,   xr21,  xr20
    vpickev.h    vr3,   vr0,   vr22

    xvssrarni.bu.h xr3,  xr2,   6
    addi.d         t0,   t0,    -1
    add.d          a0,   a0,    a1
    vst            vr3,  a2,    0
    xvstelm.d      xr3,  a2,    16,  2
    add.d          a2,   a2,    a3
    blt            zero, t0,    .loopH_lasx_24x32
endfunc

function x265_interp_8tap_horiz_pp_48x64_lasx
    slli.d       t7,    a4,    5
    la.local     t6,    g_lumaFilter
    xvldx        xr10,  t6,    t7
    addi.d       t0,    zero,  64
.loopH_lasx_48x64:
    xvld         xr0,   a0,    -3
    xvld         xr1,   a0,    -2
    xvld         xr2,   a0,    -1
    xvld         xr3,   a0,    0
    xvld         xr20,  a0,    1
    xvld         xr21,  a0,    2
    xvld         xr22,  a0,    3
    xvld         xr23,  a0,    4
    xvilvl.b     xr4,   xr1,   xr0
    xvilvl.b     xr5,   xr3,   xr2
    xvilvl.b     xr6,   xr21,  xr20
    xvilvl.b     xr7,   xr23,  xr22
    xvilvh.b     xr8,   xr1,   xr0
    xvilvh.b     xr9,   xr3,   xr2
    xvilvh.b     xr12,  xr21,  xr20
    xvilvh.b     xr13,  xr23,  xr22

    XMULW4_H xr4, xr5, xr10, xr10, xr0, xr1, xr2, xr3
    XMULW4_H xr6, xr7, xr10, xr10, xr14, xr15, xr16, xr17

    PROCESS_LUMA_LASX xr0, xr1, xr2, xr3, xr14, xr15, xr16, xr17, \
                      xr20, xr21, xr4, xr5, xr6, xr7

    XMULW4_H xr8, xr9, xr10, xr10, xr0, xr1, xr2, xr3
    XMULW4_H xr12, xr13, xr10, xr10, xr14, xr15, xr16, xr17

    PROCESS_LUMA_LASX xr0, xr1, xr2, xr3, xr14, xr15, xr16, xr17, \
                      xr22, xr23, xr4, xr5, xr6, xr7

    xvpickev.h     xr0,  xr21,  xr20
    xvpickev.h     xr1,  xr23,  xr22

    xvssrarni.bu.h xr1,  xr0,   6
    addi.d         t0,   t0,    -1
    xvst           xr1,  a2,    0

    vld            vr0,  a0,    29
    vld            vr1,  a0,    30
    vld            vr2,  a0,    31
    vld            vr3,  a0,    32
    vld            vr20, a0,    33
    vld            vr21, a0,    34
    vld            vr22, a0,    35
    vld            vr23, a0,    36
    vilvl.b        vr4,  vr1,   vr0
    vilvl.b        vr5,  vr3,   vr2
    vilvl.b        vr6,  vr21,  vr20
    vilvl.b        vr7,  vr23,  vr22
    vilvh.b        vr8,  vr1,   vr0
    vilvh.b        vr9,  vr3,   vr2
    vilvh.b        vr12, vr21,  vr20
    vilvh.b        vr13, vr23,  vr22

    xvpermi.q      xr8,  xr4,   0x20
    xvpermi.q      xr9,  xr5,   0x20
    xvpermi.q      xr12, xr6,   0x20
    xvpermi.q      xr13, xr7,   0x20

    XMULW4_H xr8, xr9, xr10, xr10, xr4, xr5, xr6, xr7
    XMULW4_H xr12, xr13, xr10, xr10, xr14, xr15, xr16, xr17

    PROCESS_LUMA_LASX xr4, xr5, xr6, xr7, xr14, xr15, xr16, xr17, \
                      xr20, xr21, xr4, xr5, xr6, xr7
    xvpickev.h     xr0,  xr21,  xr20
    xvssrarni.bu.h xr1,  xr0,   6
    add.d          a0,   a0,    a1
    xvpermi.d      xr2,  xr1,   0xD8
    vst            vr2,  a2,    32
    add.d          a2,   a2,    a3
    blt            zero, t0,    .loopH_lasx_48x64
endfunc

.macro FILTER_HORIZ_LUMA_WxN_LASX  w, h, rep
function x265_interp_8tap_horiz_pp_\w\()x\h\()_lasx
    slli.d       t7,    a4,    5
    la.local     t6,    g_lumaFilter
    xvldx        xr10,  t6,    t7
    addi.d       t0,    zero,  \h
.loopH_lasx_\w\()x\h:
    move         t1,    a0
    move         t2,    a2
.rept \rep
    xvld         xr0,   t1,    -3
    xvld         xr1,   t1,    -2
    xvld         xr2,   t1,    -1
    xvld         xr3,   t1,    0
    xvld         xr20,  t1,    1
    xvld         xr21,  t1,    2
    xvld         xr22,  t1,    3
    xvld         xr23,  t1,    4
    xvilvl.b     xr4,   xr1,   xr0
    xvilvl.b     xr5,   xr3,   xr2
    xvilvl.b     xr6,   xr21,  xr20
    xvilvl.b     xr7,   xr23,  xr22
    xvilvh.b     xr8,   xr1,   xr0
    xvilvh.b     xr9,   xr3,   xr2
    xvilvh.b     xr12,  xr21,  xr20
    xvilvh.b     xr13,  xr23,  xr22

    XMULW4_H xr4, xr5, xr10, xr10, xr0, xr1, xr2, xr3
    XMULW4_H xr6, xr7, xr10, xr10, xr14, xr15, xr16, xr17

    PROCESS_LUMA_LASX xr0, xr1, xr2, xr3, xr14, xr15, xr16, xr17, \
                      xr20, xr21, xr4, xr5, xr6, xr7

    XMULW4_H xr8, xr9, xr10, xr10, xr0, xr1, xr2, xr3
    XMULW4_H xr12, xr13, xr10, xr10, xr14, xr15, xr16, xr17

    PROCESS_LUMA_LASX xr0, xr1, xr2, xr3, xr14, xr15, xr16, xr17, \
                      xr22, xr23, xr4, xr5, xr6, xr7


    xvpickev.h     xr0,  xr21,  xr20
    xvpickev.h     xr1,  xr23,  xr22

    xvssrarni.bu.h xr1,  xr0,   6
    addi.d         t1,   t1,    32
    xvst           xr1,  t2,    0
    addi.d         t2,   t2,    32
.endr
    addi.d        t0,   t0,    -1
    add.d         a0,   a0,    a1
    add.d         a2,   a2,    a3
    blt           zero, t0,    .loopH_lasx_\w\()x\h
endfunc
.endm

FILTER_HORIZ_LUMA_WxN_LASX 32, 8,  1
FILTER_HORIZ_LUMA_WxN_LASX 32, 16, 1
FILTER_HORIZ_LUMA_WxN_LASX 32, 24, 1
FILTER_HORIZ_LUMA_WxN_LASX 32, 32, 1
FILTER_HORIZ_LUMA_WxN_LASX 32, 64, 1
FILTER_HORIZ_LUMA_WxN_LASX 64, 16, 2
FILTER_HORIZ_LUMA_WxN_LASX 64, 32, 2
FILTER_HORIZ_LUMA_WxN_LASX 64, 48, 2
FILTER_HORIZ_LUMA_WxN_LASX 64, 64, 2

.macro FILTER_HORIZ_PS_16xN_LASX  h
function x265_interp_8tap_horiz_ps_16x\h\()_lasx
    slli.d       t7,    a4,    5
    slli.d       a3,    a3,    1
    la.local     t6,    g_lumaFilter
    la.local     t5,    h_psOffset
    xvldx        xr10,  t6,    t7
    xvld         xr11,  t5,    0
    addi.d       t0,    zero,  \h
    beqz         a5,    .loopS_lasx_16x\h
    alsl.d       t1,    a1,    a1,   1
    sub.d        a0,    a0,    t1
    addi.d       t0,    t0,    7
.loopS_lasx_16x\h:
    vld          vr0,   a0,    -3
    vld          vr1,   a0,    -2
    vld          vr2,   a0,    -1
    vld          vr3,   a0,    0
    vld          vr20,  a0,    1
    vld          vr21,  a0,    2
    vld          vr22,  a0,    3
    vld          vr23,  a0,    4
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    vilvl.b      vr6,   vr21,  vr20
    vilvl.b      vr7,   vr23,  vr22
    vilvh.b      vr8,   vr1,   vr0
    vilvh.b      vr9,   vr3,   vr2
    vilvh.b      vr12,  vr21,  vr20
    vilvh.b      vr13,  vr23,  vr22

    xvpermi.q    xr8,   xr4,   0x20
    xvpermi.q    xr9,   xr5,   0x20
    xvpermi.q    xr12,  xr6,   0x20
    xvpermi.q    xr13,  xr7,   0x20

    XMULW4_H xr8, xr9, xr10, xr10, xr4, xr5, xr6, xr7
    XMULW4_H xr12, xr13, xr10, xr10, xr14, xr15, xr16, xr17

    PROCESS_LUMA_LASX xr4, xr5, xr6, xr7, xr14, xr15, xr16, xr17, \
                      xr20, xr21, xr4, xr5, xr6, xr7

    xvpickev.h   xr0,   xr21,  xr20
    xvadd.h      xr2,   xr0,   xr11
    add.d        a0,    a0,    a1
    addi.d       t0,    t0,    -1
    xvst         xr2,   a2,    0
    add.d        a2,    a2,    a3
    blt          zero,  t0,    .loopS_lasx_16x\h
endfunc
.endm

FILTER_HORIZ_PS_16xN_LASX 4
FILTER_HORIZ_PS_16xN_LASX 8
FILTER_HORIZ_PS_16xN_LASX 12
FILTER_HORIZ_PS_16xN_LASX 16
FILTER_HORIZ_PS_16xN_LASX 32
FILTER_HORIZ_PS_16xN_LASX 64

function x265_interp_8tap_horiz_ps_24x32_lasx
    slli.d       t7,    a4,    5
    slli.d       a3,    a3,    1
    la.local     t6,    g_lumaFilter
    la.local     t5,    h_psOffset
    xvldx        xr10,  t6,    t7
    xvld         xr11,  t5,    0
    addi.d       t0,    zero,  32
    beqz         a5,    .loopS_lasx_24x32
    alsl.d       t1,    a1,    a1,   1
    sub.d        a0,    a0,    t1
    addi.d       t0,    t0,    7
.loopS_lasx_24x32:
    xvld         xr0,   a0,    -3
    xvld         xr1,   a0,    -2
    xvld         xr2,   a0,    -1
    xvld         xr3,   a0,    0
    xvld         xr20,  a0,    1
    xvld         xr21,  a0,    2
    xvld         xr22,  a0,    3
    xvld         xr23,  a0,    4
    xvilvl.b     xr4,   xr1,   xr0
    xvilvl.b     xr5,   xr3,   xr2
    xvilvl.b     xr6,   xr21,  xr20
    xvilvl.b     xr7,   xr23,  xr22
    xvilvh.b     xr8,   xr1,   xr0
    xvilvh.b     xr9,   xr3,   xr2
    xvilvh.b     xr12,  xr21,  xr20
    xvilvh.b     xr13,  xr23,  xr22

    xvpermi.q    xr12,  xr8,   0x20
    xvpermi.q    xr13,  xr9,   0x20
    XMULW4_H xr4, xr5, xr10, xr10, xr0, xr1, xr2, xr3
    XMULW4_H xr6, xr7, xr10, xr10, xr14, xr15, xr16, xr17

    PROCESS_LUMA_LASX xr0, xr1, xr2, xr3, xr14, xr15, xr16, xr17, \
                      xr20, xr21, xr4, xr5, xr6, xr7

    XMULW4_H xr12, xr13, xr10, xr10, xr14, xr15, xr16, xr17
.irp x, xr14, xr15, xr16, xr17
    xvhaddw.w.h  \x,    \x,    \x
.endr
    xvpickev.h   xr4,   xr15,  xr14
    xvpickev.h   xr5,   xr17,  xr16
    xvhaddw.w.h  xr4,   xr4,   xr4
    xvhaddw.w.h  xr5,   xr5,   xr5
    xvpickev.h   xr6,   xr5,   xr4
    xvhaddw.w.h  xr22,  xr6,   xr6
    xvpermi.d    xr0,   xr20,  0x4E
    xvpermi.d    xr1,   xr21,  0x4E
    xvpermi.q    xr20,  xr22,  0x2
    xvpermi.q    xr21,  xr22,  0x12

    xvpickev.h   xr2,   xr21,  xr20
    vpickev.h    vr3,   vr1,   vr0

    xvadd.h      xr4,   xr2,   xr11
    xvadd.h      xr5,   xr3,   xr11
    xvst         xr4,   a2,    0
    vst          vr5,   a2,    32
    addi.d       t0,    t0,    -1
    add.d        a2,    a2,    a3
    add.d        a0,    a0,    a1
    blt          zero,  t0,    .loopS_lasx_24x32
endfunc

function x265_interp_8tap_horiz_ps_48x64_lasx
    slli.d       t7,    a4,    5
    slli.d       a3,    a3,    1
    la.local     t6,    g_lumaFilter
    la.local     t5,    h_psOffset
    xvldx        xr10,  t6,    t7
    xvld         xr11,  t5,    0
    addi.d       t0,    zero,  64
    beqz         a5,    .loopS_lasx_48x64
    alsl.d       t1,    a1,    a1,   1
    sub.d        a0,    a0,    t1
    addi.d       t0,    t0,    7
.loopS_lasx_48x64:
    xvld         xr0,   a0,    -3
    xvld         xr1,   a0,    -2
    xvld         xr2,   a0,    -1
    xvld         xr3,   a0,    0
    xvld         xr20,  a0,    1
    xvld         xr21,  a0,    2
    xvld         xr22,  a0,    3
    xvld         xr23,  a0,    4
    xvilvl.b     xr4,   xr1,   xr0
    xvilvl.b     xr5,   xr3,   xr2
    xvilvl.b     xr6,   xr21,  xr20
    xvilvl.b     xr7,   xr23,  xr22
    xvilvh.b     xr8,   xr1,   xr0
    xvilvh.b     xr9,   xr3,   xr2
    xvilvh.b     xr12,  xr21,  xr20
    xvilvh.b     xr13,  xr23,  xr22

    XMULW4_H xr4, xr5, xr10, xr10, xr0, xr1, xr2, xr3
    XMULW4_H xr6, xr7, xr10, xr10, xr14, xr15, xr16, xr17

    PROCESS_LUMA_LASX xr0, xr1, xr2, xr3, xr14, xr15, xr16, xr17, \
                      xr20, xr21, xr4, xr5, xr6, xr7

    XMULW4_H xr8, xr9, xr10, xr10, xr0, xr1, xr2, xr3
    XMULW4_H xr12, xr13, xr10, xr10, xr14, xr15, xr16, xr17

    PROCESS_LUMA_LASX xr0, xr1, xr2, xr3, xr14, xr15, xr16, xr17, \
                      xr22, xr23, xr4, xr5, xr6, xr7

    xvpickev.h   xr0,   xr21,  xr20
    xvpickev.h   xr1,   xr23,  xr22
    xvadd.h      xr2,   xr0,   xr11
    xvadd.h      xr3,   xr1,   xr11
    xvor.v       xr4,   xr2,   xr2
    xvpermi.q    xr2,   xr3,   0x2
    xvpermi.q    xr4,   xr3,   0x13

    xvst         xr2,   a2,    0
    xvst         xr4,   a2,    32

    vld          vr0,   a0,    29
    vld          vr1,   a0,    30
    vld          vr2,   a0,    31
    vld          vr3,   a0,    32
    vld          vr20,  a0,    33
    vld          vr21,  a0,    34
    vld          vr22,  a0,    35
    vld          vr23,  a0,    36
    vilvl.b      vr4,   vr1,   vr0
    vilvl.b      vr5,   vr3,   vr2
    vilvl.b      vr6,   vr21,  vr20
    vilvl.b      vr7,   vr23,  vr22
    vilvh.b      vr8,   vr1,   vr0
    vilvh.b      vr9,   vr3,   vr2
    vilvh.b      vr12,  vr21,  vr20
    vilvh.b      vr13,  vr23,  vr22

    xvpermi.q    xr8,   xr4,   0x20
    xvpermi.q    xr9,   xr5,   0x20
    xvpermi.q    xr12,  xr6,   0x20
    xvpermi.q    xr13,  xr7,   0x20

    XMULW4_H xr8, xr9, xr10, xr10, xr4, xr5, xr6, xr7
    XMULW4_H xr12, xr13, xr10, xr10, xr14, xr15, xr16, xr17

    PROCESS_LUMA_LASX xr4, xr5, xr6, xr7, xr14, xr15, xr16, xr17, \
                      xr20, xr21, xr4, xr5, xr6, xr7

    xvpickev.h   xr0,   xr21,  xr20
    xvadd.h      xr2,   xr0,   xr11
    addi.d       t0,    t0,    -1
    add.d        a0,    a0,    a1
    xvst         xr2,   a2,    64
    add.d        a2,    a2,    a3
    blt          zero,  t0,    .loopS_lasx_48x64
endfunc

.macro FILTER_HORIZ_PS_WxN_LASX  w, h, rep
function x265_interp_8tap_horiz_ps_\w\()x\h\()_lasx
    slli.d       t7,    a4,    5
    slli.d       a3,    a3,    1
    la.local     t6,    g_lumaFilter
    la.local     t5,    h_psOffset
    xvldx        xr10,  t6,    t7
    xvld         xr11,  t5,    0
    addi.d       t0,    zero,  \h
    beqz         a5,    .loopS_lasx_\w\()x\h
    alsl.d       t1,    a1,    a1,   1
    sub.d        a0,    a0,    t1
    addi.d       t0,    t0,    7
.loopS_lasx_\w\()x\h:
    move         t1,    a0
    move         t2,    a2
.rept \rep
    xvld         xr0,   t1,    -3
    xvld         xr1,   t1,    -2
    xvld         xr2,   t1,    -1
    xvld         xr3,   t1,    0
    xvld         xr20,  t1,    1
    xvld         xr21,  t1,    2
    xvld         xr22,  t1,    3
    xvld         xr23,  t1,    4
    xvilvl.b     xr4,   xr1,   xr0
    xvilvl.b     xr5,   xr3,   xr2
    xvilvl.b     xr6,   xr21,  xr20
    xvilvl.b     xr7,   xr23,  xr22
    xvilvh.b     xr8,   xr1,   xr0
    xvilvh.b     xr9,   xr3,   xr2
    xvilvh.b     xr12,  xr21,  xr20
    xvilvh.b     xr13,  xr23,  xr22

    XMULW4_H xr4, xr5, xr10, xr10, xr0, xr1, xr2, xr3
    XMULW4_H xr6, xr7, xr10, xr10, xr14, xr15, xr16, xr17

    PROCESS_LUMA_LASX xr0, xr1, xr2, xr3, xr14, xr15, xr16, xr17, \
                      xr20, xr21, xr4, xr5, xr6, xr7

    XMULW4_H xr8, xr9, xr10, xr10, xr0, xr1, xr2, xr3
    XMULW4_H xr12, xr13, xr10, xr10, xr14, xr15, xr16, xr17

    PROCESS_LUMA_LASX xr0, xr1, xr2, xr3, xr14, xr15, xr16, xr17, \
                      xr22, xr23, xr4, xr5, xr6, xr7

    xvpickev.h   xr0,   xr21,  xr20
    xvpickev.h   xr1,   xr23,  xr22
    xvadd.h      xr2,   xr0,   xr11
    xvadd.h      xr3,   xr1,   xr11
    xvor.v       xr4,   xr2,   xr2
    xvpermi.q    xr2,   xr3,   0x2
    xvpermi.q    xr4,   xr3,   0x13

    addi.d       t1,    t1,    32
    xvst         xr2,   t2,    0
    xvst         xr4,   t2,    32
    addi.d       t2,    t2,    64
.endr
    addi.d       t0,    t0,    -1
    add.d        a2,    a2,    a3
    add.d        a0,    a0,    a1
    blt          zero,  t0,    .loopS_lasx_\w\()x\h
endfunc
.endm

FILTER_HORIZ_PS_WxN_LASX 32, 8,  1
FILTER_HORIZ_PS_WxN_LASX 32, 16, 1
FILTER_HORIZ_PS_WxN_LASX 32, 24, 1
FILTER_HORIZ_PS_WxN_LASX 32, 32, 1
FILTER_HORIZ_PS_WxN_LASX 32, 64, 1
FILTER_HORIZ_PS_WxN_LASX 64, 16, 2
FILTER_HORIZ_PS_WxN_LASX 64, 32, 2
FILTER_HORIZ_PS_WxN_LASX 64, 48, 2
FILTER_HORIZ_PS_WxN_LASX 64, 64, 2

.macro FILTER_VERT_SP_4xN  h
function x265_interp_8tap_vert_sp_4x\h\()_lsx
    slli.d       a1,    a1,    1
    slli.d       t7,    a4,    4
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_lumaFilter
    la.local     t4,    h_psOffset
    addi.d       sp,    sp,    -32
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  \h/4
    sub.d        t6,    a0,    t2  //src -= 3 * srcStride
    fst.d        f24,   sp,    0
    fst.d        f25,   sp,    8
    fst.d        f26,   sp,    16
    fst.d        f27,   sp,    24
    vldrepl.h    vr16,  t5,    0 + 128
    vldrepl.h    vr17,  t5,    2 + 128
    vldrepl.h    vr18,  t5,    4 + 128
    vldrepl.h    vr19,  t5,    6 + 128
    vldrepl.h    vr20,  t5,    8 + 128
    vldrepl.h    vr21,  t5,    10 + 128
    vldrepl.h    vr22,  t5,    12 + 128
    vldrepl.h    vr23,  t5,    14 + 128
    vld          vr27,  t4,    32

    add.d        a0,    t6,    t3
    fld.d        f8,    t6,    0    //0
    fldx.d       f9,    t6,    a1   //1
    fldx.d       f10,   t6,    t1   //2
    fldx.d       f11,   t6,    t2   //3

    fld.d        f12,   a0,    0    //4
    fldx.d       f13,   a0,    a1   //5
    fldx.d       f14,   a0,    t1   //6

    add.d        t6,    a0,    t2
    vilvl.h      vr0,   vr9,   vr8  //0,1
    vilvl.h      vr1,   vr10,  vr9  //1,2
    vilvl.h      vr2,   vr11,  vr10 //2,3
    vilvl.h      vr3,   vr12,  vr11 //3,4
    vilvl.h      vr4,   vr13,  vr12 //4,5
    vilvl.h      vr5,   vr14,  vr13 //5,6
.loopV_sp_4x\h:
    fld.d        f15,   t6,    0    //7
    fldx.d       f24,   t6,    a1   //8
    fldx.d       f25,   t6,    t1   //9
    fldx.d       f26,   t6,    t2   //10
.irp x, vr10, vr11, vr12, vr13
    vor.v        \x,    vr27,  vr27
.endr
    VMADD4_W vr0, vr2, vr16, vr16, vr10, vr11, vr12, vr13
    vilvl.h      vr6,   vr15,  vr14 //6,7
    vilvl.h      vr7,   vr24,  vr15 //7,8
    vilvl.h      vr8,   vr25,  vr24 //8,9
    vilvl.h      vr9,   vr26,  vr25 //9,10

    VMADD4_W vr1, vr3, vr17, vr17, vr10, vr11, vr12, vr13
    VMADD4_W vr2, vr4, vr18, vr18, vr10, vr11, vr12, vr13
    VMADD4_W vr3, vr5, vr19, vr19, vr10, vr11, vr12, vr13
    VMADD4_W vr4, vr6, vr20, vr20, vr10, vr11, vr12, vr13
    VMADD4_W vr5, vr7, vr21, vr21, vr10, vr11, vr12, vr13
    VMADD4_W vr6, vr8, vr22, vr22, vr10, vr11, vr12, vr13
    VMADD4_W vr7, vr9, vr23, vr23, vr10, vr11, vr12, vr13

    vor.v            vr0,  vr4,  vr4
    vor.v            vr1,  vr5,  vr5
    vor.v            vr2,  vr6,  vr6
    vor.v            vr3,  vr7,  vr7
    vssrani.h.w      vr11, vr10, 12
    vssrani.h.w      vr13, vr12, 12
    vor.v            vr4,  vr8,  vr8
    vor.v            vr5,  vr9,  vr9
    vssrani.bu.h     vr13, vr11, 0
    vor.v            vr14, vr26, vr26
    vstelm.w         vr13, a2,   0,  0
    add.d            a2,   a2,   a3
    vstelm.w         vr13, a2,   0,  1
    add.d            a2,   a2,   a3
    vstelm.w         vr13, a2,   0,  2
    add.d            a2,   a2,   a3
    vstelm.w         vr13, a2,   0,  3
    add.d            t6,   t6,   t3
    add.d            a2,   a2,   a3
    addi.d           t0,   t0,   -1
    blt              zero, t0,   .loopV_sp_4x\h
    fld.d            f24,  sp,   0
    fld.d            f25,  sp,   8
    fld.d            f26,  sp,   16
    fld.d            f27,  sp,   24
    addi.d           sp,   sp,   32
endfunc
.endm

FILTER_VERT_SP_4xN 4
FILTER_VERT_SP_4xN 8
FILTER_VERT_SP_4xN 16

.macro FILTER_VERT_SP_8xN  h
function x265_interp_8tap_vert_sp_8x\h\()_lsx
    slli.d       a1,    a1,    1
    slli.d       t7,    a4,    4
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_lumaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  \h/2
    sub.d        t6,    a0,    t2  //src -= 3 * srcStride
    vldrepl.h    vr16,  t5,    0 + 128
    vldrepl.h    vr17,  t5,    2 + 128
    vldrepl.h    vr18,  t5,    4 + 128
    vldrepl.h    vr19,  t5,    6 + 128
    vldrepl.h    vr20,  t5,    8 + 128
    vldrepl.h    vr21,  t5,    10 + 128
    vldrepl.h    vr22,  t5,    12 + 128
    vldrepl.h    vr23,  t5,    14 + 128
    vld          vr15,  t4,    32

    add.d        a0,    t6,    t3
    vld          vr0,   t6,    0    //0
    vldx         vr1,   t6,    a1   //1
    vldx         vr2,   t6,    t1   //2
    vldx         vr3,   t6,    t2   //3

    vld          vr4,   a0,    0    //4
    vldx         vr5,   a0,    a1   //5
    vldx         vr6,   a0,    t1   //6
    add.d        t6,    a0,    t2

.loopV_sp_8x\h:
    vld          vr7,   t6,    0   //7
    vldx         vr8,   t6,    a1  //8
.irp x, vr10, vr11, vr12, vr13
    vor.v        \x,    vr15,  vr15
.endr
    VMADD4_W vr0, vr1, vr16, vr16, vr10, vr11, vr12, vr13
    VMADD4_W vr1, vr2, vr17, vr17, vr10, vr11, vr12, vr13
    VMADD4_W vr2, vr3, vr18, vr18, vr10, vr11, vr12, vr13
    VMADD4_W vr3, vr4, vr19, vr19, vr10, vr11, vr12, vr13
    VMADD4_W vr4, vr5, vr20, vr20, vr10, vr11, vr12, vr13
    VMADD4_W vr5, vr6, vr21, vr21, vr10, vr11, vr12, vr13
    VMADD4_W vr6, vr7, vr22, vr22, vr10, vr11, vr12, vr13
    VMADD4_W vr7, vr8, vr23, vr23, vr10, vr11, vr12, vr13

    vor.v            vr0,  vr2,  vr2
    vor.v            vr1,  vr3,  vr3
    vor.v            vr2,  vr4,  vr4
    vor.v            vr3,  vr5,  vr5
    vssrani.h.w      vr12, vr10, 12
    vssrani.h.w      vr13, vr11, 12
    vor.v            vr4,  vr6,  vr6
    vor.v            vr5,  vr7,  vr7
    vssrani.bu.h     vr13, vr12, 0
    vor.v            vr6,  vr8,  vr8
    vbsrl.v          vr10, vr13, 8
    vilvl.b          vr11, vr10, vr13

    vstelm.d         vr11, a2,   0,  0
    add.d            a2,   a2,   a3
    vstelm.d         vr11, a2,   0,  1
    add.d            t6,   t6,   t1
    addi.d           t0,   t0,   -1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_sp_8x\h
endfunc
.endm

FILTER_VERT_SP_8xN 4
FILTER_VERT_SP_8xN 8
FILTER_VERT_SP_8xN 16
FILTER_VERT_SP_8xN 32

function x265_interp_8tap_vert_sp_12x16_lsx
    slli.d       a1,    a1,    1
    slli.d       t7,    a4,    4
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_lumaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  16
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride
    addi.d       sp,    sp,    -40
    fst.d        f24,   sp,    0
    fst.d        f25,   sp,    8
    fst.d        f26,   sp,    16
    fst.d        f27,   sp,    24
    fst.d        f28,   sp,    32

    vldrepl.h    vr16,  t5,    0 + 128
    vldrepl.h    vr17,  t5,    2 + 128
    vldrepl.h    vr18,  t5,    4 + 128
    vldrepl.h    vr19,  t5,    6 + 128
    vldrepl.h    vr20,  t5,    8 + 128
    vldrepl.h    vr21,  t5,    10 + 128
    vldrepl.h    vr22,  t5,    12 + 128
    vldrepl.h    vr23,  t5,    14 + 128
    vld          vr28,  t4,    32

    addi.d       t6,    a0,    16
    vld          vr0,   a0,    0    //0
    vldx         vr1,   a0,    a1   //1
    vldx         vr2,   a0,    t1   //2
    vldx         vr3,   a0,    t2   //3

    add.d        a0,    a0,    t3
    fld.d        f8,    t6,    0
    fldx.d       f9,    t6,    a1
    fldx.d       f10,   t6,    t1
    fldx.d       f11,   t6,    t2
    addi.d       t6,    a0,    16

    vilvl.h      vr8,   vr27,  vr8
    vilvl.h      vr9,   vr27,  vr9
    vilvl.h      vr10,  vr27,  vr10
    vilvl.h      vr11,  vr27,  vr11
    vld          vr4,   a0,    0    //4
    vldx         vr5,   a0,    a1   //5
    vldx         vr6,   a0,    t1   //6

    fld.d        f12,   t6,    0
    fldx.d       f13,   t6,    a1
    fldx.d       f14,   t6,    t1
    add.d        a0,    a0,    t2
    vilvl.h      vr12,  vr27,  vr12
    vilvl.h      vr13,  vr27,  vr13
    vilvl.h      vr14,  vr27,  vr14
.loopV_sp_12x16:
    vld          vr7,   a0,   0   //7
    fld.d        f15,   a0,   16  //7
    vor.v        vr24,  vr28, vr28
    vor.v        vr25,  vr28, vr28
    vor.v        vr26,  vr28, vr28
    vilvl.h      vr15,  vr27, vr15
    vmaddwev.w.h  vr24, vr0,  vr16
    vmaddwod.w.h  vr25, vr0,  vr16
    vmaddwev.w.h  vr26, vr8,  vr16

    vmaddwev.w.h  vr24, vr1,  vr17
    vmaddwod.w.h  vr25, vr1,  vr17
    vmaddwev.w.h  vr26, vr9,  vr17

    vmaddwev.w.h  vr24, vr2,  vr18
    vmaddwod.w.h  vr25, vr2,  vr18
    vmaddwev.w.h  vr26, vr10, vr18

    vmaddwev.w.h  vr24, vr3,  vr19
    vmaddwod.w.h  vr25, vr3,  vr19
    vmaddwev.w.h  vr26, vr11, vr19

    vmaddwev.w.h  vr24, vr4,  vr20
    vmaddwod.w.h  vr25, vr4,  vr20
    vmaddwev.w.h  vr26, vr12, vr20

    vmaddwev.w.h  vr24, vr5,  vr21
    vmaddwod.w.h  vr25, vr5,  vr21
    vmaddwev.w.h  vr26, vr13, vr21

    vmaddwev.w.h  vr24, vr6,  vr22
    vmaddwod.w.h  vr25, vr6,  vr22
    vmaddwev.w.h  vr26, vr14, vr22

    vmaddwev.w.h  vr24, vr7,  vr23
    vmaddwod.w.h  vr25, vr7,  vr23
    vmaddwev.w.h  vr26, vr15, vr23

    vor.v            vr0,  vr1,  vr1
    vor.v            vr1,  vr2,  vr2
    vor.v            vr2,  vr3,  vr3
    vor.v            vr3,  vr4,  vr4
    vor.v            vr4,  vr5,  vr5
    vor.v            vr5,  vr6,  vr6
    vor.v            vr6,  vr7,  vr7

    vssrani.h.w      vr26, vr24, 12
    vssrani.h.w      vr27, vr25, 12
    vor.v            vr8,  vr9,  vr9
    vor.v            vr9,  vr10, vr10
    vor.v            vr10, vr11, vr11
    vilvl.h          vr24, vr27, vr26
    vor.v            vr11, vr12, vr12
    vor.v            vr12, vr13, vr13
    vssrani.bu.h     vr26, vr24, 0
    vor.v            vr13, vr14, vr14
    vor.v            vr14, vr15, vr15

    vstelm.d         vr26, a2,   0,  0
    vstelm.w         vr26, a2,   8,  3
    add.d            a0,   a0,   a1
    addi.d           t0,   t0,   -1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_sp_12x16
    fld.d            f24,  sp,    0
    fld.d            f25,  sp,    8
    fld.d            f26,  sp,    16
    fld.d            f27,  sp,    24
    fld.d            f28,  sp,    32
    addi.d           sp,   sp,    40
endfunc

.macro FILTER_VERT_SP_16xN  h
function x265_interp_8tap_vert_sp_16x\h\()_lsx
    slli.d       a1,    a1,    1
    slli.d       t7,    a4,    4
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_lumaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  \h
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride
    addi.d       sp,    sp,    -40
    fst.d        f24,   sp,    0
    fst.d        f25,   sp,    8
    fst.d        f26,   sp,    16
    fst.d        f27,   sp,    24
    fst.d        f28,   sp,    32

    vldrepl.h    vr16,  t5,    0 + 128
    vldrepl.h    vr17,  t5,    2 + 128
    vldrepl.h    vr18,  t5,    4 + 128
    vldrepl.h    vr19,  t5,    6 + 128
    vldrepl.h    vr20,  t5,    8 + 128
    vldrepl.h    vr21,  t5,    10 + 128
    vldrepl.h    vr22,  t5,    12 + 128
    vldrepl.h    vr23,  t5,    14 + 128
    vld          vr28,  t4,    32

    addi.d       t6,    a0,    16
    vld          vr0,   a0,    0    //0
    vldx         vr1,   a0,    a1   //1
    vldx         vr2,   a0,    t1   //2
    vldx         vr3,   a0,    t2   //3

    add.d        a0,    a0,    t3
    vld          vr8,   t6,    0
    vldx         vr9,   t6,    a1
    vldx         vr10,  t6,    t1
    vldx         vr11,  t6,    t2
    addi.d       t6,    a0,    16

    vld          vr4,   a0,    0    //4
    vldx         vr5,   a0,    a1   //5
    vldx         vr6,   a0,    t1   //6

    vld          vr12,  t6,    0
    vldx         vr13,  t6,    a1
    vldx         vr14,  t6,    t1
    add.d        a0,    a0,    t2
.loopV_sp_16x\h:
    vld          vr7,   a0,    0   //7
    vld          vr15,  a0,    16  //7
.irp x, vr24, vr25, vr26, vr27
    vor.v        \x,    vr28,  vr28
.endr
    VMADD4_W vr0, vr8, vr16, vr16, vr24, vr25, vr26, vr27
    VMADD4_W vr1, vr9, vr17, vr17, vr24, vr25, vr26, vr27
    VMADD4_W vr2, vr10, vr18, vr18, vr24, vr25, vr26, vr27
    VMADD4_W vr3, vr11, vr19, vr19, vr24, vr25, vr26, vr27
    VMADD4_W vr4, vr12, vr20, vr20, vr24, vr25, vr26, vr27
    VMADD4_W vr5, vr13, vr21, vr21, vr24, vr25, vr26, vr27
    VMADD4_W vr6, vr14, vr22, vr22, vr24, vr25, vr26, vr27
    VMADD4_W vr7, vr15, vr23, vr23, vr24, vr25, vr26, vr27

    vor.v            vr0,  vr1,  vr1
    vor.v            vr1,  vr2,  vr2
    vor.v            vr2,  vr3,  vr3
    vor.v            vr3,  vr4,  vr4
    vor.v            vr4,  vr5,  vr5
    vor.v            vr5,  vr6,  vr6
    vor.v            vr6,  vr7,  vr7

    vssrani.h.w      vr26, vr24, 12
    vssrani.h.w      vr27, vr25, 12
    vor.v            vr8,  vr9,  vr9
    vor.v            vr9,  vr10, vr10
    vor.v            vr10, vr11, vr11
    vilvl.h          vr24, vr27, vr26
    vilvh.h          vr25, vr27, vr26
    vor.v            vr11, vr12, vr12
    vor.v            vr12, vr13, vr13
    vssrani.bu.h     vr25, vr24, 0
    vor.v            vr13, vr14, vr14
    vor.v            vr14, vr15, vr15

    vst              vr25, a2,   0
    add.d            a0,   a0,   a1
    addi.d           t0,   t0,   -1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_sp_16x\h
    fld.d            f24,  sp,   0
    fld.d            f25,  sp,   8
    fld.d            f26,  sp,   16
    fld.d            f27,  sp,   24
    fld.d            f28,  sp,   32
    addi.d           sp,   sp,   40
endfunc
.endm

FILTER_VERT_SP_16xN 4
FILTER_VERT_SP_16xN 8
FILTER_VERT_SP_16xN 12
FILTER_VERT_SP_16xN 16
FILTER_VERT_SP_16xN 32
FILTER_VERT_SP_16xN 64

function x265_interp_8tap_vert_sp_24x32_lsx
    slli.d       a1,    a1,    1
    slli.d       t7,    a4,    4
    slli.d       t1,    a1,    1   //srcStride * 2
    la.local     t6,    g_lumaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  32
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride

    vldrepl.h    vr16,  t5,    0 + 128
    vldrepl.h    vr17,  t5,    2 + 128
    vldrepl.h    vr18,  t5,    4 + 128
    vldrepl.h    vr19,  t5,    6 + 128
    vldrepl.h    vr20,  t5,    8 + 128
    vldrepl.h    vr21,  t5,    10 + 128
    vldrepl.h    vr22,  t5,    12 + 128
    vldrepl.h    vr23,  t5,    14 + 128
    vld          vr7,   t4,    32

.loopV_sp_24x32:
    vld          vr0,   a0,    0
    vld          vr1,   a0,    16
    vld          vr2,   a0,    32
    add.d        t5,    a0,    a1
.irp x, vr8, vr9, vr10, vr11, vr12, vr13
    vor.v        \x,    vr7,   vr7
.endr
    VMADD4_W vr0, vr1, vr16, vr16, vr8, vr9, vr10, vr11
    vmaddwev.w.h vr12,  vr2, vr16
    vmaddwod.w.h vr13,  vr2, vr16
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr17, vr17, vr8, vr9, vr10, vr11
    vmaddwev.w.h vr12,  vr2, vr17
    vmaddwod.w.h vr13,  vr2, vr17
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr18, vr18, vr8, vr9, vr10, vr11
    vmaddwev.w.h vr12,  vr2, vr18
    vmaddwod.w.h vr13,  vr2, vr18
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr19, vr19, vr8, vr9, vr10, vr11
    vmaddwev.w.h vr12,  vr2, vr19
    vmaddwod.w.h vr13,  vr2, vr19
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr20, vr20, vr8, vr9, vr10, vr11
    vmaddwev.w.h vr12,  vr2, vr20
    vmaddwod.w.h vr13,  vr2, vr20
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr21, vr21, vr8, vr9, vr10, vr11
    vmaddwev.w.h vr12,  vr2, vr21
    vmaddwod.w.h vr13,  vr2, vr21
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr22, vr22, vr8, vr9, vr10, vr11
    vmaddwev.w.h vr12,  vr2, vr22
    vmaddwod.w.h vr13,  vr2, vr22
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    VMADD4_W vr0, vr1, vr23, vr23, vr8, vr9, vr10, vr11
    vmaddwev.w.h vr12,  vr2, vr23
    vmaddwod.w.h vr13,  vr2, vr23

    vssrani.h.w  vr10, vr8,  12
    vssrani.h.w  vr11, vr9,  12
    vssrani.h.w  vr13, vr12, 12

    vilvl.h      vr8, vr11, vr10
    vilvh.h      vr9, vr11, vr10
    vssrani.bu.h vr14, vr13, 0
    vssrani.bu.h vr9,  vr8,  0
    vbsrl.v      vr12, vr14, 4
    vilvl.b      vr5,  vr12, vr14
    vst          vr9,  a2,   0
    vstelm.d     vr5,  a2,   16,  0
    addi.d       t0,   t0,   -1
    add.d        a0,   a0,   a1
    add.d        a2,   a2,   a3
    blt          zero, t0,   .loopV_sp_24x32
endfunc

function x265_interp_8tap_vert_sp_48x64_lsx
    slli.d       a1,    a1,    1
    slli.d       t7,    a4,    4
    slli.d       t1,    a1,    1   //srcStride * 2
    addi.d       sp,    sp,    -24
    la.local     t6,    g_lumaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  64
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride
    fst.d        f24,   sp,    0
    fst.d        f25,   sp,    8
    fst.d        f26,   sp,    16

    vldrepl.h    vr16,  t5,    0 + 128
    vldrepl.h    vr17,  t5,    2 + 128
    vldrepl.h    vr18,  t5,    4 + 128
    vldrepl.h    vr19,  t5,    6 + 128
    vldrepl.h    vr20,  t5,    8 + 128
    vldrepl.h    vr21,  t5,    10 + 128
    vldrepl.h    vr22,  t5,    12 + 128
    vldrepl.h    vr23,  t5,    14 + 128
    vld          vr7,   t4,    32

.loopV_sp_48x64:
    vld          vr0,   a0,    0
    vld          vr1,   a0,    16
    vld          vr2,   a0,    32
    vld          vr3,   a0,    48
    vld          vr4,   a0,    64
    vld          vr5,   a0,    80
    add.d        t5,    a0,    a1
.irp x, vr6, vr8, vr9, vr10, vr11, vr12, vr13, vr14, vr15, vr24, vr25, vr26
    vor.v        \x,    vr7,   vr7
.endr
    VMADD4_W vr0, vr1, vr16, vr16, vr6, vr8, vr9, vr10
    VMADD4_W vr2, vr3, vr16, vr16, vr11, vr12, vr13, vr14
    VMADD4_W vr4, vr5, vr16, vr16, vr15, vr24, vr25, vr26
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    vld          vr4,   t5,    64
    vld          vr5,   t5,    80
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr17, vr17, vr6, vr8, vr9, vr10
    VMADD4_W vr2, vr3, vr17, vr17, vr11, vr12, vr13, vr14
    VMADD4_W vr4, vr5, vr17, vr17, vr15, vr24, vr25, vr26
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    vld          vr4,   t5,    64
    vld          vr5,   t5,    80
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr18, vr18, vr6, vr8, vr9, vr10
    VMADD4_W vr2, vr3, vr18, vr18, vr11, vr12, vr13, vr14
    VMADD4_W vr4, vr5, vr18, vr18, vr15, vr24, vr25, vr26
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    vld          vr4,   t5,    64
    vld          vr5,   t5,    80
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr19, vr19, vr6, vr8, vr9, vr10
    VMADD4_W vr2, vr3, vr19, vr19, vr11, vr12, vr13, vr14
    VMADD4_W vr4, vr5, vr19, vr19, vr15, vr24, vr25, vr26
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    vld          vr4,   t5,    64
    vld          vr5,   t5,    80
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr20, vr20, vr6, vr8, vr9, vr10
    VMADD4_W vr2, vr3, vr20, vr20, vr11, vr12, vr13, vr14
    VMADD4_W vr4, vr5, vr20, vr20, vr15, vr24, vr25, vr26
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    vld          vr4,   t5,    64
    vld          vr5,   t5,    80
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr21, vr21, vr6, vr8, vr9, vr10
    VMADD4_W vr2, vr3, vr21, vr21, vr11, vr12, vr13, vr14
    VMADD4_W vr4, vr5, vr21, vr21, vr15, vr24, vr25, vr26
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    vld          vr4,   t5,    64
    vld          vr5,   t5,    80
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr22, vr22, vr6, vr8, vr9, vr10
    VMADD4_W vr2, vr3, vr22, vr22, vr11, vr12, vr13, vr14
    VMADD4_W vr4, vr5, vr22, vr22, vr15, vr24, vr25, vr26
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    vld          vr4,   t5,    64
    vld          vr5,   t5,    80
    VMADD4_W vr0, vr1, vr23, vr23, vr6, vr8, vr9, vr10
    VMADD4_W vr2, vr3, vr23, vr23, vr11, vr12, vr13, vr14
    VMADD4_W vr4, vr5, vr23, vr23, vr15, vr24, vr25, vr26

    vssrani.h.w  vr9,  vr6,  12
    vssrani.h.w  vr10, vr8,  12
    vssrani.h.w  vr13, vr11, 12
    vssrani.h.w  vr14, vr12, 12
    vssrani.h.w  vr25, vr15, 12
    vssrani.h.w  vr26, vr24, 12

    vssrani.bu.h vr13, vr9,  0
    vssrani.bu.h vr14, vr10, 0
    vilvl.h      vr10, vr26, vr25
    vilvh.h      vr11, vr26, vr25

    vilvl.b      vr0,  vr14, vr13
    vilvh.b      vr1,  vr14, vr13
    vssrani.bu.h vr11, vr10, 0
    vst          vr0,  a2,   0
    vst          vr1,  a2,   16
    vst          vr11, a2,   32
    addi.d       t0,   t0,   -1
    add.d        a0,   a0,   a1
    add.d        a2,   a2,   a3
    blt          zero, t0,   .loopV_sp_48x64
    fld.d        f24,  sp,   0
    fld.d        f25,  sp,   8
    fld.d        f26,  sp,   16
    addi.d       sp,   sp,   24
endfunc

.macro FILTER_VERT_SP_WxN  w, h, rep
function x265_interp_8tap_vert_sp_\w\()x\h\()_lsx
    slli.d       a1,    a1,    1
    slli.d       t7,    a4,    4
    slli.d       t1,    a1,    1   //srcStride * 2
    la.local     t6,    g_lumaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  \h
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride

    vldrepl.h    vr16,  t5,    0 + 128
    vldrepl.h    vr17,  t5,    2 + 128
    vldrepl.h    vr18,  t5,    4 + 128
    vldrepl.h    vr19,  t5,    6 + 128
    vldrepl.h    vr20,  t5,    8 + 128
    vldrepl.h    vr21,  t5,    10 + 128
    vldrepl.h    vr22,  t5,    12 + 128
    vldrepl.h    vr23,  t5,    14 + 128
    vld          vr7,   t4,    32

.loopV_sp_\w\()x\h:
    move         t1,    a0
    move         t2,    a2
.rept \rep
    vld          vr0,   t1,    0
    vld          vr1,   t1,    16
    vld          vr2,   t1,    32
    vld          vr3,   t1,    48
    add.d        t5,    t1,    a1
.irp x, vr8, vr9, vr10, vr11, vr12, vr13, vr14, vr15
    vor.v        \x,    vr7,   vr7
.endr
    VMADD4_W vr0, vr1, vr16, vr16, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr16, vr16, vr12, vr13, vr14, vr15
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr17, vr17, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr17, vr17, vr12, vr13, vr14, vr15
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr18, vr18, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr18, vr18, vr12, vr13, vr14, vr15
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr19, vr19, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr19, vr19, vr12, vr13, vr14, vr15
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr20, vr20, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr20, vr20, vr12, vr13, vr14, vr15
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr21, vr21, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr21, vr21, vr12, vr13, vr14, vr15
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr22, vr22, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr22, vr22, vr12, vr13, vr14, vr15
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    VMADD4_W vr0, vr1, vr23, vr23, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr23, vr23, vr12, vr13, vr14, vr15

    vssrani.h.w  vr10, vr8,  12
    vssrani.h.w  vr11, vr9,  12
    vssrani.h.w  vr14, vr12, 12
    vssrani.h.w  vr15, vr13, 12
    vssrani.bu.h vr14, vr10, 0
    vssrani.bu.h vr15, vr11, 0
    addi.d       t1,   t1,   64
    vilvl.b      vr4,  vr15, vr14
    vilvh.b      vr5,  vr15, vr14
    vst          vr4,  t2,   0
    vst          vr5,  t2,   16
    addi.d       t2,   t2,   32
.endr
    addi.d       t0,   t0,   -1
    add.d        a0,   a0,   a1
    add.d        a2,   a2,   a3
    blt          zero, t0,   .loopV_sp_\w\()x\h
endfunc
.endm

FILTER_VERT_SP_WxN 32, 8,  1
FILTER_VERT_SP_WxN 32, 16, 1
FILTER_VERT_SP_WxN 32, 24, 1
FILTER_VERT_SP_WxN 32, 32, 1
FILTER_VERT_SP_WxN 32, 64, 1
FILTER_VERT_SP_WxN 64, 16, 2
FILTER_VERT_SP_WxN 64, 32, 2
FILTER_VERT_SP_WxN 64, 48, 2
FILTER_VERT_SP_WxN 64, 64, 2

.macro FILTER_VERT_SP_16xN_LASX  h
function x265_interp_8tap_vert_sp_16x\h\()_lasx
    slli.d       a1,    a1,    1
    slli.d       t7,    a4,    4
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2
    la.local     t6,    g_lumaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  \h/2
    sub.d        t6,    a0,    t2  //src -= 3 * srcStride

    slli.d       t7,    a3,    1
    xvldrepl.h   xr16,  t5,    0 + 128
    xvldrepl.h   xr17,  t5,    2 + 128
    xvldrepl.h   xr18,  t5,    4 + 128
    xvldrepl.h   xr19,  t5,    6 + 128
    xvldrepl.h   xr20,  t5,    8 + 128
    xvldrepl.h   xr21,  t5,    10 + 128
    xvldrepl.h   xr22,  t5,    12 + 128
    xvldrepl.h   xr23,  t5,    14 + 128
    xvld         xr15,  t4,    32

    add.d        a0,    t6,    t3
    xvld         xr0,   t6,    0
    xvldx        xr1,   t6,    a1
    xvldx        xr2,   t6,    t1
    xvldx        xr3,   t6,    t2
    xvld         xr4,   a0,    0
    xvldx        xr5,   a0,    a1
    xvldx        xr6,   a0,    t1
    add.d        t6,    a0,    t2
.loopV_sp_lasx_16x\h:
    xvld         xr7,   t6,    0
    xvldx        xr8,   t6,    a1
.irp x, xr10, xr11, xr12, xr13
    xvor.v       \x,    xr15,  xr15
.endr
    XMADD4_W xr0, xr1, xr16, xr16, xr10, xr11, xr12, xr13
    XMADD4_W xr1, xr2, xr17, xr17, xr10, xr11, xr12, xr13
    XMADD4_W xr2, xr3, xr18, xr18, xr10, xr11, xr12, xr13
    XMADD4_W xr3, xr4, xr19, xr19, xr10, xr11, xr12, xr13
    XMADD4_W xr4, xr5, xr20, xr20, xr10, xr11, xr12, xr13
    XMADD4_W xr5, xr6, xr21, xr21, xr10, xr11, xr12, xr13
    XMADD4_W xr6, xr7, xr22, xr22, xr10, xr11, xr12, xr13
    XMADD4_W xr7, xr8, xr23, xr23, xr10, xr11, xr12, xr13

    xvor.v        xr0,  xr2,  xr2
    xvor.v        xr1,  xr3,  xr3
    xvor.v        xr2,  xr4,  xr4
    xvor.v        xr3,  xr5,  xr5
    xvor.v        xr4,  xr6,  xr6
    xvor.v        xr5,  xr7,  xr7
    xvor.v        xr6,  xr8,  xr8
    xvssrani.h.w  xr12, xr10, 12
    xvssrani.h.w  xr13, xr11, 12
    xvilvl.h      xr10, xr13, xr12
    xvilvh.h      xr11, xr13, xr12
    xvssrani.bu.h xr11, xr10, 0
    addi.d        t0,   t0,   -1
    xvpermi.d     xr12, xr11, 0xD8
    xvpermi.d     xr13, xr11, 0x8D
    add.d         t6,   t6,   t1
    vst           vr12, a2,   0
    vstx          vr13, a2,   a3
    add.d         a2,   a2,   t7
    blt           zero, t0,   .loopV_sp_lasx_16x\h
endfunc
.endm

FILTER_VERT_SP_16xN_LASX 4
FILTER_VERT_SP_16xN_LASX 8
FILTER_VERT_SP_16xN_LASX 12
FILTER_VERT_SP_16xN_LASX 16
FILTER_VERT_SP_16xN_LASX 32
FILTER_VERT_SP_16xN_LASX 64

function x265_interp_8tap_vert_sp_24x32_lasx
    slli.d       a1,    a1,    1
    slli.d       t7,    a4,    4
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2
    la.local     t6,    g_lumaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  16
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride
    addi.d       sp,    sp,    -64

    xvldrepl.h   xr16,  t5,    0 + 128
    xvldrepl.h   xr17,  t5,    2 + 128
    xvldrepl.h   xr18,  t5,    4 + 128
    xvldrepl.h   xr19,  t5,    6 + 128
    xvldrepl.h   xr20,  t5,    8 + 128
    xvldrepl.h   xr21,  t5,    10 + 128
    xvldrepl.h   xr22,  t5,    12 + 128
    xvldrepl.h   xr23,  t5,    14 + 128
    fst.d        f24,   sp,    0
    fst.d        f25,   sp,    8
    fst.d        f26,   sp,    16
    fst.d        f27,   sp,    24
    fst.d        f28,   sp,    32
    fst.d        f29,   sp,    40
    fst.d        f30,   sp,    48
    fst.d        f31,   sp,    56

    addi.d       t6,    a0,    32
    xvld         xr0,   a0,    0
    xvldx        xr1,   a0,    a1
    xvldx        xr2,   a0,    t1
    xvldx        xr3,   a0,    t2

    add.d        a0,    a0,    t3
    vld          vr9,   t6,    0
    vldx         vr10,  t6,    a1
    vldx         vr11,  t6,    t1
    vldx         vr12,  t6,    t2
    addi.d       t6,    a0,    32

    xvld         xr4,   a0,    0
    xvldx        xr5,   a0,    a1
    xvldx        xr6,   a0,    t1

    vld          vr13,  t6,    0
    vldx         vr14,  t6,    a1
    vldx         vr15,  t6,    t1
    add.d        a0,    a0,    t2
    xvpermi.q    xr9,   xr10,  0x2
    xvpermi.q    xr10,  xr11,  0x2
    xvpermi.q    xr11,  xr12,  0x2
    xvpermi.q    xr12,  xr13,  0x2
    xvpermi.q    xr13,  xr14,  0x2
    xvpermi.q    xr14,  xr15,  0x2
.loopV_sp_lasx_24x32:
    addi.d       t6,    a0,    32
    xvld         xr26,  t4,    32
    xvld         xr7,   a0,    0
    xvldx        xr8,   a0,    a1
    vld          vr24,  t6,    0
    vldx         vr25,  t6,    a1
.irp x, xr27, xr28, xr29, xr30, xr31
    xvor.v       \x,    xr26,  xr26
.endr
    xvpermi.q    xr15,  xr24,  0x2
    xvpermi.q    xr24,  xr25,  0x2
    XMADD4_W xr0,  xr1,  xr16, xr16, xr26, xr27, xr28, xr29
    XMADD4_W xr9,  xr1,  xr16, xr17, xr30, xr31, xr26, xr27
    XMADD4_W xr2,  xr10, xr17, xr17, xr28, xr29, xr30, xr31
    XMADD4_W xr2,  xr3,  xr18, xr18, xr26, xr27, xr28, xr29
    XMADD4_W xr11, xr3,  xr18, xr19, xr30, xr31, xr26, xr27
    XMADD4_W xr4,  xr12, xr19, xr19, xr28, xr29, xr30, xr31
    XMADD4_W xr4,  xr5,  xr20, xr20, xr26, xr27, xr28, xr29
    XMADD4_W xr13, xr5,  xr20, xr21, xr30, xr31, xr26, xr27
    XMADD4_W xr6,  xr14, xr21, xr21, xr28, xr29, xr30, xr31
    XMADD4_W xr6,  xr7,  xr22, xr22, xr26, xr27, xr28, xr29
    XMADD4_W xr15, xr7,  xr22, xr23, xr30, xr31, xr26, xr27
    XMADD4_W xr8,  xr24, xr23, xr23, xr28, xr29, xr30, xr31

    xvor.v        xr0,  xr2,  xr2
    xvor.v        xr1,  xr3,  xr3
    xvor.v        xr2,  xr4,  xr4
    xvor.v        xr3,  xr5,  xr5
    xvor.v        xr4,  xr6,  xr6
    xvor.v        xr5,  xr7,  xr7
    xvor.v        xr6,  xr8,  xr8
    xvor.v        xr9,  xr11, xr11
    xvor.v        xr10, xr12, xr12
    xvor.v        xr11, xr13, xr13
    xvor.v        xr12, xr14, xr14
    xvor.v        xr13, xr15, xr15
    xvor.v        xr14, xr24, xr24
    xvor.v        xr15, xr25, xr25

    xvssrani.h.w  xr31, xr30, 12
    xvssrani.h.w  xr28, xr26, 12
    xvssrani.h.w  xr29, xr27, 12
    xvpermi.d     xr30, xr31, 0xB1
    xvilvl.h      xr7,  xr29, xr28
    xvilvh.h      xr8,  xr29, xr28
    xvilvl.h      xr24, xr30, xr31
    addi.d        t0,   t0,   -1
    xvssrani.bu.h xr8,  xr7,  0
    xvssrani.bu.h xr25, xr24, 0
    xvpermi.d     xr26, xr8,  0xD8
    xvpermi.d     xr27, xr8,  0x8D
    vst           vr26, a2,   0
    xvstelm.d     xr25, a2,   16,   0
    add.d         a2,   a2,   a3
    add.d         a0,   a0,   t1
    vst           vr27, a2,   0
    xvstelm.d     xr25, a2,   16,   2
    add.d         a2,   a2,   a3
    blt           zero, t0,   .loopV_sp_lasx_24x32
    fld.d         f24,  sp,   0
    fld.d         f25,  sp,   8
    fld.d         f26,  sp,   16
    fld.d         f27,  sp,   24
    fld.d         f28,  sp,   32
    fld.d         f29,  sp,   40
    fld.d         f30,  sp,   48
    fld.d         f31,  sp,   56
    addi.d        sp,   sp,   64
endfunc

function x265_interp_8tap_vert_sp_48x64_lasx
    slli.d       a1,    a1,    1
    slli.d       t7,    a4,    4
    slli.d       t1,    a1,    1   //srcStride * 2
    la.local     t6,    g_lumaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  64
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride

    xvldrepl.h   xr16,  t5,    0 + 128
    xvldrepl.h   xr17,  t5,    2 + 128
    xvldrepl.h   xr18,  t5,    4 + 128
    xvldrepl.h   xr19,  t5,    6 + 128
    xvldrepl.h   xr20,  t5,    8 + 128
    xvldrepl.h   xr21,  t5,    10 + 128
    xvldrepl.h   xr22,  t5,    12 + 128
    xvldrepl.h   xr23,  t5,    14 + 128
    xvld         xr7,   t4,    32

.loopV_sp_lasx_48x64:
    xvld         xr0,   a0,    0
    xvld         xr1,   a0,    32
    xvld         xr2,   a0,    64
    add.d        t5,    a0,    a1
    xvor.v       xr8,   xr7,   xr7
    xvor.v       xr9,   xr7,   xr7
    xvor.v       xr10,  xr7,   xr7
    xvor.v       xr11,  xr7,   xr7
    xvor.v       xr12,  xr7,   xr7
    xvor.v       xr13,  xr7,   xr7
    XMADD4_W xr0, xr1, xr16, xr16, xr8, xr9, xr10, xr11
    xvmaddwev.w.h xr12, xr2,   xr16
    xvmaddwod.w.h xr13, xr2,   xr16
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    xvld         xr2,   t5,    64
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr17, xr17, xr8, xr9, xr10, xr11
    xvmaddwev.w.h xr12, xr2,   xr17
    xvmaddwod.w.h xr13, xr2,   xr17
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    xvld         xr2,   t5,    64
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr18, xr18, xr8, xr9, xr10, xr11
    xvmaddwev.w.h xr12, xr2,   xr18
    xvmaddwod.w.h xr13, xr2,   xr18
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    xvld         xr2,   t5,    64
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr19, xr19, xr8, xr9, xr10, xr11
    xvmaddwev.w.h xr12, xr2,   xr19
    xvmaddwod.w.h xr13, xr2,   xr19
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    xvld         xr2,   t5,    64
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr20, xr20, xr8, xr9, xr10, xr11
    xvmaddwev.w.h xr12, xr2,   xr20
    xvmaddwod.w.h xr13, xr2,   xr20
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    xvld         xr2,   t5,    64
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr21, xr21, xr8, xr9, xr10, xr11
    xvmaddwev.w.h xr12, xr2,   xr21
    xvmaddwod.w.h xr13, xr2,   xr21
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    xvld         xr2,   t5,    64
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr22, xr22, xr8, xr9, xr10, xr11
    xvmaddwev.w.h xr12, xr2,   xr22
    xvmaddwod.w.h xr13, xr2,   xr22
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    xvld         xr2,   t5,    64
    XMADD4_W xr0, xr1, xr23, xr23, xr8, xr9, xr10, xr11
    xvmaddwev.w.h xr12, xr2,   xr23
    xvmaddwod.w.h xr13, xr2,   xr23

    xvssrani.h.w  xr13, xr12, 12
    xvssrani.h.w  xr10, xr8,  12
    xvssrani.h.w  xr11, xr9,  12
    xvpermi.d     xr14, xr13, 0xB1
    xvilvl.h      xr3,  xr11, xr10
    xvilvh.h      xr4,  xr11, xr10
    xvilvl.h      xr5,  xr14, xr13
    xvssrani.bu.h xr4,  xr3,  0
    xvssrani.bu.h xr6,  xr5,  0
    xvpermi.d     xr0,  xr4,  0xD8
    xvpermi.d     xr1,  xr6,  0xD8
    addi.d        t0,   t0,   -1
    add.d         a0,   a0,   a1
    xvst          xr0,  a2,   0
    vst           vr1,  a2,   32
    add.d         a2,   a2,   a3
    blt           zero, t0,   .loopV_sp_lasx_48x64
endfunc

.macro FILTER_VERT_SP_WxN_LASX  w, h, rep
function x265_interp_8tap_vert_sp_\w\()x\h\()_lasx
    slli.d       a1,    a1,    1
    slli.d       t7,    a4,    4
    slli.d       t1,    a1,    1   //srcStride * 2
    la.local     t6,    g_lumaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  \h
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride

    xvldrepl.h   xr16,  t5,    0 + 128
    xvldrepl.h   xr17,  t5,    2 + 128
    xvldrepl.h   xr18,  t5,    4 + 128
    xvldrepl.h   xr19,  t5,    6 + 128
    xvldrepl.h   xr20,  t5,    8 + 128
    xvldrepl.h   xr21,  t5,    10 + 128
    xvldrepl.h   xr22,  t5,    12 + 128
    xvldrepl.h   xr23,  t5,    14 + 128
    xvld         xr7,   t4,    32

.loopV_sp_lasx_\w\()x\h:
    move         t1,    a0
    move         t2,    a2
.rept \rep
    xvld         xr0,   t1,    0
    xvld         xr1,   t1,    32
    add.d        t5,    t1,    a1
    xvor.v       xr8,   xr7,   xr7
    xvor.v       xr9,   xr7,   xr7
    xvor.v       xr10,  xr7,   xr7
    xvor.v       xr11,  xr7,   xr7
    XMADD4_W xr0, xr1, xr16, xr16, xr8, xr9, xr10, xr11
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr17, xr17, xr8, xr9, xr10, xr11
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr18, xr18, xr8, xr9, xr10, xr11
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr19, xr19, xr8, xr9, xr10, xr11
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr20, xr20, xr8, xr9, xr10, xr11
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr21, xr21, xr8, xr9, xr10, xr11
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr22, xr22, xr8, xr9, xr10, xr11
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    XMADD4_W xr0, xr1, xr23, xr23, xr8, xr9, xr10, xr11

    xvssrani.h.w  xr10, xr8,  12
    xvssrani.h.w  xr11, xr9,  12
    addi.d        t1,   t1,   64
    xvilvl.h      xr12, xr11, xr10
    xvilvh.h      xr13, xr11, xr10
    xvssrani.bu.h xr13, xr12, 0
    xvpermi.d     xr14, xr13, 0xD8
    xvst          xr14, t2,   0
    addi.d        t2,   t2,   32
.endr
    addi.d        t0,   t0,   -1
    add.d         a0,   a0,   a1
    add.d         a2,   a2,   a3
    blt           zero, t0,   .loopV_sp_lasx_\w\()x\h
endfunc
.endm

FILTER_VERT_SP_WxN_LASX 32, 8,  1
FILTER_VERT_SP_WxN_LASX 32, 16, 1
FILTER_VERT_SP_WxN_LASX 32, 24, 1
FILTER_VERT_SP_WxN_LASX 32, 32, 1
FILTER_VERT_SP_WxN_LASX 32, 64, 1
FILTER_VERT_SP_WxN_LASX 64, 16, 2
FILTER_VERT_SP_WxN_LASX 64, 32, 2
FILTER_VERT_SP_WxN_LASX 64, 48, 2
FILTER_VERT_SP_WxN_LASX 64, 64, 2

.macro FILTER_VERT_SS_4xN  h
function x265_interp_8tap_vert_ss_4x\h\()_lsx
    slli.d       a1,    a1,    1
    slli.d       t7,    a4,    4
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    slli.d       a3,    a3,    1
    la.local     t6,    g_lumaFilter
    addi.d       sp,    sp,    -24
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  \h/4
    sub.d        t6,    a0,    t2  //src -= 3 * srcStride
    fst.d        f24,   sp,    0
    fst.d        f25,   sp,    8
    fst.d        f26,   sp,    16
    vldrepl.h    vr16,  t5,    0 + 128
    vldrepl.h    vr17,  t5,    2 + 128
    vldrepl.h    vr18,  t5,    4 + 128
    vldrepl.h    vr19,  t5,    6 + 128
    vldrepl.h    vr20,  t5,    8 + 128
    vldrepl.h    vr21,  t5,    10 + 128
    vldrepl.h    vr22,  t5,    12 + 128
    vldrepl.h    vr23,  t5,    14 + 128

    add.d        a0,    t6,    t3
    fld.d        f8,    t6,    0    //0
    fldx.d       f9,    t6,    a1   //1
    fldx.d       f10,   t6,    t1   //2
    fldx.d       f11,   t6,    t2   //3

    fld.d        f12,   a0,    0    //4
    fldx.d       f13,   a0,    a1   //5
    fldx.d       f14,   a0,    t1   //6

    add.d        t6,    a0,    t2
    vilvl.h      vr0,   vr9,   vr8  //0,1
    vilvl.h      vr1,   vr10,  vr9  //1,2
    vilvl.h      vr2,   vr11,  vr10 //2,3
    vilvl.h      vr3,   vr12,  vr11 //3,4
    vilvl.h      vr4,   vr13,  vr12 //4,5
    vilvl.h      vr5,   vr14,  vr13 //5,6
.loopV_ss_4x\h:
    fld.d        f15,   t6,    0    //7
    fldx.d       f24,   t6,    a1   //8
    fldx.d       f25,   t6,    t1   //9
    fldx.d       f26,   t6,    t2   //10
    VMULW4_W vr0, vr2, vr16, vr16, vr10, vr11, vr12, vr13
    vilvl.h      vr6,   vr15,  vr14 //6,7
    vilvl.h      vr7,   vr24,  vr15 //7,8
    vilvl.h      vr8,   vr25,  vr24 //8,9
    vilvl.h      vr9,   vr26,  vr25 //9,10

    VMADD4_W vr1, vr3, vr17, vr17, vr10, vr11, vr12, vr13
    VMADD4_W vr2, vr4, vr18, vr18, vr10, vr11, vr12, vr13
    VMADD4_W vr3, vr5, vr19, vr19, vr10, vr11, vr12, vr13
    VMADD4_W vr4, vr6, vr20, vr20, vr10, vr11, vr12, vr13
    VMADD4_W vr5, vr7, vr21, vr21, vr10, vr11, vr12, vr13
    VMADD4_W vr6, vr8, vr22, vr22, vr10, vr11, vr12, vr13
    VMADD4_W vr7, vr9, vr23, vr23, vr10, vr11, vr12, vr13

    vor.v            vr0,  vr4,  vr4
    vor.v            vr1,  vr5,  vr5
    vor.v            vr2,  vr6,  vr6
    vor.v            vr3,  vr7,  vr7
    vssrani.h.w      vr11, vr10, 6
    vssrani.h.w      vr13, vr12, 6
    vor.v            vr4,  vr8,  vr8
    vor.v            vr5,  vr9,  vr9
    vor.v            vr14, vr26, vr26
    vstelm.d         vr11, a2,   0,  0
    add.d            a2,   a2,   a3
    vstelm.d         vr11, a2,   0,  1
    add.d            a2,   a2,   a3
    vstelm.d         vr13, a2,   0,  0
    add.d            a2,   a2,   a3
    vstelm.d         vr13, a2,   0,  1
    add.d            t6,   t6,   t3
    add.d            a2,   a2,   a3
    addi.d           t0,   t0,   -1
    blt              zero, t0,   .loopV_ss_4x\h
    fld.d            f24,  sp,   0
    fld.d            f25,  sp,   8
    fld.d            f26,  sp,   16
    addi.d           sp,   sp,   24
endfunc
.endm

FILTER_VERT_SS_4xN 4
FILTER_VERT_SS_4xN 8
FILTER_VERT_SS_4xN 16

.macro FILTER_VERT_SS_8xN  h
function x265_interp_8tap_vert_ss_8x\h\()_lsx
    slli.d       a1,    a1,    1
    slli.d       a3,    a3,    1
    slli.d       t7,    a4,    4
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    slli.d       t4,    a3,    1
    la.local     t6,    g_lumaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  \h/2
    sub.d        t6,    a0,    t2  //src -= 3 * srcStride
    vldrepl.h    vr16,  t5,    0 + 128
    vldrepl.h    vr17,  t5,    2 + 128
    vldrepl.h    vr18,  t5,    4 + 128
    vldrepl.h    vr19,  t5,    6 + 128
    vldrepl.h    vr20,  t5,    8 + 128
    vldrepl.h    vr21,  t5,    10 + 128
    vldrepl.h    vr22,  t5,    12 + 128
    vldrepl.h    vr23,  t5,    14 + 128

    add.d        a0,    t6,    t3
    vld          vr0,   t6,    0    //0
    vldx         vr1,   t6,    a1   //1
    vldx         vr2,   t6,    t1   //2
    vldx         vr3,   t6,    t2   //3

    vld          vr4,   a0,    0    //4
    vldx         vr5,   a0,    a1   //5
    vldx         vr6,   a0,    t1   //6
    add.d        t6,    a0,    t2

.loopV_ss_8x\h:
    vld          vr7,   t6,    0   //7
    vldx         vr8,   t6,    a1  //8
    VMULW4_W vr0, vr1, vr16, vr16, vr10, vr11, vr12, vr13
    VMADD4_W vr1, vr2, vr17, vr17, vr10, vr11, vr12, vr13
    VMADD4_W vr2, vr3, vr18, vr18, vr10, vr11, vr12, vr13
    VMADD4_W vr3, vr4, vr19, vr19, vr10, vr11, vr12, vr13
    VMADD4_W vr4, vr5, vr20, vr20, vr10, vr11, vr12, vr13
    VMADD4_W vr5, vr6, vr21, vr21, vr10, vr11, vr12, vr13
    VMADD4_W vr6, vr7, vr22, vr22, vr10, vr11, vr12, vr13
    VMADD4_W vr7, vr8, vr23, vr23, vr10, vr11, vr12, vr13

    vor.v            vr0,  vr2,  vr2
    vor.v            vr1,  vr3,  vr3
    vor.v            vr2,  vr4,  vr4
    vor.v            vr3,  vr5,  vr5
    vssrani.h.w      vr12, vr10, 6
    vssrani.h.w      vr13, vr11, 6
    vor.v            vr4,  vr6,  vr6
    vor.v            vr5,  vr7,  vr7
    vilvl.h          vr10, vr13, vr12
    vilvh.h          vr11, vr13, vr12
    vor.v            vr6,  vr8,  vr8

    vst              vr10, a2,   0
    vstx             vr11, a2,   a3
    add.d            t6,   t6,   t1
    addi.d           t0,   t0,   -1
    add.d            a2,   a2,   t4
    blt              zero, t0,   .loopV_ss_8x\h
endfunc
.endm

FILTER_VERT_SS_8xN 4
FILTER_VERT_SS_8xN 8
FILTER_VERT_SS_8xN 16
FILTER_VERT_SS_8xN 32

function x265_interp_8tap_vert_ss_12x16_lsx
    slli.d       a1,    a1,    1
    slli.d       a3,    a3,    1
    slli.d       t7,    a4,    4
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_lumaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  16
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride
    addi.d       sp,    sp,    -32
    fst.d        f24,   sp,    0
    fst.d        f25,   sp,    8
    fst.d        f26,   sp,    16
    fst.d        f27,   sp,    24

    vldrepl.h    vr16,  t5,    0 + 128
    vldrepl.h    vr17,  t5,    2 + 128
    vldrepl.h    vr18,  t5,    4 + 128
    vldrepl.h    vr19,  t5,    6 + 128
    vldrepl.h    vr20,  t5,    8 + 128
    vldrepl.h    vr21,  t5,    10 + 128
    vldrepl.h    vr22,  t5,    12 + 128
    vldrepl.h    vr23,  t5,    14 + 128
    vldi         vr27,  0

    addi.d       t6,    a0,    16
    vld          vr0,   a0,    0    //0
    vldx         vr1,   a0,    a1   //1
    vldx         vr2,   a0,    t1   //2
    vldx         vr3,   a0,    t2   //3

    add.d        a0,    a0,    t3
    fld.d        f8,    t6,    0
    fldx.d       f9,    t6,    a1
    fldx.d       f10,   t6,    t1
    fldx.d       f11,   t6,    t2
    addi.d       t6,    a0,    16

    vilvl.h      vr8,   vr27,  vr8
    vilvl.h      vr9,   vr27,  vr9
    vilvl.h      vr10,  vr27,  vr10
    vilvl.h      vr11,  vr27,  vr11
    vld          vr4,   a0,    0    //4
    vldx         vr5,   a0,    a1   //5
    vldx         vr6,   a0,    t1   //6

    fld.d        f12,   t6,    0
    fldx.d       f13,   t6,    a1
    fldx.d       f14,   t6,    t1
    add.d        a0,    a0,    t2
    vilvl.h      vr12,  vr27,  vr12
    vilvl.h      vr13,  vr27,  vr13
    vilvl.h      vr14,  vr27,  vr14
.loopV_ss_12x16:
    vld          vr7,   a0,    0   //7
    fld.d        f15,   a0,    16  //7
    vilvl.h      vr15,  vr27, vr15
    vmulwev.w.h  vr24,  vr0,  vr16
    vmulwod.w.h  vr25,  vr0,  vr16
    vmulwev.w.h  vr26,  vr8,  vr16

    vmaddwev.w.h vr24,  vr1,  vr17
    vmaddwod.w.h vr25,  vr1,  vr17
    vmaddwev.w.h vr26,  vr9,  vr17

    vmaddwev.w.h vr24,  vr2,  vr18
    vmaddwod.w.h vr25,  vr2,  vr18
    vmaddwev.w.h vr26,  vr10, vr18

    vmaddwev.w.h vr24,  vr3,  vr19
    vmaddwod.w.h vr25,  vr3,  vr19
    vmaddwev.w.h vr26,  vr11, vr19

    vmaddwev.w.h vr24,  vr4,  vr20
    vmaddwod.w.h vr25,  vr4,  vr20
    vmaddwev.w.h vr26,  vr12, vr20

    vmaddwev.w.h vr24,  vr5,  vr21
    vmaddwod.w.h vr25,  vr5,  vr21
    vmaddwev.w.h vr26,  vr13, vr21

    vmaddwev.w.h vr24,  vr6,  vr22
    vmaddwod.w.h vr25,  vr6,  vr22
    vmaddwev.w.h vr26,  vr14, vr22

    vmaddwev.w.h vr24,  vr7,  vr23
    vmaddwod.w.h vr25,  vr7,  vr23
    vmaddwev.w.h vr26,  vr15, vr23

    vor.v            vr0,  vr1,  vr1
    vor.v            vr1,  vr2,  vr2
    vor.v            vr2,  vr3,  vr3
    vor.v            vr3,  vr4,  vr4
    vor.v            vr4,  vr5,  vr5
    vor.v            vr5,  vr6,  vr6
    vor.v            vr6,  vr7,  vr7

    vssrani.h.w      vr26, vr24, 6
    vssrani.h.w      vr27, vr25, 6
    vor.v            vr8,  vr9,  vr9
    vor.v            vr9,  vr10, vr10
    vor.v            vr10, vr11, vr11
    vilvl.h          vr24, vr27, vr26
    vor.v            vr11, vr12, vr12
    vor.v            vr12, vr13, vr13
    vor.v            vr13, vr14, vr14
    vor.v            vr14, vr15, vr15

    vst              vr24, a2,   0
    vstelm.d         vr26, a2,   16,  1
    add.d            a0,   a0,   a1
    addi.d           t0,   t0,   -1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_ss_12x16
    fld.d            f24,  sp,   0
    fld.d            f25,  sp,   8
    fld.d            f26,  sp,   16
    fld.d            f27,  sp,   24
    addi.d           sp,   sp,   32
endfunc

.macro FILTER_VERT_SS_16xN  h
function x265_interp_8tap_vert_ss_16x\h\()_lsx
    slli.d       a1,    a1,    1
    slli.d       a3,    a3,    1
    slli.d       t7,    a4,    4
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_lumaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  \h
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride
    addi.d       sp,    sp,    -32
    fst.d        f24,   sp,    0
    fst.d        f25,   sp,    8
    fst.d        f26,   sp,    16
    fst.d        f27,   sp,    24

    vldrepl.h    vr16,  t5,    0 + 128
    vldrepl.h    vr17,  t5,    2 + 128
    vldrepl.h    vr18,  t5,    4 + 128
    vldrepl.h    vr19,  t5,    6 + 128
    vldrepl.h    vr20,  t5,    8 + 128
    vldrepl.h    vr21,  t5,    10 + 128
    vldrepl.h    vr22,  t5,    12 + 128
    vldrepl.h    vr23,  t5,    14 + 128

    addi.d       t6,    a0,    16
    vld          vr0,   a0,    0    //0
    vldx         vr1,   a0,    a1   //1
    vldx         vr2,   a0,    t1   //2
    vldx         vr3,   a0,    t2   //3

    add.d        a0,    a0,    t3
    vld          vr8,   t6,    0
    vldx         vr9,   t6,    a1
    vldx         vr10,  t6,    t1
    vldx         vr11,  t6,    t2
    addi.d       t6,    a0,    16

    vld          vr4,   a0,    0    //4
    vldx         vr5,   a0,    a1   //5
    vldx         vr6,   a0,    t1   //6

    vld          vr12,  t6,    0
    vldx         vr13,  t6,    a1
    vldx         vr14,  t6,    t1
    add.d        a0,    a0,    t2
.loopV_ss_16x\h:
    vld          vr7,   a0,    0   //7
    vld          vr15,  a0,    16  //7
    VMULW4_W vr0, vr8, vr16, vr16, vr24, vr25, vr26, vr27
    VMADD4_W vr1, vr9, vr17, vr17, vr24, vr25, vr26, vr27
    VMADD4_W vr2, vr10, vr18, vr18, vr24, vr25, vr26, vr27
    VMADD4_W vr3, vr11, vr19, vr19, vr24, vr25, vr26, vr27
    VMADD4_W vr4, vr12, vr20, vr20, vr24, vr25, vr26, vr27
    VMADD4_W vr5, vr13, vr21, vr21, vr24, vr25, vr26, vr27
    VMADD4_W vr6, vr14, vr22, vr22, vr24, vr25, vr26, vr27
    VMADD4_W vr7, vr15, vr23, vr23, vr24, vr25, vr26, vr27

    vor.v            vr0,  vr1,  vr1
    vor.v            vr1,  vr2,  vr2
    vor.v            vr2,  vr3,  vr3
    vor.v            vr3,  vr4,  vr4
    vor.v            vr4,  vr5,  vr5
    vor.v            vr5,  vr6,  vr6
    vor.v            vr6,  vr7,  vr7

    vssrani.h.w      vr26, vr24, 6
    vssrani.h.w      vr27, vr25, 6
    vor.v            vr8,  vr9,  vr9
    vor.v            vr9,  vr10, vr10
    vor.v            vr10, vr11, vr11
    vilvl.h          vr24, vr27, vr26
    vilvh.h          vr25, vr27, vr26
    vor.v            vr11, vr12, vr12
    vor.v            vr12, vr13, vr13
    vor.v            vr13, vr14, vr14
    vor.v            vr14, vr15, vr15

    vst              vr24, a2,   0
    vst              vr25, a2,   16
    add.d            a0,   a0,   a1
    addi.d           t0,   t0,   -1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_ss_16x\h
    fld.d            f24,  sp,   0
    fld.d            f25,  sp,   8
    fld.d            f26,  sp,   16
    fld.d            f27,  sp,   24
    addi.d           sp,   sp,   32
endfunc
.endm

FILTER_VERT_SS_16xN 4
FILTER_VERT_SS_16xN 8
FILTER_VERT_SS_16xN 12
FILTER_VERT_SS_16xN 16
FILTER_VERT_SS_16xN 32
FILTER_VERT_SS_16xN 64

function x265_interp_8tap_vert_ss_24x32_lsx
    slli.d       a1,    a1,    1
    slli.d       a3,    a3,    1
    slli.d       t7,    a4,    4
    slli.d       t1,    a1,    1   //srcStride * 2
    la.local     t6,    g_lumaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  32
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride

    vldrepl.h    vr16,  t5,    0 + 128
    vldrepl.h    vr17,  t5,    2 + 128
    vldrepl.h    vr18,  t5,    4 + 128
    vldrepl.h    vr19,  t5,    6 + 128
    vldrepl.h    vr20,  t5,    8 + 128
    vldrepl.h    vr21,  t5,    10 + 128
    vldrepl.h    vr22,  t5,    12 + 128
    vldrepl.h    vr23,  t5,    14 + 128

.loopV_ss_24x32:
    vld          vr0,   a0,    0
    vld          vr1,   a0,    16
    vld          vr2,   a0,    32
    add.d        t5,    a0,    a1
    VMULW4_W vr0, vr1, vr16, vr16, vr8, vr9, vr10, vr11
    vmulwev.w.h vr12,  vr2, vr16
    vmulwod.w.h vr13,  vr2, vr16
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr17, vr17, vr8, vr9, vr10, vr11
    vmaddwev.w.h vr12,  vr2, vr17
    vmaddwod.w.h vr13,  vr2, vr17
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr18, vr18, vr8, vr9, vr10, vr11
    vmaddwev.w.h vr12,  vr2, vr18
    vmaddwod.w.h vr13,  vr2, vr18
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr19, vr19, vr8, vr9, vr10, vr11
    vmaddwev.w.h vr12,  vr2, vr19
    vmaddwod.w.h vr13,  vr2, vr19
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr20, vr20, vr8, vr9, vr10, vr11
    vmaddwev.w.h vr12,  vr2, vr20
    vmaddwod.w.h vr13,  vr2, vr20
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr21, vr21, vr8, vr9, vr10, vr11
    vmaddwev.w.h vr12,  vr2, vr21
    vmaddwod.w.h vr13,  vr2, vr21
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr22, vr22, vr8, vr9, vr10, vr11
    vmaddwev.w.h vr12,  vr2, vr22
    vmaddwod.w.h vr13,  vr2, vr22
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    VMADD4_W vr0, vr1, vr23, vr23, vr8, vr9, vr10, vr11
    vmaddwev.w.h vr12,  vr2, vr23
    vmaddwod.w.h vr13,  vr2, vr23

    vssrani.h.w  vr10, vr8,  6
    vssrani.h.w  vr11, vr9,  6
    vssrani.h.w  vr13, vr12, 6

    vilvl.h      vr8,  vr11, vr10
    vilvh.h      vr9,  vr11, vr10
    vbsrl.v      vr12, vr13, 8
    addi.d       t0,   t0,   -1
    add.d        a0,   a0,   a1
    vilvl.h      vr10, vr12, vr13

    vst          vr8,  a2,   0
    vst          vr9,  a2,   16
    vst          vr10, a2,   32
    add.d        a2,   a2,   a3
    blt          zero, t0,   .loopV_ss_24x32
endfunc

function x265_interp_8tap_vert_ss_48x64_lsx
    slli.d       a1,    a1,    1
    slli.d       a3,    a3,    1
    slli.d       t7,    a4,    4
    slli.d       t1,    a1,    1   //srcStride * 2
    addi.d       sp,    sp,    -16
    la.local     t6,    g_lumaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  64
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride
    fst.d        f24,   sp,    0
    fst.d        f25,   sp,    8

    vldrepl.h    vr16,  t5,    0 + 128
    vldrepl.h    vr17,  t5,    2 + 128
    vldrepl.h    vr18,  t5,    4 + 128
    vldrepl.h    vr19,  t5,    6 + 128
    vldrepl.h    vr20,  t5,    8 + 128
    vldrepl.h    vr21,  t5,    10 + 128
    vldrepl.h    vr22,  t5,    12 + 128
    vldrepl.h    vr23,  t5,    14 + 128

.loopV_ss_48x64:
    vld          vr0,   a0,    0
    vld          vr1,   a0,    16
    vld          vr2,   a0,    32
    vld          vr3,   a0,    48
    vld          vr4,   a0,    64
    vld          vr5,   a0,    80
    add.d        t5,    a0,    a1
    VMULW4_W vr0, vr1, vr16, vr16, vr6, vr7, vr8, vr9
    VMULW4_W vr2, vr3, vr16, vr16, vr10, vr11, vr12, vr13
    VMULW4_W vr4, vr5, vr16, vr16, vr14, vr15, vr24, vr25
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    vld          vr4,   t5,    64
    vld          vr5,   t5,    80
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr17, vr17, vr6, vr7, vr8, vr9
    VMADD4_W vr2, vr3, vr17, vr17, vr10, vr11, vr12, vr13
    VMADD4_W vr4, vr5, vr17, vr17, vr14, vr15, vr24, vr25
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    vld          vr4,   t5,    64
    vld          vr5,   t5,    80
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr18, vr18, vr6, vr7, vr8, vr9
    VMADD4_W vr2, vr3, vr18, vr18, vr10, vr11, vr12, vr13
    VMADD4_W vr4, vr5, vr18, vr18, vr14, vr15, vr24, vr25
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    vld          vr4,   t5,    64
    vld          vr5,   t5,    80
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr19, vr19, vr6, vr7, vr8, vr9
    VMADD4_W vr2, vr3, vr19, vr19, vr10, vr11, vr12, vr13
    VMADD4_W vr4, vr5, vr19, vr19, vr14, vr15, vr24, vr25
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    vld          vr4,   t5,    64
    vld          vr5,   t5,    80
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr20, vr20, vr6, vr7, vr8, vr9
    VMADD4_W vr2, vr3, vr20, vr20, vr10, vr11, vr12, vr13
    VMADD4_W vr4, vr5, vr20, vr20, vr14, vr15, vr24, vr25
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    vld          vr4,   t5,    64
    vld          vr5,   t5,    80
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr21, vr21, vr6, vr7, vr8, vr9
    VMADD4_W vr2, vr3, vr21, vr21, vr10, vr11, vr12, vr13
    VMADD4_W vr4, vr5, vr21, vr21, vr14, vr15, vr24, vr25
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    vld          vr4,   t5,    64
    vld          vr5,   t5,    80
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr22, vr22, vr6, vr7, vr8, vr9
    VMADD4_W vr2, vr3, vr22, vr22, vr10, vr11, vr12, vr13
    VMADD4_W vr4, vr5, vr22, vr22, vr14, vr15, vr24, vr25
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    vld          vr4,   t5,    64
    vld          vr5,   t5,    80
    VMADD4_W vr0, vr1, vr23, vr23, vr6, vr7, vr8, vr9
    VMADD4_W vr2, vr3, vr23, vr23, vr10, vr11, vr12, vr13
    VMADD4_W vr4, vr5, vr23, vr23, vr14, vr15, vr24, vr25

    vssrani.h.w  vr8,  vr6,  6
    vssrani.h.w  vr9,  vr7,  6
    vssrani.h.w  vr12, vr10, 6
    vssrani.h.w  vr13, vr11, 6
    vssrani.h.w  vr24, vr14, 6
    vssrani.h.w  vr25, vr15, 6

    vilvl.h      vr6,  vr9,  vr8
    vilvh.h      vr7,  vr9,  vr8
    vilvl.h      vr10, vr13, vr12
    vilvh.h      vr11, vr13, vr12
    vilvl.h      vr14, vr25, vr24
    vilvh.h      vr15, vr25, vr24
    vst          vr6,  a2,   0
    vst          vr7,  a2,   16
    vst          vr10, a2,   32
    vst          vr11, a2,   48
    vst          vr14, a2,   64
    vst          vr15, a2,   80
    addi.d       t0,   t0,   -1
    add.d        a0,   a0,   a1
    add.d        a2,   a2,   a3
    blt          zero, t0,   .loopV_ss_48x64
    fld.d        f24,  sp,   0
    fld.d        f25,  sp,   8
    addi.d       sp,   sp,   16
endfunc

.macro FILTER_VERT_SS_WxN  w, h, rep
function x265_interp_8tap_vert_ss_\w\()x\h\()_lsx
    slli.d       a1,    a1,    1
    slli.d       a3,    a3,    1
    slli.d       t7,    a4,    4
    slli.d       t1,    a1,    1   //srcStride * 2
    la.local     t6,    g_lumaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  \h
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride

    vldrepl.h    vr16,  t5,    0 + 128
    vldrepl.h    vr17,  t5,    2 + 128
    vldrepl.h    vr18,  t5,    4 + 128
    vldrepl.h    vr19,  t5,    6 + 128
    vldrepl.h    vr20,  t5,    8 + 128
    vldrepl.h    vr21,  t5,    10 + 128
    vldrepl.h    vr22,  t5,    12 + 128
    vldrepl.h    vr23,  t5,    14 + 128

.loopV_ss_\w\()x\h:
    move         t1,    a0
    move         t2,    a2
.rept \rep
    vld          vr0,   t1,    0
    vld          vr1,   t1,    16
    vld          vr2,   t1,    32
    vld          vr3,   t1,    48
    add.d        t5,    t1,    a1
    VMULW4_W vr0, vr1, vr16, vr16, vr8, vr9, vr10, vr11
    VMULW4_W vr2, vr3, vr16, vr16, vr12, vr13, vr14, vr15
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr17, vr17, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr17, vr17, vr12, vr13, vr14, vr15
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr18, vr18, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr18, vr18, vr12, vr13, vr14, vr15
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr19, vr19, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr19, vr19, vr12, vr13, vr14, vr15
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr20, vr20, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr20, vr20, vr12, vr13, vr14, vr15
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr21, vr21, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr21, vr21, vr12, vr13, vr14, vr15
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr22, vr22, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr22, vr22, vr12, vr13, vr14, vr15
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    VMADD4_W vr0, vr1, vr23, vr23, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr23, vr23, vr12, vr13, vr14, vr15

    vssrani.h.w  vr10, vr8,  6
    vssrani.h.w  vr11, vr9,  6
    vssrani.h.w  vr14, vr12, 6
    vssrani.h.w  vr15, vr13, 6
    addi.d       t1,   t1,   64
    vilvl.h      vr4,  vr11, vr10
    vilvh.h      vr5,  vr11, vr10
    vilvl.h      vr6,  vr15, vr14
    vilvh.h      vr7,  vr15, vr14
    vst          vr4,  t2,   0
    vst          vr5,  t2,   16
    vst          vr6,  t2,   32
    vst          vr7,  t2,   48
    addi.d       t2,   t2,   64
.endr
    addi.d       t0,   t0,   -1
    add.d        a0,   a0,   a1
    add.d        a2,   a2,   a3
    blt          zero, t0,   .loopV_ss_\w\()x\h
endfunc
.endm

FILTER_VERT_SS_WxN 32, 8,  1
FILTER_VERT_SS_WxN 32, 16, 1
FILTER_VERT_SS_WxN 32, 24, 1
FILTER_VERT_SS_WxN 32, 32, 1
FILTER_VERT_SS_WxN 32, 64, 1
FILTER_VERT_SS_WxN 64, 16, 2
FILTER_VERT_SS_WxN 64, 32, 2
FILTER_VERT_SS_WxN 64, 48, 2
FILTER_VERT_SS_WxN 64, 64, 2

.macro FILTER_VERT_SS_16xN_LASX  h
function x265_interp_8tap_vert_ss_16x\h\()_lasx
    slli.d       a1,    a1,    1
    slli.d       a3,    a3,    1
    slli.d       t7,    a4,    4
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_lumaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  \h/2
    sub.d        t6,    a0,    t2  //src -= 3 * srcStride
    slli.d       t7,    a3,    1
    xvldrepl.h   xr16,  t5,    0 + 128
    xvldrepl.h   xr17,  t5,    2 + 128
    xvldrepl.h   xr18,  t5,    4 + 128
    xvldrepl.h   xr19,  t5,    6 + 128
    xvldrepl.h   xr20,  t5,    8 + 128
    xvldrepl.h   xr21,  t5,    10 + 128
    xvldrepl.h   xr22,  t5,    12 + 128
    xvldrepl.h   xr23,  t5,    14 + 128

    add.d        a0,    t6,    t3
    xvld         xr0,   t6,    0
    xvldx        xr1,   t6,    a1
    xvldx        xr2,   t6,    t1
    xvldx        xr3,   t6,    t2
    xvld         xr4,   a0,    0
    xvldx        xr5,   a0,    a1
    xvldx        xr6,   a0,    t1
    add.d        t6,    a0,    t2
.loopV_ss_lasx_16x\h:
    xvld         xr7,   t6,    0
    xvldx        xr8,   t6,    a1
    XMULW4_W xr0, xr1, xr16, xr16, xr10, xr11, xr12, xr13
    XMADD4_W xr1, xr2, xr17, xr17, xr10, xr11, xr12, xr13
    XMADD4_W xr2, xr3, xr18, xr18, xr10, xr11, xr12, xr13
    XMADD4_W xr3, xr4, xr19, xr19, xr10, xr11, xr12, xr13
    XMADD4_W xr4, xr5, xr20, xr20, xr10, xr11, xr12, xr13
    XMADD4_W xr5, xr6, xr21, xr21, xr10, xr11, xr12, xr13
    XMADD4_W xr6, xr7, xr22, xr22, xr10, xr11, xr12, xr13
    XMADD4_W xr7, xr8, xr23, xr23, xr10, xr11, xr12, xr13

    xvor.v        xr0,  xr2,  xr2
    xvor.v        xr1,  xr3,  xr3
    xvor.v        xr2,  xr4,  xr4
    xvor.v        xr3,  xr5,  xr5
    xvor.v        xr4,  xr6,  xr6
    xvor.v        xr5,  xr7,  xr7
    xvor.v        xr6,  xr8,  xr8
    xvssrani.h.w  xr12, xr10, 6
    xvssrani.h.w  xr13, xr11, 6
    xvilvl.h      xr14, xr13, xr12
    xvilvh.h      xr15, xr13, xr12
    addi.d        t0,   t0,   -1
    xvst          xr14, a2,   0
    xvstx         xr15, a2,   a3
    add.d         t6,   t6,   t1
    add.d         a2,   a2,   t7
    blt           zero, t0,   .loopV_ss_lasx_16x\h
endfunc
.endm

FILTER_VERT_SS_16xN_LASX 4
FILTER_VERT_SS_16xN_LASX 8
FILTER_VERT_SS_16xN_LASX 12
FILTER_VERT_SS_16xN_LASX 16
FILTER_VERT_SS_16xN_LASX 32
FILTER_VERT_SS_16xN_LASX 64

function x265_interp_8tap_vert_ss_24x32_lasx
    slli.d       a1,    a1,    1
    slli.d       a3,    a3,    1
    slli.d       t7,    a4,    4
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_lumaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  16
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride
    addi.d       sp,    sp,    -64
    xvldrepl.h   xr16,  t5,    0 + 128
    xvldrepl.h   xr17,  t5,    2 + 128
    xvldrepl.h   xr18,  t5,    4 + 128
    xvldrepl.h   xr19,  t5,    6 + 128
    xvldrepl.h   xr20,  t5,    8 + 128
    xvldrepl.h   xr21,  t5,    10 + 128
    xvldrepl.h   xr22,  t5,    12 + 128
    xvldrepl.h   xr23,  t5,    14 + 128
    fst.d        f24,   sp,    0
    fst.d        f25,   sp,    8
    fst.d        f26,   sp,    16
    fst.d        f27,   sp,    24
    fst.d        f28,   sp,    32
    fst.d        f29,   sp,    40
    fst.d        f30,   sp,    48
    fst.d        f31,   sp,    56

    addi.d       t6,    a0,    32
    xvld         xr0,   a0,    0
    xvldx        xr1,   a0,    a1
    xvldx        xr2,   a0,    t1
    xvldx        xr3,   a0,    t2

    add.d        a0,    a0,    t3
    vld          vr9,   t6,    0
    vldx         vr10,  t6,    a1
    vldx         vr11,  t6,    t1
    vldx         vr12,  t6,    t2
    addi.d       t6,    a0,    32

    xvld         xr4,   a0,    0
    xvldx        xr5,   a0,    a1
    xvldx        xr6,   a0,    t1

    vld          vr13,  t6,    0
    vldx         vr14,  t6,    a1
    vldx         vr15,  t6,    t1
    add.d        a0,    a0,    t2
    xvpermi.q    xr9,   xr10,  0x2
    xvpermi.q    xr10,  xr11,  0x2
    xvpermi.q    xr11,  xr12,  0x2
    xvpermi.q    xr12,  xr13,  0x2
    xvpermi.q    xr13,  xr14,  0x2
    xvpermi.q    xr14,  xr15,  0x2
.loopV_ss_lasx_24x32:
    addi.d       t6,    a0,    32
    xvld         xr7,   a0,    0
    xvldx        xr8,   a0,    a1
    vld          vr24,  t6,    0
    vldx         vr25,  t6,    a1
    XMULW4_W xr0, xr1, xr16, xr16, xr26, xr27, xr28, xr29
    xvmulwev.w.h xr30,  xr9,   xr16
    xvmulwod.w.h xr31,  xr9,   xr16
    xvpermi.q    xr15,  xr24,  0x2
    xvpermi.q    xr24,  xr25,  0x2
    XMADD4_W xr1, xr2, xr17, xr17, xr26, xr27, xr28, xr29
    xvmaddwev.w.h xr30,  xr10, xr17
    xvmaddwod.w.h xr31,  xr10, xr17
    XMADD4_W xr2, xr3, xr18, xr18, xr26, xr27, xr28, xr29
    xvmaddwev.w.h xr30,  xr11, xr18
    xvmaddwod.w.h xr31,  xr11, xr18
    XMADD4_W xr3, xr4, xr19, xr19, xr26, xr27, xr28, xr29
    xvmaddwev.w.h xr30,  xr12, xr19
    xvmaddwod.w.h xr31,  xr12, xr19
    XMADD4_W xr4, xr5, xr20, xr20, xr26, xr27, xr28, xr29
    xvmaddwev.w.h xr30,  xr13, xr20
    xvmaddwod.w.h xr31,  xr13, xr20
    XMADD4_W xr5, xr6, xr21, xr21, xr26, xr27, xr28, xr29
    xvmaddwev.w.h xr30,  xr14, xr21
    xvmaddwod.w.h xr31,  xr14, xr21
    XMADD4_W xr6, xr7, xr22, xr22, xr26, xr27, xr28, xr29
    xvmaddwev.w.h xr30,  xr15, xr22
    xvmaddwod.w.h xr31,  xr15, xr22
    XMADD4_W xr7, xr8, xr23, xr23, xr26, xr27, xr28, xr29
    xvmaddwev.w.h xr30,  xr24, xr23
    xvmaddwod.w.h xr31,  xr24, xr23

    xvor.v        xr0,  xr2,  xr2
    xvor.v        xr1,  xr3,  xr3
    xvor.v        xr2,  xr4,  xr4
    xvor.v        xr3,  xr5,  xr5
    xvor.v        xr4,  xr6,  xr6
    xvor.v        xr5,  xr7,  xr7
    xvor.v        xr6,  xr8,  xr8
    xvor.v        xr9,  xr11, xr11
    xvor.v        xr10, xr12, xr12
    xvor.v        xr11, xr13, xr13
    xvor.v        xr12, xr14, xr14
    xvor.v        xr13, xr15, xr15
    xvor.v        xr14, xr24, xr24
    xvor.v        xr15, xr25, xr25
    xvssrani.h.w  xr31, xr30, 6
    xvssrani.h.w  xr28, xr26, 6
    xvssrani.h.w  xr29, xr27, 6
    xvpermi.d     xr30, xr31, 0xB1
    xvilvl.h      xr7,  xr29, xr28
    xvilvh.h      xr8,  xr29, xr28
    xvilvl.h      xr24, xr30, xr31
    addi.d        t0,   t0,   -1
    xvst          xr7,  a2,   0
    vst           vr24, a2,   32
    add.d         a2,   a2,   a3
    xvpermi.d     xr25, xr24, 0x4E
    add.d         a0,   a0,   t1
    xvst          xr8,  a2,   0
    vst           vr25, a2,   32
    add.d         a2,   a2,   a3
    blt           zero, t0,   .loopV_ss_lasx_24x32
    fld.d         f24,  sp,   0
    fld.d         f25,  sp,   8
    fld.d         f26,  sp,   16
    fld.d         f27,  sp,   24
    fld.d         f28,  sp,   32
    fld.d         f29,  sp,   40
    fld.d         f30,  sp,   48
    fld.d         f31,  sp,   56
    addi.d        sp,   sp,   64
endfunc

function x265_interp_8tap_vert_ss_48x64_lasx
    slli.d       a1,    a1,    1
    slli.d       a3,    a3,    1
    slli.d       t7,    a4,    4
    slli.d       t1,    a1,    1   //srcStride * 2
    la.local     t6,    g_lumaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  64
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride

    xvldrepl.h   xr16,  t5,    0 + 128
    xvldrepl.h   xr17,  t5,    2 + 128
    xvldrepl.h   xr18,  t5,    4 + 128
    xvldrepl.h   xr19,  t5,    6 + 128
    xvldrepl.h   xr20,  t5,    8 + 128
    xvldrepl.h   xr21,  t5,    10 + 128
    xvldrepl.h   xr22,  t5,    12 + 128
    xvldrepl.h   xr23,  t5,    14 + 128
.loopV_ss_lasx_48x64:
    xvld         xr0,   a0,    0
    xvld         xr1,   a0,    32
    xvld         xr2,   a0,    64
    add.d        t5,    a0,    a1
    XMULW4_W xr0, xr1, xr16, xr16, xr8, xr9, xr10, xr11
    xvmulwev.w.h xr12,  xr2,   xr16
    xvmulwod.w.h xr13,  xr2,   xr16
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    xvld         xr2,   t5,    64
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr17, xr17, xr8, xr9, xr10, xr11
    xvmaddwev.w.h xr12, xr2,   xr17
    xvmaddwod.w.h xr13, xr2,   xr17
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    xvld         xr2,   t5,    64
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr18, xr18, xr8, xr9, xr10, xr11
    xvmaddwev.w.h xr12, xr2,   xr18
    xvmaddwod.w.h xr13, xr2,   xr18
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    xvld         xr2,   t5,    64
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr19, xr19, xr8, xr9, xr10, xr11
    xvmaddwev.w.h xr12, xr2,   xr19
    xvmaddwod.w.h xr13, xr2,   xr19
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    xvld         xr2,   t5,    64
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr20, xr20, xr8, xr9, xr10, xr11
    xvmaddwev.w.h xr12, xr2,   xr20
    xvmaddwod.w.h xr13, xr2,   xr20
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    xvld         xr2,   t5,    64
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr21, xr21, xr8, xr9, xr10, xr11
    xvmaddwev.w.h xr12, xr2,   xr21
    xvmaddwod.w.h xr13, xr2,   xr21
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    xvld         xr2,   t5,    64
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr22, xr22, xr8, xr9, xr10, xr11
    xvmaddwev.w.h xr12, xr2,   xr22
    xvmaddwod.w.h xr13, xr2,   xr22
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    xvld         xr2,   t5,    64
    XMADD4_W xr0, xr1, xr23, xr23, xr8, xr9, xr10, xr11
    xvmaddwev.w.h xr12, xr2,   xr23
    xvmaddwod.w.h xr13, xr2,   xr23

    xvssrani.h.w  xr13, xr12, 6
    xvssrani.h.w  xr10, xr8,  6
    xvssrani.h.w  xr11, xr9,  6
    xvpermi.d     xr14, xr13, 0xB1
    xvilvl.h      xr3,  xr11, xr10
    xvilvh.h      xr4,  xr11, xr10
    xvilvl.h      xr5,  xr14, xr13
    xvst          xr3,  a2,   0
    xvst          xr4,  a2,   32
    xvst          xr5,  a2,   64
    addi.d        t0,   t0,   -1
    add.d         a0,   a0,   a1
    add.d         a2,   a2,   a3
    blt           zero, t0,   .loopV_ss_lasx_48x64
endfunc

.macro FILTER_VERT_SS_WxN_LASX  w, h, rep
function x265_interp_8tap_vert_ss_\w\()x\h\()_lasx
    slli.d       a1,    a1,    1
    slli.d       a3,    a3,    1
    slli.d       t7,    a4,    4
    slli.d       t1,    a1,    1   //srcStride * 2
    la.local     t6,    g_lumaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  \h
    sub.d        a0,    a0,    t2  //src -= 3 * srcStride

    xvldrepl.h   xr16,  t5,    0 + 128
    xvldrepl.h   xr17,  t5,    2 + 128
    xvldrepl.h   xr18,  t5,    4 + 128
    xvldrepl.h   xr19,  t5,    6 + 128
    xvldrepl.h   xr20,  t5,    8 + 128
    xvldrepl.h   xr21,  t5,    10 + 128
    xvldrepl.h   xr22,  t5,    12 + 128
    xvldrepl.h   xr23,  t5,    14 + 128

.loopV_ss_lasx_\w\()x\h:
    move         t1,    a0
    move         t2,    a2
.rept \rep
    xvld         xr0,   t1,    0
    xvld         xr1,   t1,    32
    add.d        t5,    t1,    a1
    XMULW4_W xr0, xr1, xr16, xr16, xr8, xr9, xr10, xr11
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr17, xr17, xr8, xr9, xr10, xr11
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr18, xr18, xr8, xr9, xr10, xr11
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr19, xr19, xr8, xr9, xr10, xr11
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr20, xr20, xr8, xr9, xr10, xr11
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr21, xr21, xr8, xr9, xr10, xr11
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr22, xr22, xr8, xr9, xr10, xr11
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    XMADD4_W xr0, xr1, xr23, xr23, xr8, xr9, xr10, xr11

    xvssrani.h.w  xr10, xr8,  6
    xvssrani.h.w  xr11, xr9,  6
    addi.d        t1,   t1,   64
    xvilvl.h      xr12, xr11, xr10
    xvilvh.h      xr13, xr11, xr10
    xvst          xr12, t2,   0
    xvst          xr13, t2,   32
    addi.d        t2,   t2,   64
.endr
    addi.d        t0,   t0,   -1
    add.d         a0,   a0,   a1
    add.d         a2,   a2,   a3
    blt           zero, t0,   .loopV_ss_lasx_\w\()x\h
endfunc
.endm

FILTER_VERT_SS_WxN_LASX 32, 8,  1
FILTER_VERT_SS_WxN_LASX 32, 16, 1
FILTER_VERT_SS_WxN_LASX 32, 24, 1
FILTER_VERT_SS_WxN_LASX 32, 32, 1
FILTER_VERT_SS_WxN_LASX 32, 64, 1
FILTER_VERT_SS_WxN_LASX 64, 16, 2
FILTER_VERT_SS_WxN_LASX 64, 32, 2
FILTER_VERT_SS_WxN_LASX 64, 48, 2
FILTER_VERT_SS_WxN_LASX 64, 64, 2

.macro PROCESS_4TAP_LUMA in0, in1, in2, in3, in4, in5, in6, in7, \
                         out0, out1, tmp0, tmp1, tmp2, tmp3
    vhaddw.w.h   \in0,   \in0,  \in0
    vhaddw.w.h   \in1,   \in1,  \in1
    vhaddw.w.h   \in2,   \in2,  \in2
    vhaddw.w.h   \in3,   \in3,  \in3
    vhaddw.w.h   \in4,   \in4,  \in4
    vhaddw.w.h   \in5,   \in5,  \in5
    vhaddw.w.h   \in6,   \in6,  \in6
    vhaddw.w.h   \in7,   \in7,  \in7
    vpickev.h    \tmp0,  \in1,  \in0
    vpickev.h    \tmp1,  \in3,  \in2
    vpickev.h    \tmp2,  \in5,  \in4
    vpickev.h    \tmp3,  \in7,  \in6
    vhaddw.w.h   \tmp0,  \tmp0, \tmp0
    vhaddw.w.h   \tmp1,  \tmp1, \tmp1
    vhaddw.w.h   \tmp2,  \tmp2, \tmp2
    vhaddw.w.h   \tmp3,  \tmp3, \tmp3
    vpickev.h    \out0,  \tmp1, \tmp0
    vpickev.h    \out1,  \tmp3, \tmp2
.endm

.macro FILTER_HORIZ_4TAP_LUMA_2xN  h
function x265_interp_4tap_horiz_pp_2x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t2,    a1,    1
    slli.d       t4,    a1,    2
    la.local     t6,    g_chromaFilter
    addi.d       t0,    zero,  \h/4
    add.d        t3,    t2,    a1
    addi.d       t1,    a0,    -1
    vldx         vr10,  t6,    t7
.loopH_4tap_2x\h:
    fld.s        f0,    t1,    0
    fld.s        f1,    a0,    0
    fldx.s       f2,    t1,    a1
    fldx.s       f3,    a0,    a1
    fldx.s       f4,    t1,    t2
    fldx.s       f5,    a0,    t2
    fldx.s       f6,    t1,    t3
    fldx.s       f7,    a0,    t3

    vilvl.b      vr11,  vr2,   vr0
    vilvl.b      vr12,  vr3,   vr1
    vilvl.b      vr13,  vr6,   vr4
    vilvl.b      vr14,  vr7,   vr5

    vilvl.d      vr0,   vr12,  vr11
    vilvl.d      vr1,   vr14,  vr13

    VMULW4_H vr0, vr1, vr10, vr10, vr4, vr5, vr6, vr7

    vhaddw.w.h   vr11,  vr4,   vr4
    vhaddw.w.h   vr12,  vr5,   vr5
    vhaddw.w.h   vr13,  vr6,   vr6
    vhaddw.w.h   vr14,  vr7,   vr7

    vpickev.h    vr0,   vr12,  vr11
    vpickev.h    vr1,   vr14,  vr13
    vhaddw.w.h   vr2,   vr0,   vr0
    vhaddw.w.h   vr3,   vr1,   vr1

    vpickev.h    vr4,   vr3,   vr2
    add.d        a0,    a0,    t4
    vssrarni.bu.h vr5,  vr4,   6
    add.d        t1,    t1,    t4
    vstelm.h     vr5,   a2,    0,    0
    add.d        a2,    a2,    a3
    vstelm.h     vr5,   a2,    0,    1
    add.d        a2,    a2,    a3
    vstelm.h     vr5,   a2,    0,    2
    add.d        a2,    a2,    a3
    vstelm.h     vr5,   a2,    0,    3
    addi.d       t0,    t0,    -1
    add.d        a2,    a2,    a3
    blt          zero,  t0,    .loopH_4tap_2x\h
endfunc
.endm

FILTER_HORIZ_4TAP_LUMA_2xN  4
FILTER_HORIZ_4TAP_LUMA_2xN  8
FILTER_HORIZ_4TAP_LUMA_2xN  16

function x265_interp_4tap_horiz_pp_4x2_lsx
    slli.d       t7,    a4,    5
    add.d        t0,    a0,    a1
    la.local     t6,    g_chromaFilter
    vldx         vr10,  t6,    t7
    fld.s        f0,    a0,    -1
    fld.s        f1,    a0,    0
    fld.s        f2,    a0,    1
    fld.s        f3,    a0,    2
    fld.s        f4,    t0,    -1
    fld.s        f5,    t0,    0
    fld.s        f6,    t0,    1
    fld.s        f7,    t0,    2

    vilvl.b      vr11,  vr2,   vr0
    vilvl.b      vr12,  vr3,   vr1
    vilvl.b      vr13,  vr6,   vr4
    vilvl.b      vr14,  vr7,   vr5

    vilvl.d      vr0,   vr12,  vr11
    vilvl.d      vr1,   vr14,  vr13

    VMULW4_H vr0, vr1, vr10, vr10, vr11, vr12, vr13, vr14

    vhaddw.w.h   vr2,   vr11,  vr11
    vhaddw.w.h   vr3,   vr12,  vr12
    vhaddw.w.h   vr4,   vr13,  vr13
    vhaddw.w.h   vr5,   vr14,  vr14

    vpickev.h    vr0,   vr3,   vr2
    vpickev.h    vr1,   vr5,   vr4
    vhaddw.w.h   vr6,   vr0,   vr0
    vhaddw.w.h   vr7,   vr1,   vr1
    vpickev.h    vr8,   vr7,   vr6

    vssrarni.bu.h vr9,  vr8,  6
    vstelm.w     vr9,  a2,    0,    0
    add.d        a2,    a2,    a3
    vstelm.w     vr9,  a2,    0,    1
    addi.d       t0,    t0,    -1
    add.d        a2,    a2,    a3
endfunc

.macro FILTER_HORIZ_4TAP_LUMA_4xN  h
function x265_interp_4tap_horiz_pp_4x\h\()_lsx
    slli.d       t7,    a4,    5
    la.local     t6,    g_chromaFilter
    addi.d       t0,    zero,  \h/4
    vldx         vr10,  t6,    t7
.loopH_4tap_4x\h:
    fld.s        f0,    a0,    -1
    fld.s        f1,    a0,    0
    fld.s        f2,    a0,    1
    fld.s        f3,    a0,    2
    add.d        a0,    a0,    a1
    vilvl.b      vr11,  vr2,   vr0
    vilvl.b      vr12,  vr3,   vr1
    fld.s        f4,    a0,    -1
    fld.s        f5,    a0,    0
    fld.s        f6,    a0,    1
    fld.s        f7,    a0,    2
    add.d        a0,    a0,    a1
    vilvl.b      vr13,  vr6,   vr4
    vilvl.b      vr14,  vr7,   vr5
    fld.d        f0,    a0,    -1
    fld.d        f1,    a0,    0
    fld.d        f2,    a0,    1
    fld.d        f3,    a0,    2
    add.d        a0,    a0,    a1
    vilvl.b      vr15,  vr2,   vr0
    vilvl.b      vr16,  vr3,   vr1
    fld.d        f4,    a0,    -1
    fld.d        f5,    a0,    0
    fld.d        f6,    a0,    1
    fld.d        f7,    a0,    2
    add.d        a0,    a0,    a1
    vilvl.b      vr17,  vr6,   vr4
    vilvl.b      vr18,  vr7,   vr5

    vilvl.d      vr0,   vr12,  vr11
    vilvl.d      vr1,   vr14,  vr13
    vilvl.d      vr2,   vr16,  vr15
    vilvl.d      vr3,   vr18,  vr17

    VMULW4_H vr0, vr1, vr10, vr10, vr11, vr12, vr13, vr14
    VMULW4_H vr2, vr3, vr10, vr10, vr15, vr16, vr17, vr18

    PROCESS_4TAP_LUMA vr11, vr12, vr13, vr14, vr15, vr16, vr17, vr18, \
                      vr20, vr21, vr0, vr1, vr2, vr3

    vssrarni.bu.h vr21, vr20, 6
    vstelm.w     vr21,  a2,    0,    0
    add.d        a2,    a2,    a3
    vstelm.w     vr21,  a2,    0,    1
    add.d        a2,    a2,    a3
    vstelm.w     vr21,  a2,    0,    2
    add.d        a2,    a2,    a3
    vstelm.w     vr21,  a2,    0,    3
    addi.d       t0,    t0,    -1
    add.d        a2,    a2,    a3
    blt          zero,  t0,    .loopH_4tap_4x\h
endfunc
.endm

FILTER_HORIZ_4TAP_LUMA_4xN  4
FILTER_HORIZ_4TAP_LUMA_4xN  8
FILTER_HORIZ_4TAP_LUMA_4xN  16
FILTER_HORIZ_4TAP_LUMA_4xN  32

.macro FILTER_HORIZ_4TAP_LUMA_6xN  h
function x265_interp_4tap_horiz_pp_6x\h\()_lsx
    slli.d       t7,    a4,    5
    la.local     t6,    g_chromaFilter
    addi.d       t0,    zero,  \h/2
    vldx         vr10,  t6,    t7
.loopH_4tap_6x\h:
    add.d        t2,    a0,    a1
    fld.d        f0,    a0,    -1
    fld.d        f1,    a0,    0
    fld.d        f2,    a0,    1
    fld.d        f3,    a0,    2
    fld.d        f4,    t2,    -1
    fld.d        f5,    t2,    0
    fld.d        f6,    t2,    1
    fld.d        f7,    t2,    2

    vilvl.b      vr11,  vr2,   vr0
    vilvl.b      vr12,  vr3,   vr1
    vilvl.b      vr13,  vr6,   vr4
    vilvl.b      vr14,  vr7,   vr5

    VMULW4_H vr11, vr12, vr10, vr10, vr0, vr1, vr2, vr3
    VMULW4_H vr13, vr14, vr10, vr10, vr4, vr5, vr6, vr7

.irp x, vr0, vr1, vr2, vr3, vr4, vr5, vr6, vr7
    vhaddw.w.h   \x, \x, \x
.endr

    vpickev.h       vr11, vr1,  vr0
    vpickev.h       vr12, vr3,  vr2
    vpickev.h       vr13, vr5,  vr4
    vpickev.h       vr14, vr7,  vr6

.irp x, vr11, vr12, vr13, vr14
    vhaddw.w.h   \x, \x, \x
.endr

    vpackev.h       vr8,  vr12, vr11
    vpackev.h       vr9,  vr14, vr13
    add.d           a0,   t2,   a1
    vssrarni.bu.h   vr9,  vr8,  6
    vshuf4i.h       vr11, vr9,  0xd8
    vstelm.w        vr11, a2,   0,    0
    vstelm.h        vr11, a2,   4,    2
    add.d           a2,   a2,   a3
    vstelm.w        vr11, a2,   0,    2
    vstelm.h        vr11, a2,   4,    6
    addi.d          t0,   t0,   -1
    add.d           a2,   a2,   a3
    blt             zero, t0,   .loopH_4tap_6x\h
endfunc
.endm

FILTER_HORIZ_4TAP_LUMA_6xN 8
FILTER_HORIZ_4TAP_LUMA_6xN 16

.macro FILTER_HORIZ_4TAP_LUMA_8xN  h
function x265_interp_4tap_horiz_pp_8x\h\()_lsx
    slli.d       t7,    a4,    5
    la.local     t6,    g_chromaFilter
    addi.d       t0,    zero,  \h/2
    vldx         vr10,  t6,    t7
.loopH_4tap_8x\h:
    add.d        t2,    a0,    a1
    fld.d        f0,    a0,    -1
    fld.d        f1,    a0,    0
    fld.d        f2,    a0,    1
    fld.d        f3,    a0,    2
    fld.d        f4,    t2,    -1
    fld.d        f5,    t2,    0
    fld.d        f6,    t2,    1
    fld.d        f7,    t2,    2

    vilvl.b      vr11,  vr2,   vr0
    vilvl.b      vr12,  vr3,   vr1
    vilvl.b      vr13,  vr6,   vr4
    vilvl.b      vr14,  vr7,   vr5

    VMULW4_H vr11, vr12, vr10, vr10, vr0, vr1, vr2, vr3
    VMULW4_H vr13, vr14, vr10, vr10, vr4, vr5, vr6, vr7

.irp x, vr0, vr1, vr2, vr3, vr4, vr5, vr6, vr7
    vhaddw.w.h   \x, \x, \x
.endr

    vpickev.h       vr11, vr1,  vr0
    vpickev.h       vr12, vr3,  vr2
    vpickev.h       vr13, vr5,  vr4
    vpickev.h       vr14, vr7,  vr6

.irp x, vr11, vr12, vr13, vr14
    vhaddw.w.h   \x, \x, \x
.endr

    vpackev.h       vr8,  vr12, vr11
    vpackev.h       vr9,  vr14, vr13
    add.d           a0,   t2,   a1
    vssrarni.bu.h   vr9,  vr8,  6
    vshuf4i.h       vr11, vr9,  0xd8
    vstelm.d        vr11, a2,   0,    0
    add.d           a2,   a2,   a3
    vstelm.d        vr11, a2,   0,    1
    addi.d          t0,   t0,   -1
    add.d           a2,   a2,   a3
    blt             zero, t0,   .loopH_4tap_8x\h
endfunc
.endm

FILTER_HORIZ_4TAP_LUMA_8xN 2
FILTER_HORIZ_4TAP_LUMA_8xN 4
FILTER_HORIZ_4TAP_LUMA_8xN 6
FILTER_HORIZ_4TAP_LUMA_8xN 8
FILTER_HORIZ_4TAP_LUMA_8xN 12
FILTER_HORIZ_4TAP_LUMA_8xN 16
FILTER_HORIZ_4TAP_LUMA_8xN 32
FILTER_HORIZ_4TAP_LUMA_8xN 64

.macro FILTER_HORIZ_4TAP_LUMA_12xN h
function x265_interp_4tap_horiz_pp_12x\h\()_lsx
    slli.d       t7,    a4,    5
    la.local     t6,    g_chromaFilter
    addi.d       t0,    zero,  \h/2
    vldx         vr10,  t6,    t7
.loopH_4tap_12x\h:
    add.d        t1,    a0,    a1
    vld          vr0,   a0,    -1
    vld          vr1,   a0,    0
    vld          vr2,   a0,    1
    vld          vr3,   a0,    2
    vld          vr4,   t1,    -1
    vld          vr5,   t1,    0
    vld          vr6,   t1,    1
    vld          vr7,   t1,    2

    vilvh.w      vr8,   vr4,   vr0
    vilvh.w      vr9,   vr5,   vr1
    vilvh.w      vr11,  vr6,   vr2
    vilvh.w      vr12,  vr7,   vr3

    vilvl.b      vr13,  vr1,   vr0
    vilvl.b      vr14,  vr3,   vr2
    vilvl.b      vr15,  vr5,   vr4
    vilvl.b      vr16,  vr7,   vr6
    vilvl.b      vr17,  vr9,   vr8
    vilvl.b      vr18,  vr12,  vr11

    VMULW4_H vr13, vr14, vr10, vr10, vr0, vr1, vr2, vr3
    VMULW4_H vr15, vr16, vr10, vr10, vr4, vr5, vr6, vr7
    VMULW4_H vr17, vr18, vr10, vr10, vr19, vr20, vr21, vr22

.irp x, vr0, vr1, vr2, vr3, vr4, vr5, vr6, vr7, vr19, vr20, vr21, vr22
    vhaddw.w.h  \x, \x, \x
.endr

    vpickev.h      vr11, vr2,  vr0
    vpickev.h      vr12, vr3,  vr1
    vpickev.h      vr13, vr6,  vr4
    vpickev.h      vr14, vr7,  vr5
    vpickev.h      vr15, vr21, vr19
    vpickev.h      vr16, vr22, vr20

.irp x, vr11, vr12, vr15, vr16, vr13, vr14
    vhaddw.w.h \x, \x, \x
.endr

    vpackev.h      vr0,  vr12, vr11
    vpackev.h      vr1,  vr16, vr15
    vpackev.h      vr2,  vr14, vr13

    vssrarni.bu.h  vr1,  vr0,  6
    vssrarni.bu.h  vr3,  vr2,  6

    vshuf4i.h      vr4,  vr1,  0xD8
    vshuf4i.h      vr5,  vr3,  0xD8
    vstelm.d       vr4,  a2,   0,    0
    vstelm.w       vr4,  a2,   8,    2
    add.d          a2,   a2,   a3
    add.d          a0,   t1,   a1
    addi.d         t0,   t0,   -1
    vstelm.d       vr5,  a2,   0,    0
    vstelm.w       vr4,  a2,   8,    3
    add.d          a2,   a2,   a3
    blt            zero, t0,   .loopH_4tap_12x\h
endfunc
.endm

FILTER_HORIZ_4TAP_LUMA_12xN  16
FILTER_HORIZ_4TAP_LUMA_12xN  32

.macro FILTER_HORIZ_4TAP_LUMA_16xN  h
function x265_interp_4tap_horiz_pp_16x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t3,    a3,    1
    la.local     t6,    g_chromaFilter
    addi.d       t0,    zero,  \h/2
    vldx         vr10,  t6,    t7
.loopH_4tap_16x\h:
    add.d        t1,    a0,    a1
    vld          vr0,   a0,    -1
    vld          vr1,   a0,    0
    vld          vr2,   a0,    1
    vld          vr3,   a0,    2
    vld          vr4,   t1,    -1
    vld          vr5,   t1,    0
    vld          vr6,   t1,    1
    vld          vr7,   t1,    2

    vilvl.b      vr8,   vr1,   vr0
    vilvl.b      vr9,   vr3,   vr2
    vilvh.b      vr11,  vr1,   vr0
    vilvh.b      vr12,  vr3,   vr2
    vilvl.b      vr13,  vr5,   vr4
    vilvl.b      vr14,  vr7,   vr6
    vilvh.b      vr15,  vr5,   vr4
    vilvh.b      vr16,  vr7,   vr6

    VMULW4_H vr8, vr9, vr10, vr10, vr0, vr1, vr2, vr3
    VMULW4_H vr11, vr12, vr10, vr10, vr4, vr5, vr6, vr7
    VMULW4_H vr13, vr14, vr10, vr10, vr8, vr9, vr17, vr18
    VMULW4_H vr15, vr16, vr10, vr10, vr19, vr20, vr21, vr22

.irp x, vr0, vr1, vr2, vr3, vr4, vr5, vr6, vr7,\
     vr8, vr9, vr17, vr18, vr19, vr20, vr21, vr22
    vhaddw.w.h  \x, \x, \x
.endr

    vpickev.h      vr11, vr2,  vr0
    vpickev.h      vr12, vr3,  vr1
    vpickev.h      vr13, vr6,  vr4
    vpickev.h      vr14, vr7,  vr5
    vpickev.h      vr15, vr17, vr8
    vpickev.h      vr16, vr18, vr9
    vpickev.h      vr0,  vr21, vr19
    vpickev.h      vr1,  vr22, vr20

.irp x, vr11, vr12, vr13, vr14, vr15, vr16, vr0, vr1
    vhaddw.w.h  \x, \x, \x
.endr

    vpackev.h      vr2,  vr12, vr11
    vpackev.h      vr3,  vr14, vr13
    vpackev.h      vr4,  vr16, vr15
    vpackev.h      vr5,  vr1,  vr0

    vssrarni.bu.h  vr3,  vr2,  6
    vssrarni.bu.h  vr5,  vr4,  6

    vshuf4i.h      vr6,  vr3,  0xD8
    vshuf4i.h      vr7,  vr5,  0xD8

    vst            vr6,  a2,    0
    vstx           vr7,  a2,    a3
    addi.d         t0,   t0,    -1
    add.d          a0,   t1,    a1
    add.d          a2,   a2,    t3
    blt            zero, t0,    .loopH_4tap_16x\h
endfunc
.endm

FILTER_HORIZ_4TAP_LUMA_16xN 4
FILTER_HORIZ_4TAP_LUMA_16xN 8
FILTER_HORIZ_4TAP_LUMA_16xN 12
FILTER_HORIZ_4TAP_LUMA_16xN 16
FILTER_HORIZ_4TAP_LUMA_16xN 24
FILTER_HORIZ_4TAP_LUMA_16xN 32
FILTER_HORIZ_4TAP_LUMA_16xN 64

.macro FILTER_HORIZ_4TAP_LUMA_24xN h
function x265_interp_4tap_horiz_pp_24x\h\()_lsx
    slli.d       t7,    a4,    5
    la.local     t6,    g_chromaFilter
    addi.d       t0,    zero,  \h
    vldx         vr10,  t6,    t7
.loopH_4tap_24x\h:
    vld          vr0,   a0,    -1
    vld          vr1,   a0,    0
    vld          vr2,   a0,    1
    vld          vr3,   a0,    2
    fld.d        f4,    a0,    15
    fld.d        f5,    a0,    16
    fld.d        f6,    a0,    17
    fld.d        f7,    a0,    18

    vilvl.b      vr8,   vr1,   vr0
    vilvl.b      vr9,   vr3,   vr2
    vilvh.b      vr11,  vr1,   vr0
    vilvh.b      vr12,  vr3,   vr2
    vilvl.b      vr13,  vr5,   vr4
    vilvl.b      vr14,  vr7,   vr6

    VMULW4_H vr8, vr9, vr10, vr10, vr0, vr1, vr2, vr3
    VMULW4_H vr11, vr12, vr10, vr10, vr4, vr5, vr6, vr7
    VMULW4_H vr13, vr14, vr10, vr10, vr8, vr9, vr17, vr18

.irp x, vr0, vr1, vr2, vr3, vr4, vr5, vr6, vr7, vr8, vr9, vr17, vr18
    vhaddw.w.h  \x, \x, \x
.endr

    vpickev.h      vr11, vr2,  vr0
    vpickev.h      vr12, vr3,  vr1
    vpickev.h      vr13, vr6,  vr4
    vpickev.h      vr14, vr7,  vr5
    vpickev.h      vr15, vr17, vr8
    vpickev.h      vr16, vr18, vr9

.irp x, vr11, vr12, vr13, vr14, vr15, vr16
    vhaddw.w.h  \x, \x, \x
.endr

    vpackev.h      vr2,  vr12, vr11
    vpackev.h      vr3,  vr14, vr13
    vpackev.h      vr4,  vr16, vr15

    vssrarni.bu.h  vr3,  vr2,  6
    vssrarni.bu.h  vr5,  vr4,  6

    vshuf4i.h      vr6,  vr3,  0xD8
    vshuf4i.h      vr7,  vr5,  0xD8

    vst            vr6,  a2,   0
    vstelm.d       vr7,  a2,   16,   0
    add.d          a0,   a0,   a1
    addi.d         t0,   t0,   -1
    add.d          a2,   a2,   a3
    blt            zero, t0,   .loopH_4tap_24x\h
endfunc
.endm

FILTER_HORIZ_4TAP_LUMA_24xN  32
FILTER_HORIZ_4TAP_LUMA_24xN  64

.macro FILTER_HORIZ_4TAP_LUMA_WxN  w, h, rep
function x265_interp_4tap_horiz_pp_\w\()x\h\()_lsx
    slli.d       t7,    a4,    5
    la.local     t6,    g_chromaFilter
    addi.d       t0,    zero,  \h
    vldx         vr10,  t6,    t7
.loopH_4tap_\w\()x\h:
    move         t1,    a0
    move         t2,    a2
.rept  \rep
    vld          vr0,   t1,    -1
    vld          vr1,   t1,    0
    vld          vr2,   t1,    1
    vld          vr3,   t1,    2

    vilvl.b      vr8,   vr1,   vr0
    vilvl.b      vr9,   vr3,   vr2
    vilvh.b      vr11,  vr1,   vr0
    vilvh.b      vr12,  vr3,   vr2

    VMULW4_H vr8, vr9, vr10, vr10, vr0, vr1, vr2, vr3
    VMULW4_H vr11, vr12, vr10, vr10, vr4, vr5, vr6, vr7

.irp x, vr0, vr1, vr2, vr3, vr4, vr5, vr6, vr7
    vhaddw.w.h  \x, \x, \x
.endr

    vpickev.h      vr11, vr2,  vr0
    vpickev.h      vr12, vr3,  vr1
    vpickev.h      vr13, vr6,  vr4
    vpickev.h      vr14, vr7,  vr5

.irp x, vr11, vr12, vr13, vr14
    vhaddw.w.h  \x, \x, \x
.endr

    vpackev.h      vr2,  vr12, vr11
    vpackev.h      vr3,  vr14, vr13

    vssrarni.bu.h  vr3,  vr2,  6
    addi.d         t1,   t1,   16
    vshuf4i.h      vr6,  vr3,  0xD8
    vst            vr6,  t2,   0
    addi.d         t2,   t2,   16
.endr
    addi.d         t0,   t0,   -1
    add.d          a0,   a0,   a1
    add.d          a2,   a2,   a3
    blt            zero, t0,   .loopH_4tap_\w\()x\h
endfunc
.endm

FILTER_HORIZ_4TAP_LUMA_WxN 32, 8,  2
FILTER_HORIZ_4TAP_LUMA_WxN 32, 16, 2
FILTER_HORIZ_4TAP_LUMA_WxN 32, 24, 2
FILTER_HORIZ_4TAP_LUMA_WxN 32, 32, 2
FILTER_HORIZ_4TAP_LUMA_WxN 32, 48, 2
FILTER_HORIZ_4TAP_LUMA_WxN 32, 64, 2

FILTER_HORIZ_4TAP_LUMA_WxN 48, 64, 3

FILTER_HORIZ_4TAP_LUMA_WxN 64, 16, 4
FILTER_HORIZ_4TAP_LUMA_WxN 64, 32, 4
FILTER_HORIZ_4TAP_LUMA_WxN 64, 48, 4
FILTER_HORIZ_4TAP_LUMA_WxN 64, 64, 4

.macro FILTER_HORIZ_4TAP_LUMA_16xN_LASX  h
function x265_interp_4tap_horiz_pp_16x\h\()_lasx
    slli.d       t7,    a4,    5
    slli.d       t3,    a3,    1
    la.local     t6,    g_chromaFilter
    addi.d       t0,    zero,  \h/2
    xvldx        xr10,  t6,    t7
.loopH_4tap_lasx_16x\h:
    add.d        t1,    a0,    a1
    vld          vr0,   a0,    -1
    vld          vr1,   a0,    0
    vld          vr2,   a0,    1
    vld          vr3,   a0,    2
    vld          vr4,   t1,    -1
    vld          vr5,   t1,    0
    vld          vr6,   t1,    1
    vld          vr7,   t1,    2

    vilvl.b      vr8,   vr1,   vr0
    vilvl.b      vr9,   vr3,   vr2
    vilvh.b      vr11,  vr1,   vr0
    vilvh.b      vr12,  vr3,   vr2

    vilvl.b      vr13,  vr5,   vr4
    vilvl.b      vr14,  vr7,   vr6
    vilvh.b      vr15,  vr5,   vr4
    vilvh.b      vr16,  vr7,   vr6

    xvpermi.q    xr13,  xr8,   0x20
    xvpermi.q    xr14,  xr9,   0x20
    xvpermi.q    xr15,  xr11,  0x20
    xvpermi.q    xr16,  xr12,  0x20
    XMULW4_H xr13, xr14, xr10, xr10, xr8, xr9, xr17, xr18
    XMULW4_H xr15, xr16, xr10, xr10, xr19, xr20, xr21, xr22

.irp x, xr8, xr9, xr17, xr18, xr19, xr20, xr21, xr22
    xvhaddw.w.h  \x, \x, \x
.endr

    xvpickev.h     xr15, xr17, xr8
    xvpickev.h     xr16, xr18, xr9
    xvpickev.h     xr0,  xr21, xr19
    xvpickev.h     xr1,  xr22, xr20

.irp x, xr15, xr16, xr0, xr1
    xvhaddw.w.h   \x, \x, \x
.endr

    xvpackev.h     xr4,  xr16, xr15
    xvpackev.h     xr5,  xr1,  xr0

    xvssrarni.bu.h xr5,  xr4,  6

    xvshuf4i.h     xr6,  xr5,  0xD8
    addi.d         t0,   t0,    -1
    add.d          a0,   t1,    a1
    xvpermi.d      xr7,  xr6,  0x4E

    vst            vr6,  a2,    0
    vstx           vr7,  a2,    a3
    add.d          a2,   a2,    t3
    blt            zero, t0,    .loopH_4tap_lasx_16x\h
endfunc
.endm

FILTER_HORIZ_4TAP_LUMA_16xN_LASX 4
FILTER_HORIZ_4TAP_LUMA_16xN_LASX 8
FILTER_HORIZ_4TAP_LUMA_16xN_LASX 12
FILTER_HORIZ_4TAP_LUMA_16xN_LASX 16
FILTER_HORIZ_4TAP_LUMA_16xN_LASX 24
FILTER_HORIZ_4TAP_LUMA_16xN_LASX 32
FILTER_HORIZ_4TAP_LUMA_16xN_LASX 64

.macro FILTER_HORIZ_4TAP_LUMA_24xN_LASX h
function x265_interp_4tap_horiz_pp_24x\h\()_lasx
    slli.d       t7,    a4,    5
    la.local     t6,    g_chromaFilter
    addi.d       t0,    zero,  \h/2
    xvldx        xr10,  t6,    t7
.loopH_4tap_lasx_24x\h:
    add.d        t1,    a0,    a1
    xvld         xr0,   a0,    -1
    xvld         xr1,   a0,    0
    xvld         xr2,   a0,    1
    xvld         xr3,   a0,    2
    xvld         xr20,  t1,    -1
    xvld         xr21,  t1,    0
    xvld         xr22,  t1,    1
    xvld         xr23,  t1,    2

    xvilvl.b     xr4,   xr1,   xr0
    xvilvl.b     xr5,   xr3,   xr2
    xvilvl.b     xr6,   xr21,  xr20
    xvilvl.b     xr7,   xr23,  xr22
    xvilvh.b     xr8,   xr1,   xr0
    xvilvh.b     xr9,   xr3,   xr2
    xvilvh.b     xr12,  xr21,  xr20
    xvilvh.b     xr13,  xr23,  xr22

    xvpermi.q    xr12,  xr8,   0x20
    xvpermi.q    xr13,  xr9,   0x20

    XMULW4_H xr4, xr5, xr10, xr10, xr0, xr1, xr2, xr3
    XMULW4_H xr6, xr7, xr10, xr10, xr14, xr15, xr16, xr17
    XMULW4_H xr12, xr13, xr10, xr10, xr18, xr19, xr20, xr21

.irp x, xr0, xr1, xr2, xr3, xr14, xr15, xr16, xr17, xr18, xr19, xr20, xr21
    xvhaddw.w.h  \x, \x, \x
.endr

    xvpickev.h      xr4, xr2,  xr0
    xvpickev.h      xr5, xr3,  xr1
    xvpickev.h      xr6, xr16, xr14
    xvpickev.h      xr7, xr17, xr15
    xvpickev.h      xr8, xr20, xr18
    xvpickev.h      xr9, xr21, xr19

.irp x, xr4, xr5, xr6, xr7, xr8, xr9
    xvhaddw.w.h  \x, \x, \x
.endr

    xvpackev.h     xr0,  xr5,  xr4
    xvpackev.h     xr2,  xr9,  xr8
    xvpackev.h     xr1,  xr7,  xr6
    xvpermi.d      xr3,  xr2,  0x4E

    xvssrarni.bu.h xr1,  xr0,  6
    vssrarni.bu.h  vr3,  vr2,  6

    xvshuf4i.h     xr4,  xr1,  0xD8
    vshuf4i.h      vr5,  vr3,  0xD8

    add.d          t2,   a2,   a3
    xvilvl.d       xr6,  xr5,  xr4
    xvilvh.d       xr7,  xr5,  xr4
    vst            vr6,  a2,   0
    xvstelm.d      xr6,  a2,   16,   2
    add.d          a0,   t1,   a1
    addi.d         t0,   t0,   -1
    vst            vr7,  t2,   0
    xvstelm.d      xr7,  t2,   16,   2
    add.d          a2,   t2,   a3
    blt            zero, t0,   .loopH_4tap_lasx_24x\h
endfunc
.endm

FILTER_HORIZ_4TAP_LUMA_24xN_LASX  32
FILTER_HORIZ_4TAP_LUMA_24xN_LASX  64

function x265_interp_4tap_horiz_pp_48x64_lasx
    slli.d       t7,    a4,    5
    la.local     t6,    g_chromaFilter
    addi.d       t0,    zero,  64
    xvldx        xr10,  t6,    t7
.loopH_4tap_lasx_48x64:
    xvld         xr0,   a0,    -1
    xvld         xr1,   a0,    0
    xvld         xr2,   a0,    1
    xvld         xr3,   a0,    2
    vld          vr20,  a0,    31
    vld          vr21,  a0,    32
    vld          vr22,  a0,    33
    vld          vr23,  a0,    34

    xvilvl.b     xr4,   xr1,   xr0
    xvilvl.b     xr5,   xr3,   xr2
    vilvl.b      vr6,   vr21,  vr20
    vilvl.b      vr7,   vr23,  vr22
    xvilvh.b     xr8,   xr1,   xr0
    xvilvh.b     xr9,   xr3,   xr2
    vilvh.b      vr12,  vr21,  vr20
    vilvh.b      vr13,  vr23,  vr22

    xvpermi.q    xr12,  xr6,   0x20
    xvpermi.q    xr13,  xr7,   0x20
    XMULW4_H xr4, xr5, xr10, xr10, xr0, xr1, xr2, xr3
    XMULW4_H xr8, xr9, xr10, xr10, xr14, xr15, xr16, xr17
    XMULW4_H xr12, xr13, xr10, xr10, xr18, xr19, xr20, xr21

.irp x, xr0, xr1, xr2, xr3, xr14, xr15, xr16, xr17, xr18, xr19, xr20, xr21
    xvhaddw.w.h  \x, \x, \x
.endr

    xvpickev.h   xr4,  xr2,  xr0
    xvpickev.h   xr5,  xr3,  xr1
    xvpickev.h   xr6,  xr16, xr14
    xvpickev.h   xr7,  xr17, xr15
    xvpickev.h   xr8,  xr20, xr18
    xvpickev.h   xr9,  xr21, xr19

.irp x, xr4, xr5, xr6, xr7, xr8, xr9
    xvhaddw.w.h  \x, \x, \x
.endr

    xvpackev.h     xr0,  xr5,  xr4
    xvpackev.h     xr2,  xr9,  xr8
    xvpackev.h     xr1,  xr7,  xr6
    xvpermi.d      xr3,  xr2,  0x4E

    xvssrarni.bu.h xr1,  xr0,  6
    vssrarni.bu.h  vr3,  vr2,  6

    xvshuf4i.h     xr4,  xr1,  0xD8
    vshuf4i.h      vr5,  vr3,  0xD8

    xvst           xr4,  a2,   0
    vst            vr5,  a2,   32
    addi.d         t0,   t0,   -1
    add.d          a0,   a0,   a1
    add.d          a2,   a2,   a3
    blt            zero, t0,   .loopH_4tap_lasx_48x64
endfunc

.macro FILTER_HORIZ_4TAP_LUMA_WxN_LASX  w, h, rep
function x265_interp_4tap_horiz_pp_\w\()x\h\()_lasx
    slli.d       t7,    a4,    5
    la.local     t6,    g_chromaFilter
    addi.d       t0,    zero,  \h/2
    xvldx        xr10,  t6,    t7
    slli.d       t3,    a1,    1
    slli.d       t4,    a3,    1
.loopH_4tap_lasx_\w\()x\h:
    move         t1,    a0
    move         t2,    a2
.rept  \rep
    add.d        t5,    t1,    a1
    xvld         xr0,   t1,    -1
    xvld         xr1,   t1,    0
    xvld         xr2,   t1,    1
    xvld         xr3,   t1,    2
    xvld         xr20,  t5,    -1
    xvld         xr21,  t5,    0
    xvld         xr22,  t5,    1
    xvld         xr23,  t5,    2

    xvilvl.b     xr4,   xr1,   xr0
    xvilvl.b     xr5,   xr3,   xr2
    xvilvl.b     xr6,   xr21,  xr20
    xvilvl.b     xr7,   xr23,  xr22
    xvilvh.b     xr8,   xr1,   xr0
    xvilvh.b     xr9,   xr3,   xr2
    xvilvh.b     xr12,  xr21,  xr20
    xvilvh.b     xr13,  xr23,  xr22

    XMULW4_H xr4, xr5, xr10, xr10, xr0, xr1, xr2, xr3
    XMULW4_H xr6, xr7, xr10, xr10, xr14, xr15, xr16, xr17
    XMULW4_H xr8, xr9, xr10, xr10, xr4, xr5, xr6, xr7
    XMULW4_H xr12, xr13, xr10, xr10, xr18, xr19, xr20, xr21

.irp x, xr0, xr1, xr2, xr3, xr14, xr15, xr16, xr17, \
     xr4, xr5, xr6, xr7, xr18, xr19, xr20, xr21
    xvhaddw.w.h  \x, \x, \x
.endr
    xvpickev.h   xr8,  xr2,  xr0
    xvpickev.h   xr9,  xr3,  xr1
    xvpickev.h   xr12, xr16, xr14
    xvpickev.h   xr13, xr17, xr15
    xvpickev.h   xr0,  xr6,  xr4
    xvpickev.h   xr1,  xr7,  xr5
    xvpickev.h   xr2,  xr20, xr18
    xvpickev.h   xr3,  xr21, xr19

.irp x, xr8, xr9, xr12, xr13, xr0, xr1, xr2, xr3
    xvhaddw.w.h  \x, \x, \x
.endr

    xvpackev.h     xr4,  xr9,  xr8
    xvpackev.h     xr5,  xr13, xr12
    xvpackev.h     xr6,  xr1,  xr0
    xvpackev.h     xr7,  xr3,  xr2

    xvssrarni.bu.h xr5,  xr4,  6
    xvssrarni.bu.h xr7,  xr6,  6

    xvshuf4i.h     xr0,  xr5,  0xD8
    xvshuf4i.h     xr1,  xr7,  0xD8

    xvilvl.d       xr2,  xr1,  xr0
    xvilvh.d       xr3,  xr1,  xr0
    addi.d         t1,   t1,   32
    xvst           xr2,  t2,   0
    xvstx          xr3,  t2,   a3
    addi.d         t2,   t2,   32
.endr
    addi.d         t0,   t0,   -1
    add.d          a0,   a0,   t3
    add.d          a2,   a2,   t4
    blt            zero, t0,   .loopH_4tap_lasx_\w\()x\h
endfunc
.endm

FILTER_HORIZ_4TAP_LUMA_WxN_LASX 32, 8,  1
FILTER_HORIZ_4TAP_LUMA_WxN_LASX 32, 16, 1
FILTER_HORIZ_4TAP_LUMA_WxN_LASX 32, 24, 1
FILTER_HORIZ_4TAP_LUMA_WxN_LASX 32, 32, 1
FILTER_HORIZ_4TAP_LUMA_WxN_LASX 32, 48, 1
FILTER_HORIZ_4TAP_LUMA_WxN_LASX 32, 64, 1

FILTER_HORIZ_4TAP_LUMA_WxN_LASX 64, 16, 2
FILTER_HORIZ_4TAP_LUMA_WxN_LASX 64, 32, 2
FILTER_HORIZ_4TAP_LUMA_WxN_LASX 64, 48, 2
FILTER_HORIZ_4TAP_LUMA_WxN_LASX 64, 64, 2

.macro FILTER_HORIZ_4TAP_PS_2xN  h
function x265_interp_4tap_horiz_ps_2x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       a3,    a3,    1
    slli.d       t2,    a1,    1  //srcStride*2
    slli.d       t4,    a1,    2  //srcStride*4
    la.local     t6,    g_chromaFilter
    la.local     t5,    h_psOffset
    vldx         vr10,  t6,    t7
    vld          vr11,  t5,    0
    addi.d       t0,    zero,  \h/4
    add.d        t3,    t2,    a1  //srcStride*3
    beqz         a5,    .loopS_4tap_2x\h
    sub.d        a0,    a0,    a1
    addi.d       t1,    a0,    -1
    fld.s        f1,    a0,    0
    fldx.s       f3,    a0,    a1
    fldx.s       f5,    a0,    t2
    fld.s        f0,    t1,    0
    fldx.s       f2,    t1,    a1
    fldx.s       f4,    t1,    t2
    vilvl.b      vr6,   vr2,   vr0
    vilvl.b      vr7,   vr3,   vr1
    vilvl.w      vr9,   vr5,   vr4
    vilvl.d      vr8,   vr7,   vr6
    vilvl.b      vr3,   vr4,   vr9
    vmulwev.h.bu.b vr0, vr8,   vr10
    vmulwod.h.bu.b vr1, vr8,   vr10
    vmulwev.h.bu.b vr2, vr3,   vr10
    vhaddw.w.h   vr0,   vr0,   vr0
    vhaddw.w.h   vr1,   vr1,   vr1
    vhaddw.w.h   vr2,   vr2,   vr2
    vpickev.h    vr3,   vr1,   vr0
    vpickev.h    vr4,   vr5,   vr2
    vhaddw.w.h   vr3,   vr3,   vr3
    vhaddw.w.h   vr4,   vr4,   vr4
    vpickev.h    vr5,   vr4,   vr3
    vadd.h       vr6,   vr5,   vr11
    add.d        a0,    a0,    t3
    vstelm.w     vr6,   a2,    0,   0
    add.d        a2,    a2,    a3
    vstelm.w     vr6,   a2,    0,   1
    add.d        a2,    a2,    a3
    vstelm.w     vr6,   a2,    0,   2
    add.d        a2,    a2,    a3
.loopS_4tap_2x\h:
    addi.d       t1,    a0,    -1
    fld.s        f1,    a0,    0
    fldx.s       f3,    a0,    a1
    fldx.s       f5,    a0,    t2
    fldx.s       f7,    a0,    t3
    fld.s        f0,    t1,    0
    fldx.s       f2,    t1,    a1
    fldx.s       f4,    t1,    t2
    fldx.s       f6,    t1,    t3
    add.d        a0,    a0,    t4
    vilvl.b      vr12,  vr2,   vr0
    vilvl.b      vr13,  vr3,   vr1
    vilvl.b      vr14,  vr6,   vr4
    vilvl.b      vr15,  vr7,   vr5
    vilvl.d      vr8,   vr13,  vr12
    vilvl.d      vr9,   vr15,  vr14

    VMULW4_H  vr8, vr9, vr10, vr10, vr0, vr1, vr2, vr3
.irp x, vr0, vr1, vr2, vr3
    vhaddw.w.h  \x, \x, \x
.endr
    vpickev.h    vr4,   vr1,   vr0
    vpickev.h    vr5,   vr3,   vr2
    vhaddw.w.h   vr4,   vr4,   vr4
    vhaddw.w.h   vr5,   vr5,   vr5
    vpickev.h    vr6,   vr5,   vr4
    vadd.h       vr7,   vr6,   vr11
    addi.d       t0,    t0,    -1
    vstelm.w     vr7,   a2,    0,    0
    add.d        a2,    a2,    a3
    vstelm.w     vr7,   a2,    0,    1
    add.d        a2,    a2,    a3
    vstelm.w     vr7,   a2,    0,    2
    add.d        a2,    a2,    a3
    vstelm.w     vr7,   a2,    0,    3
    add.d        a2,    a2,    a3
    blt          zero,  t0,    .loopS_4tap_2x\h
endfunc
.endm

FILTER_HORIZ_4TAP_PS_2xN  4
FILTER_HORIZ_4TAP_PS_2xN  8
FILTER_HORIZ_4TAP_PS_2xN  16

.macro FILTER_HORIZ_4TAP_PS_4xN  h
function x265_interp_4tap_horiz_ps_4x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       a3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t5,    h_psOffset
    vldx         vr10,  t6,    t7
    vld          vr11,  t5,    0
    addi.d       t0,    zero,  \h/2
    beqz         a5,    .loopS_4tap_4x\h
    sub.d        a0,    a0,    a1
    addi.d       t0,    t0,    1

    fld.s        f0,    a0,    -1
    fld.s        f1,    a0,    0
    fld.s        f2,    a0,    1
    fld.s        f3,    a0,    2
    vilvl.b      vr4,   vr2,   vr0
    vilvl.b      vr5,   vr3,   vr1
    vilvl.d      vr6,   vr5,   vr4
    vmulwev.h.bu.b vr7, vr6,   vr10
    vmulwod.h.bu.b vr8, vr6,   vr10
    vhaddw.w.h   vr7,   vr7,   vr7
    vhaddw.w.h   vr8,   vr8,   vr8
    vpickev.h    vr9,   vr8,   vr7
    vhaddw.w.h   vr9,   vr9,   vr9
    vpickev.h    vr6,   vr0,   vr9
    vadd.h       vr7,   vr6,   vr11
    add.d        a0,    a0,    a1
    fst.d        f7,    a2,    0
    add.d        a2,    a2,    a3
.loopS_4tap_4x\h:
    fld.s        f0,    a0,    -1
    fld.s        f1,    a0,    0
    fld.s        f2,    a0,    1
    fld.s        f3,    a0,    2
    add.d        a0,    a0,    a1
    vilvl.b      vr4,   vr2,   vr0
    vilvl.b      vr5,   vr3,   vr1
    fld.s        f16,   a0,    -1
    fld.s        f17,   a0,    0
    fld.s        f18,   a0,    1
    fld.s        f19,   a0,    2
    vilvl.b      vr6,   vr18,  vr16
    vilvl.b      vr7,   vr19,  vr17
    add.d        a0,    a0,    a1
    vilvl.d      vr8,   vr5,   vr4
    vilvl.d      vr9,   vr7,   vr6
    VMULW4_H vr8, vr9, vr10, vr10, vr12, vr13, vr14, vr15
.irp x, vr12, vr13, vr14, vr15
    vhaddw.w.h  \x, \x, \x
.endr
    vpickev.h    vr16,  vr13,  vr12
    vpickev.h    vr17,  vr15,  vr14
    vhaddw.w.h   vr16,  vr16,  vr16
    vhaddw.w.h   vr17,  vr17,  vr17
    vpickev.h    vr18,  vr17,  vr16
    vadd.h       vr19,  vr18,  vr11
    addi.d       t0,    t0,    -1
    vstelm.d     vr19,  a2,    0,    0
    add.d        a2,    a2,    a3
    vstelm.d     vr19,  a2,    0,    1
    add.d        a2,    a2,    a3
    blt          zero,  t0,    .loopS_4tap_4x\h
endfunc
.endm

FILTER_HORIZ_4TAP_PS_4xN  2
FILTER_HORIZ_4TAP_PS_4xN  4
FILTER_HORIZ_4TAP_PS_4xN  8
FILTER_HORIZ_4TAP_PS_4xN  16
FILTER_HORIZ_4TAP_PS_4xN  32

.macro FILTER_HORIZ_4TAP_PS_6xN  h
function x265_interp_4tap_horiz_ps_6x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       a3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t5,    h_psOffset
    vldx         vr10,  t6,    t7
    vld          vr11,  t5,    0
    addi.d       t0,    zero,  \h
    beqz         a5,    .loopS_4tap_6x\h
    sub.d        a0,    a0,    a1
    addi.d       t0,    t0,    3
.loopS_4tap_6x\h:
    fld.d        f0,    a0,    -1
    fld.d        f1,    a0,    0
    fld.d        f2,    a0,    1
    fld.d        f3,    a0,    2
    vilvl.b      vr4,   vr2,   vr0
    vilvl.b      vr5,   vr3,   vr1
    VMULW4_H vr4, vr5, vr10, vr10, vr0, vr1, vr2, vr3
.irp x, vr0, vr1, vr2, vr3
    vhaddw.w.h  \x, \x, \x
.endr
    vpickev.h    vr4,   vr1,   vr0
    vpickev.h    vr5,   vr3,   vr2
    vhaddw.w.h   vr4,   vr4,   vr4
    vhaddw.w.h   vr5,   vr5,   vr5
    vpackev.h    vr6,   vr5,   vr4
    add.d        a0,    a0,    a1
    vadd.h       vr7,   vr6,   vr11
    addi.d       t0,    t0,    -1
    vstelm.w     vr7,   a2,    0,   0
    vstelm.w     vr7,   a2,    4,   2
    vstelm.w     vr7,   a2,    8,   1
    add.d        a2,    a2,    a3
    blt          zero,  t0,    .loopS_4tap_6x\h
endfunc
.endm

FILTER_HORIZ_4TAP_PS_6xN 8
FILTER_HORIZ_4TAP_PS_6xN 16

.macro FILTER_HORIZ_4TAP_PS_8xN  h
function x265_interp_4tap_horiz_ps_8x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       a3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t5,    h_psOffset
    vldx         vr10,  t6,    t7
    vld          vr11,  t5,    0
    addi.d       t0,    zero,  \h
    beqz         a5,    .loopS_4tap_8x\h
    sub.d        a0,    a0,    a1
    addi.d       t0,    t0,    3
.loopS_4tap_8x\h:
    fld.d        f0,    a0,    -1
    fld.d        f1,    a0,    0
    fld.d        f2,    a0,    1
    fld.d        f3,    a0,    2
    vilvl.b      vr4,   vr2,   vr0
    vilvl.b      vr5,   vr3,   vr1
    VMULW4_H vr4, vr5, vr10, vr10, vr0, vr1, vr2, vr3
.irp x, vr0, vr1, vr2, vr3
    vhaddw.w.h  \x, \x, \x
.endr
    vpickev.h    vr4,   vr1,   vr0
    vpickev.h    vr5,   vr3,   vr2
    vhaddw.w.h   vr4,   vr4,   vr4
    vhaddw.w.h   vr5,   vr5,   vr5
    vpackev.h    vr6,   vr5,   vr4
    add.d        a0,    a0,    a1
    vadd.h       vr7,   vr6,   vr11
    addi.d       t0,    t0,    -1
    vshuf4i.w    vr8,   vr7,   0xD8
    vst          vr8,   a2,    0
    add.d        a2,    a2,    a3
    blt          zero,  t0,    .loopS_4tap_8x\h
endfunc
.endm

FILTER_HORIZ_4TAP_PS_8xN 2
FILTER_HORIZ_4TAP_PS_8xN 4
FILTER_HORIZ_4TAP_PS_8xN 6
FILTER_HORIZ_4TAP_PS_8xN 8
FILTER_HORIZ_4TAP_PS_8xN 12
FILTER_HORIZ_4TAP_PS_8xN 16
FILTER_HORIZ_4TAP_PS_8xN 32
FILTER_HORIZ_4TAP_PS_8xN 64

.macro FILTER_HORIZ_4TAP_PS_12xN  h
function x265_interp_4tap_horiz_ps_12x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       a3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t5,    h_psOffset
    vldx         vr10,  t6,    t7
    vld          vr11,  t5,    0
    addi.d       t0,    zero,  \h
    beqz         a5,    .loopS_4tap_12x\h
    sub.d        a0,    a0,    a1
    addi.d       t0,    t0,    3
.loopS_4tap_12x\h:
    vld          vr0,   a0,    -1
    vld          vr1,   a0,    0
    vld          vr2,   a0,    1
    vld          vr3,   a0,    2
    vilvh.b      vr6,   vr2,   vr0
    vilvh.b      vr7,   vr3,   vr1
    vilvl.b      vr4,   vr2,   vr0
    vilvl.b      vr5,   vr3,   vr1
    vilvl.d      vr8,   vr7,   vr6  //8,10,9,11
    VMULW4_H vr4, vr5, vr10, vr10, vr0, vr1, vr2, vr3
    vmulwev.h.bu.b vr16, vr8,  vr10
    vmulwod.h.bu.b vr17, vr8,  vr10

.irp x, vr0, vr1, vr2, vr3, vr16, vr17
    vhaddw.w.h  \x, \x, \x
.endr

    vpickev.h    vr4,   vr1,   vr0
    vpickev.h    vr5,   vr3,   vr2
    vpickev.h    vr15,  vr17,  vr16
    vhaddw.w.h   vr4,   vr4,   vr4
    vhaddw.w.h   vr5,   vr5,   vr5
    vhaddw.w.h   vr15,  vr15,  vr15
    vpackev.h    vr6,   vr5,   vr4
    vpickev.h    vr9,   vr16,  vr15
    add.d        a0,    a0,    a1
    vadd.h       vr7,   vr6,   vr11
    vadd.h       vr8,   vr9,   vr11
    vshuf4i.w    vr7,   vr7,   0xD8
    addi.d       t0,    t0,    -1
    vst          vr7,   a2,    0
    fst.d        f8,    a2,    16
    add.d        a2,    a2,    a3
    blt          zero,  t0,    .loopS_4tap_12x\h
endfunc
.endm

FILTER_HORIZ_4TAP_PS_12xN  16
FILTER_HORIZ_4TAP_PS_12xN  32

.macro FILTER_HORIZ_4TAP_PS_24xN  h
function x265_interp_4tap_horiz_ps_24x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       a3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t5,    h_psOffset
    vldx         vr10,  t6,    t7
    vld          vr21,  t5,    0
    addi.d       t0,    zero,  \h
    beqz         a5,    .loopS_4tap_24x\h
    sub.d        a0,    a0,    a1
    addi.d       t0,    t0,    3
.loopS_4tap_24x\h:
    vld          vr0,   a0,    -1
    vld          vr1,   a0,    0
    vld          vr2,   a0,    1
    vld          vr3,   a0,    2
    fld.d        f4,    a0,    15
    fld.d        f5,    a0,    16
    fld.d        f6,    a0,    17
    fld.d        f7,    a0,    18

    vilvl.b      vr8,   vr1,   vr0
    vilvl.b      vr9,   vr3,   vr2
    vilvh.b      vr11,  vr1,   vr0
    vilvh.b      vr12,  vr3,   vr2
    vilvl.b      vr13,  vr5,   vr4
    vilvl.b      vr14,  vr7,   vr6

    VMULW4_H vr8, vr9, vr10, vr10, vr0, vr1, vr2, vr3
    VMULW4_H vr11, vr12, vr10, vr10, vr4, vr5, vr6, vr7
    VMULW4_H vr13, vr14, vr10, vr10, vr8, vr9, vr17, vr18

.irp x, vr0, vr1, vr2, vr3, vr4, vr5, vr6, vr7, vr8, vr9, vr17, vr18
    vhaddw.w.h  \x, \x, \x
.endr

    vpickev.h    vr11,  vr2,   vr0
    vpickev.h    vr12,  vr3,   vr1
    vpickev.h    vr13,  vr6,   vr4
    vpickev.h    vr14,  vr7,   vr5
    vpickev.h    vr15,  vr17,  vr8
    vpickev.h    vr16,  vr18,  vr9

.irp x, vr11, vr12, vr13, vr14, vr15, vr16
    vhaddw.w.h  \x, \x, \x
.endr

    vpackev.h    vr2,   vr12,  vr11
    vpackev.h    vr3,   vr14,  vr13
    vpackev.h    vr4,   vr16,  vr15

    add.d        a0,    a0,    a1
    vadd.h       vr5,   vr2,   vr21
    vadd.h       vr6,   vr3,   vr21
    vadd.h       vr7,   vr4,   vr21
    vshuf4i.w    vr0,   vr5,   0xD8
    vshuf4i.w    vr1,   vr6,   0xD8
    vshuf4i.w    vr2,   vr7,   0xD8
    addi.d       t0,    t0,    -1
    vst          vr0,   a2,    0
    vst          vr1,   a2,    16
    vst          vr2,   a2,    32
    add.d        a2,    a2,    a3
    blt          zero,  t0,    .loopS_4tap_24x\h
endfunc
.endm

FILTER_HORIZ_4TAP_PS_24xN  32
FILTER_HORIZ_4TAP_PS_24xN  64

.macro FILTER_HORIZ_4TAP_PS_WxN  w, h, rep
function x265_interp_4tap_horiz_ps_\w\()x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       a3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t5,    h_psOffset
    addi.d       t0,    zero,  \h
    vldx         vr10,  t6,    t7
    vld          vr21,  t5,    0
    beqz         a5,    .loopS_4tap_\w\()x\h
    sub.d        a0,    a0,    a1
    addi.d       t0,    t0,    3
.loopS_4tap_\w\()x\h:
    move         t1,    a0
    move         t2,    a2
.rept  \rep
    vld          vr0,   t1,    -1
    vld          vr1,   t1,    0
    vld          vr2,   t1,    1
    vld          vr3,   t1,    2

    vilvl.b      vr8,   vr1,   vr0
    vilvl.b      vr9,   vr3,   vr2
    vilvh.b      vr11,  vr1,   vr0
    vilvh.b      vr12,  vr3,   vr2

    VMULW4_H vr8, vr9, vr10, vr10, vr0, vr1, vr2, vr3
    VMULW4_H vr11, vr12, vr10, vr10, vr4, vr5, vr6, vr7

.irp x, vr0, vr1, vr2, vr3, vr4, vr5, vr6, vr7
    vhaddw.w.h  \x, \x, \x
.endr

    vpickev.h      vr11, vr2,  vr0
    vpickev.h      vr12, vr3,  vr1
    vpickev.h      vr13, vr6,  vr4
    vpickev.h      vr14, vr7,  vr5

.irp x, vr11, vr12, vr13, vr14
    vhaddw.w.h  \x, \x, \x
.endr

    vpackev.h      vr2,  vr12, vr11
    vpackev.h      vr3,  vr14, vr13

    vadd.h         vr4,  vr2,  vr21
    vadd.h         vr5,  vr3,  vr21
    addi.d         t1,   t1,   16
    vshuf4i.w      vr6,  vr4,  0xD8
    vshuf4i.w      vr7,  vr5,  0xD8
    vst            vr6,  t2,   0
    vst            vr7,  t2,   16
    addi.d         t2,   t2,   32
.endr
    addi.d         t0,   t0,   -1
    add.d          a0,   a0,   a1
    add.d          a2,   a2,   a3
    blt            zero, t0,   .loopS_4tap_\w\()x\h
endfunc
.endm

FILTER_HORIZ_4TAP_PS_WxN 16, 4,  1
FILTER_HORIZ_4TAP_PS_WxN 16, 8,  1
FILTER_HORIZ_4TAP_PS_WxN 16, 12, 1
FILTER_HORIZ_4TAP_PS_WxN 16, 16, 1
FILTER_HORIZ_4TAP_PS_WxN 16, 24, 1
FILTER_HORIZ_4TAP_PS_WxN 16, 32, 1
FILTER_HORIZ_4TAP_PS_WxN 16, 64, 1

FILTER_HORIZ_4TAP_PS_WxN 32, 8,  2
FILTER_HORIZ_4TAP_PS_WxN 32, 16, 2
FILTER_HORIZ_4TAP_PS_WxN 32, 24, 2
FILTER_HORIZ_4TAP_PS_WxN 32, 32, 2
FILTER_HORIZ_4TAP_PS_WxN 32, 48, 2
FILTER_HORIZ_4TAP_PS_WxN 32, 64, 2

FILTER_HORIZ_4TAP_PS_WxN 48, 64, 3

FILTER_HORIZ_4TAP_PS_WxN 64, 16, 4
FILTER_HORIZ_4TAP_PS_WxN 64, 32, 4
FILTER_HORIZ_4TAP_PS_WxN 64, 48, 4
FILTER_HORIZ_4TAP_PS_WxN 64, 64, 4

.macro FILTER_HORIZ_4TAP_PS_16xN_LASX  h
function x265_interp_4tap_horiz_ps_16x\h\()_lasx
    slli.d       t7,    a4,    5
    slli.d       a3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t5,    h_psOffset
    addi.d       t0,    zero,  \h/2
    xvldx        xr10,  t6,    t7
    xvld         xr23,  t5,    0
    slli.d       t3,    a3,    1
    beqz         a5,    .loopS_4tap_lasx_16x\h
    sub.d        a0,    a0,    a1
    addi.d       t0,    t0,    1
    vld          vr0,   a0,    -1
    vld          vr1,   a0,    0
    vld          vr2,   a0,    1
    vld          vr3,   a0,    2

    vilvl.b      vr8,   vr1,   vr0
    vilvl.b      vr9,   vr3,   vr2
    vilvh.b      vr11,  vr1,   vr0
    vilvh.b      vr12,  vr3,   vr2

    xvpermi.q    xr11,  xr8,   0x20
    xvpermi.q    xr12,  xr9,   0x20
    XMULW4_H xr11, xr12, xr10, xr10, xr8, xr9, xr17, xr18

.irp x, xr8, xr9, xr17, xr18
    xvhaddw.w.h  \x, \x, \x
.endr

    xvpickev.h     xr15, xr17, xr8
    xvpickev.h     xr16, xr18, xr9
    xvhaddw.w.h    xr15, xr15, xr15
    xvhaddw.w.h    xr16, xr16, xr16
    xvpackev.h     xr4,  xr16, xr15
    xvadd.h        xr6,  xr4,  xr23
    xvshuf4i.w     xr8,  xr6,  0xD8
    add.d          a0,   a0,   a1
    xvst           xr8,  a2,   0
    add.d          a2,   a2,   a3
.loopS_4tap_lasx_16x\h:
    add.d        t1,    a0,    a1
    vld          vr0,   a0,    -1
    vld          vr1,   a0,    0
    vld          vr2,   a0,    1
    vld          vr3,   a0,    2
    vld          vr4,   t1,    -1
    vld          vr5,   t1,    0
    vld          vr6,   t1,    1
    vld          vr7,   t1,    2

    vilvl.b      vr8,   vr1,   vr0
    vilvl.b      vr9,   vr3,   vr2
    vilvh.b      vr11,  vr1,   vr0
    vilvh.b      vr12,  vr3,   vr2

    vilvl.b      vr13,  vr5,   vr4
    vilvl.b      vr14,  vr7,   vr6
    vilvh.b      vr15,  vr5,   vr4
    vilvh.b      vr16,  vr7,   vr6

    xvpermi.q    xr11,  xr8,   0x20
    xvpermi.q    xr12,  xr9,   0x20
    xvpermi.q    xr15,  xr13,  0x20
    xvpermi.q    xr16,  xr14,  0x20
    XMULW4_H xr11, xr12, xr10, xr10, xr8, xr9, xr17, xr18
    XMULW4_H xr15, xr16, xr10, xr10, xr19, xr20, xr21, xr22

.irp x, xr8, xr9, xr17, xr18, xr19, xr20, xr21, xr22
    xvhaddw.w.h  \x, \x, \x
.endr

    xvpickev.h     xr15, xr17, xr8
    xvpickev.h     xr16, xr18, xr9
    xvpickev.h     xr0,  xr21, xr19
    xvpickev.h     xr1,  xr22, xr20

.irp x, xr15, xr16, xr0, xr1
    xvhaddw.w.h   \x, \x, \x
.endr

    xvpackev.h     xr4,  xr16, xr15
    xvpackev.h     xr5,  xr1,  xr0

    xvadd.h        xr6,  xr4,  xr23
    xvadd.h        xr7,  xr5,  xr23

    xvshuf4i.w     xr8,  xr6,  0xD8
    xvshuf4i.w     xr9,  xr7,  0xD8
    addi.d         t0,   t0,    -1
    add.d          a0,   t1,    a1
    xvst           xr8,  a2,    0
    xvstx          xr9,  a2,    a3
    add.d          a2,   a2,    t3
    blt            zero, t0,    .loopS_4tap_lasx_16x\h
endfunc
.endm

FILTER_HORIZ_4TAP_PS_16xN_LASX 4
FILTER_HORIZ_4TAP_PS_16xN_LASX 8
FILTER_HORIZ_4TAP_PS_16xN_LASX 12
FILTER_HORIZ_4TAP_PS_16xN_LASX 16
FILTER_HORIZ_4TAP_PS_16xN_LASX 24
FILTER_HORIZ_4TAP_PS_16xN_LASX 32
FILTER_HORIZ_4TAP_PS_16xN_LASX 64

.macro FILTER_HORIZ_4TAP_PS_24xN_LASX h
function x265_interp_4tap_horiz_ps_24x\h\()_lasx
    slli.d       t7,    a4,    5
    slli.d       a3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t5,    h_psOffset
    addi.d       t0,    zero,  \h/2
    xvldx        xr10,  t6,    t7
    xvld         xr23,  t5,    0
    beqz         a5,    .loopS_4tap_lasx_24x\h
    sub.d        a0,    a0,    a1
    addi.d       t0,    t0,    1
    xvld         xr0,   a0,    -1
    xvld         xr1,   a0,    0
    xvld         xr2,   a0,    1
    xvld         xr3,   a0,    2
    xvilvl.b     xr4,   xr1,   xr0
    xvilvl.b     xr5,   xr3,   xr2
    xvilvh.b     xr8,   xr2,   xr0
    xvilvh.b     xr9,   xr3,   xr1
    xvpermi.q    xr9,   xr8,   0x20

    XMULW4_H xr4, xr5, xr10, xr10, xr0, xr1, xr2, xr3
    xvmulwev.h.bu.b xr14, xr9, xr10
    xvmulwod.h.bu.b xr15, xr9, xr10

.irp x, xr0, xr1, xr2, xr3, xr14, xr15
    xvhaddw.w.h  \x, \x, \x
.endr
    xvpickev.h      xr4, xr2,  xr0
    xvpickev.h      xr6, xr15, xr14
    xvpickev.h      xr5, xr3,  xr1

    xvhaddw.w.h     xr4, xr4,  xr4
    xvhaddw.w.h     xr6, xr6,  xr6
    xvhaddw.w.h     xr5, xr5,  xr5

    xvpermi.d       xr7, xr6,  0x4E
    xvpackev.h      xr0, xr5,  xr4
    xvpackev.h      xr1, xr7,  xr6
    xvadd.h         xr0, xr0,  xr23
    xvadd.h         xr1, xr1,  xr23
    xvshuf4i.w      xr2, xr0,  0xD8
    xvshuf4i.w      xr3, xr1,  0xD8
    xvpermi.d       xr4, xr2,  0x4E
    xvpermi.q       xr3, xr2,  0x20
    add.d           a0,  a0,   a1
    xvst            xr3, a2,   0
    vst             vr4, a2,   32
    add.d           a2,  a2,   a3
.loopS_4tap_lasx_24x\h:
    add.d        t1,    a0,    a1
    xvld         xr0,   a0,    -1
    xvld         xr1,   a0,    0
    xvld         xr2,   a0,    1
    xvld         xr3,   a0,    2
    xvld         xr18,  t1,    -1
    xvld         xr19,  t1,    0
    xvld         xr20,  t1,    1
    xvld         xr21,  t1,    2

    xvilvl.b     xr4,   xr1,   xr0
    xvilvl.b     xr5,   xr3,   xr2
    xvilvl.b     xr6,   xr19,  xr18
    xvilvl.b     xr7,   xr21,  xr20
    xvilvh.b     xr8,   xr1,   xr0
    xvilvh.b     xr9,   xr3,   xr2
    xvilvh.b     xr12,  xr19,  xr18
    xvilvh.b     xr13,  xr21,  xr20

    xvpermi.q    xr12,  xr8,   0x20
    xvpermi.q    xr13,  xr9,   0x20

    XMULW4_H xr4, xr5, xr10, xr10, xr0, xr1, xr2, xr3
    XMULW4_H xr6, xr7, xr10, xr10, xr14, xr15, xr16, xr17
    XMULW4_H xr12, xr13, xr10, xr10, xr18, xr19, xr20, xr21

.irp x, xr0, xr1, xr2, xr3, xr14, xr15, xr16, xr17, xr18, xr19, xr20, xr21
    xvhaddw.w.h  \x, \x, \x
.endr

    xvpickev.h      xr4, xr2,  xr0
    xvpickev.h      xr5, xr3,  xr1
    xvpickev.h      xr6, xr16, xr14
    xvpickev.h      xr7, xr17, xr15
    xvpickev.h      xr8, xr20, xr18
    xvpickev.h      xr9, xr21, xr19

.irp x, xr4, xr5, xr6, xr7, xr8, xr9
    xvhaddw.w.h  \x, \x, \x
.endr

    xvpackev.h     xr0,  xr5,  xr4
    xvpackev.h     xr1,  xr7,  xr6
    xvpackev.h     xr2,  xr9,  xr8

    xvadd.h        xr0,  xr0,  xr23
    xvadd.h        xr1,  xr1,  xr23
    xvadd.h        xr2,  xr2,  xr23
    xvshuf4i.w     xr4,  xr0,  0xD8
    xvshuf4i.w     xr5,  xr1,  0xD8
    xvshuf4i.w     xr6,  xr2,  0xD8
    xvpermi.d      xr7,  xr4,  0x4E
    xvpermi.d      xr8,  xr5,  0x4E

    xvpermi.q      xr4,  xr6,  0x02
    xvpermi.q      xr5,  xr6,  0x12
    xvst           xr4,  a2,   0
    vst            vr7,  a2,   32
    add.d          a2,   a2,   a3
    add.d          a0,   t1,   a1
    addi.d         t0,   t0,   -1
    xvst           xr5,  a2,   0
    vst            vr8,  a2,   32
    add.d          a2,   a2,   a3
    blt            zero, t0,   .loopS_4tap_lasx_24x\h
endfunc
.endm

FILTER_HORIZ_4TAP_PS_24xN_LASX  32
FILTER_HORIZ_4TAP_PS_24xN_LASX  64

function x265_interp_4tap_horiz_ps_48x64_lasx
    slli.d       t7,    a4,    5
    slli.d       a3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t5,    h_psOffset
    addi.d       t0,    zero,  64
    xvldx        xr10,  t6,    t7
    xvld         xr23,  t5,    0
    beqz         a5,    .loopS_4tap_lasx_48x64
    sub.d        a0,    a0,    a1
    addi.d       t0,    t0,    3
.loopS_4tap_lasx_48x64:
    xvld         xr0,   a0,    -1
    xvld         xr1,   a0,    0
    xvld         xr2,   a0,    1
    xvld         xr3,   a0,    2
    vld          vr18,  a0,    31
    vld          vr19,  a0,    32
    vld          vr20,  a0,    33
    vld          vr21,  a0,    34

    xvilvl.b     xr4,   xr1,   xr0
    xvilvl.b     xr5,   xr3,   xr2
    vilvl.b      vr6,   vr19,  vr18
    vilvl.b      vr7,   vr21,  vr20
    xvilvh.b     xr8,   xr1,   xr0
    xvilvh.b     xr9,   xr3,   xr2
    vilvh.b      vr12,  vr19,  vr18
    vilvh.b      vr13,  vr21,  vr20

    xvpermi.q    xr12,  xr6,   0x20
    xvpermi.q    xr13,  xr7,   0x20
    XMULW4_H xr4, xr5, xr10, xr10, xr0, xr1, xr2, xr3
    XMULW4_H xr8, xr9, xr10, xr10, xr14, xr15, xr16, xr17
    XMULW4_H xr12, xr13, xr10, xr10, xr18, xr19, xr20, xr21

.irp x, xr0, xr1, xr2, xr3, xr14, xr15, xr16, xr17, xr18, xr19, xr20, xr21
    xvhaddw.w.h  \x, \x, \x
.endr

    xvpickev.h   xr4,  xr2,  xr0
    xvpickev.h   xr5,  xr3,  xr1
    xvpickev.h   xr6,  xr16, xr14
    xvpickev.h   xr7,  xr17, xr15
    xvpickev.h   xr8,  xr20, xr18
    xvpickev.h   xr9,  xr21, xr19

.irp x, xr4, xr5, xr6, xr7, xr8, xr9
    xvhaddw.w.h  \x, \x, \x
.endr

    xvpackev.h     xr0,  xr5,  xr4
    xvpackev.h     xr2,  xr9,  xr8
    xvpackev.h     xr1,  xr7,  xr6

    xvadd.h        xr0,  xr0,  xr23
    xvadd.h        xr2,  xr2,  xr23
    xvadd.h        xr1,  xr1,  xr23
    xvshuf4i.w     xr3,  xr0,  0xD8
    xvshuf4i.w     xr4,  xr1,  0xD8
    xvshuf4i.w     xr5,  xr2,  0xD8
    xvor.v         xr6,  xr3,  xr3
    xvpermi.q      xr3,  xr4,  0x2
    xvpermi.q      xr6,  xr4,  0x13

    xvst           xr3,  a2,   0
    xvst           xr6,  a2,   32
    xvst           xr5,  a2,   64
    addi.d         t0,   t0,   -1
    add.d          a0,   a0,   a1
    add.d          a2,   a2,   a3
    blt            zero, t0,   .loopS_4tap_lasx_48x64
endfunc

.macro FILTER_HORIZ_4TAP_PS_WxN_LASX  w, h, rep
function x265_interp_4tap_horiz_ps_\w\()x\h\()_lasx
    slli.d       t7,    a4,    5
    slli.d       a3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t5,    h_psOffset
    addi.d       t0,    zero,  \h
    xvldx        xr10,  t6,    t7
    xvld         xr23,  t5,    0
    beqz         a5,    .loopS_4tap_lasx_\w\()x\h
    sub.d        a0,    a0,    a1
    addi.d       t0,    t0,    3
.loopS_4tap_lasx_\w\()x\h:
    move         t1,    a0
    move         t2,    a2
.rept  \rep
    add.d        t5,    t1,    a1
    xvld         xr0,   t1,    -1
    xvld         xr1,   t1,    0
    xvld         xr2,   t1,    1
    xvld         xr3,   t1,    2

    xvilvl.b     xr4,   xr1,   xr0
    xvilvl.b     xr5,   xr3,   xr2
    xvilvh.b     xr8,   xr1,   xr0
    xvilvh.b     xr9,   xr3,   xr2

    XMULW4_H xr4, xr5, xr10, xr10, xr0, xr1, xr2, xr3
    XMULW4_H xr8, xr9, xr10, xr10, xr4, xr5, xr6, xr7

.irp x, xr0, xr1, xr2, xr3, xr4, xr5, xr6, xr7
    xvhaddw.w.h  \x, \x, \x
.endr
    xvpickev.h   xr14,  xr2,  xr0
    xvpickev.h   xr15,  xr3,  xr1
    xvpickev.h   xr16,  xr6,  xr4
    xvpickev.h   xr17,  xr7,  xr5

.irp x, xr14, xr15, xr16, xr17
    xvhaddw.w.h  \x, \x, \x
.endr

    xvpackev.h     xr0,  xr15, xr14
    xvpackev.h     xr1,  xr17, xr16
    xvadd.h        xr2,  xr0,  xr23
    xvadd.h        xr3,  xr1,  xr23
    xvshuf4i.w     xr4,  xr2,  0xD8
    xvshuf4i.w     xr5,  xr3,  0xD8
    xvor.v         xr6,  xr4,  xr4
    xvpermi.q      xr4,  xr5,  0x2
    xvpermi.q      xr6,  xr5,  0x13
    addi.d         t1,   t1,   32
    xvst           xr4,  t2,   0
    xvst           xr6,  t2,   32
    addi.d         t2,   t2,   64
.endr
    addi.d         t0,   t0,   -1
    add.d          a0,   a0,   a1
    add.d          a2,   a2,   a3
    blt            zero, t0,   .loopS_4tap_lasx_\w\()x\h
endfunc
.endm

FILTER_HORIZ_4TAP_PS_WxN_LASX 32, 8,  1
FILTER_HORIZ_4TAP_PS_WxN_LASX 32, 16, 1
FILTER_HORIZ_4TAP_PS_WxN_LASX 32, 24, 1
FILTER_HORIZ_4TAP_PS_WxN_LASX 32, 32, 1
FILTER_HORIZ_4TAP_PS_WxN_LASX 32, 48, 1
FILTER_HORIZ_4TAP_PS_WxN_LASX 32, 64, 1

FILTER_HORIZ_4TAP_PS_WxN_LASX 64, 16, 2
FILTER_HORIZ_4TAP_PS_WxN_LASX 64, 32, 2
FILTER_HORIZ_4TAP_PS_WxN_LASX 64, 48, 2
FILTER_HORIZ_4TAP_PS_WxN_LASX 64, 64, 2

function x265_interp_4tap_vert_pp_2x4_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_chromaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    sub.d        a0,    a0,    a1
    vldx         vr16,  t6,    t7

    add.d        t6,    a0,    t3
    fld.s        f0,    a0,    0    //0
    fldx.s       f1,    a0,    a1   //1
    fldx.s       f2,    a0,    t1   //2
    fldx.s       f3,    a0,    t2   //3
    fld.s        f4,    t6,    0    //4
    fldx.s       f5,    t6,    a1   //5
    fldx.s       f6,    t6,    t1   //6

    vilvl.h      vr8,   vr1,   vr0  //0, 1
    vilvl.h      vr9,   vr3,   vr2  //2, 3
    vilvl.h      vr10,  vr2,   vr1  //1, 2
    vilvl.h      vr11,  vr4,   vr3  //3, 4
    vilvl.h      vr12,  vr5,   vr4  //4, 5
    vilvl.h      vr14,  vr6,   vr5  //5, 6

    vilvl.w      vr0,   vr9,   vr8  //0,1,2,3
    vilvl.w      vr1,   vr11,  vr10 //1,2,3,4
    vilvl.w      vr2,   vr12,  vr9  //2,3,4,5
    vilvl.w      vr3,   vr14,  vr11 //3,4,5,6

    vilvl.d      vr4,   vr1,   vr0  //0,1,2,3,1,2,3,4
    vilvl.d      vr5,   vr3,   vr2  //2,3,4,5,3,4,5,6

    VMULW4_H  vr4, vr5, vr16, vr16, vr6, vr7, vr8, vr9
    vhaddw.w.h   vr0,   vr6,   vr6
    vhaddw.w.h   vr1,   vr7,   vr7
    vhaddw.w.h   vr2,   vr8,   vr8
    vhaddw.w.h   vr3,   vr9,   vr9

    vpickev.h    vr4,   vr2,   vr0
    vpickev.h    vr5,   vr3,   vr1
    vhaddw.w.h   vr6,   vr4,   vr4
    vhaddw.w.h   vr7,   vr5,   vr5
    vpackev.h    vr8,   vr7,   vr6

    vssrarni.bu.h    vr10, vr8,  6

    vstelm.h         vr10, a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.h         vr10, a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.h         vr10, a2,   0,   2
    add.d            a2,   a2,   a3
    vstelm.h         vr10, a2,   0,   3
endfunc

.macro VERT_4TAP_PP_2xH  h
function x265_interp_4tap_vert_pp_2x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_chromaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    sub.d        a0,    a0,    a1
    addi.d       t0,    zero,  \h/8
    vldx         vr16,  t6,    t7

.loopV_4tap_2x\h:
    add.d        t6,    a0,    t3
    fld.s        f0,    a0,    0    //0
    fldx.s       f1,    a0,    a1   //1
    fldx.s       f2,    a0,    t1   //2
    fldx.s       f3,    a0,    t2   //3

    fld.s        f4,    t6,    0    //4
    fldx.s       f5,    t6,    a1   //5
    fldx.s       f6,    t6,    t1   //6
    fldx.s       f7,    t6,    t2   //7
    add.d        a0,    t6,    t3

    vilvl.h      vr8,   vr1,   vr0  //0, 1
    vilvl.h      vr9,   vr3,   vr2  //2, 3
    vilvl.h      vr10,  vr2,   vr1  //1, 2
    vilvl.h      vr11,  vr4,   vr3  //3, 4
    vilvl.h      vr12,  vr5,   vr4  //4, 5
    vilvl.h      vr13,  vr7,   vr6  //6, 7
    vilvl.h      vr14,  vr6,   vr5  //5, 6

    vilvl.w      vr0,   vr9,   vr8  //0,1,2,3
    vilvl.w      vr1,   vr11,  vr10 //1,2,3,4
    vilvl.w      vr2,   vr12,  vr9  //2,3,4,5
    vilvl.w      vr3,   vr14,  vr11 //3,4,5,6
    vilvl.w      vr4,   vr13,  vr12 //4,5,6,7

    fld.s        f8,    a0,    0    //8
    fldx.s       f9,    a0,    a1   //9
    fldx.s       f10,   a0,    t1   //10

    vilvl.h      vr15,  vr8,   vr7  //7, 8
    vilvl.h      vr11,  vr9,   vr8  //8, 9
    vilvl.h      vr12,  vr10,  vr9  //9, 10

    vilvl.w      vr5,   vr15,  vr14 //5,6,7,8
    vilvl.w      vr6,   vr11,  vr13 //6,7,8,9
    vilvl.w      vr7,   vr12,  vr15 //7,8,9,10

    vilvl.d      vr8,   vr1,   vr0
    vilvl.d      vr9,   vr3,   vr2
    vilvl.d      vr10,  vr5,   vr4
    vilvl.d      vr11,  vr7,   vr6

    VMULW4_H  vr8, vr9, vr16, vr16, vr0, vr1, vr2, vr3
    VMULW4_H  vr10, vr11, vr16, vr16, vr4, vr5, vr6, vr7

.irp x, vr0, vr1, vr2, vr3, vr4, vr5, vr6, vr7
    vhaddw.w.h  \x, \x, \x
.endr

    vpickev.h    vr8,   vr2,   vr0
    vpickev.h    vr9,   vr3,   vr1
    vpickev.h    vr10,  vr6,   vr4
    vpickev.h    vr11,  vr7,   vr5
.irp x, vr8, vr9, vr10, vr11
    vhaddw.w.h  \x, \x, \x
.endr
    vpackev.h    vr0,   vr9,   vr8
    vpackev.h    vr1,   vr11,  vr10
    vssrarni.bu.h    vr1,  vr0,  6
    addi.d           t0,   t0,   -1
    vstelm.h         vr1,  a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.h         vr1,  a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.h         vr1,  a2,   0,   2
    add.d            a2,   a2,   a3
    vstelm.h         vr1,  a2,   0,   3
    add.d            a2,   a2,   a3
    vstelm.h         vr1,  a2,   0,   4
    add.d            a2,   a2,   a3
    vstelm.h         vr1,  a2,   0,   5
    add.d            a2,   a2,   a3
    vstelm.h         vr1,  a2,   0,   6
    add.d            a2,   a2,   a3
    vstelm.h         vr1,  a2,   0,   7
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_4tap_2x\h
endfunc
.endm

VERT_4TAP_PP_2xH  8
VERT_4TAP_PP_2xH  16

function x265_interp_4tap_vert_pp_4x2_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_chromaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    sub.d        a0,    a0,    a1
    vldx         vr16,  t6,    t7

    fld.s        f0,    a0,    0    //0
    fldx.s       f1,    a0,    a1   //1
    fldx.s       f2,    a0,    t1   //2
    fldx.s       f3,    a0,    t2   //3
    fldx.s       f4,    a0,    t3   //4

    vilvl.h      vr8,   vr1,   vr0  //0, 1
    vilvl.h      vr9,   vr3,   vr2  //2, 3
    vilvl.h      vr10,  vr2,   vr1  //1, 2
    vilvl.h      vr11,  vr4,   vr3  //3, 4

    vilvl.w      vr0,   vr9,   vr8  //0,1,2,3
    vilvl.w      vr1,   vr11,  vr10 //1,2,3,4

    VMULW4_H vr0, vr1, vr16, vr16, vr9, vr10, vr11, vr12

    vhaddw.w.h   vr0,   vr9,   vr9
    vhaddw.w.h   vr1,   vr10,  vr10
    vhaddw.w.h   vr2,   vr11,  vr11
    vhaddw.w.h   vr3,   vr12,  vr12

    vpickev.h    vr4,   vr1,   vr0
    vpickev.h    vr5,   vr3,   vr2
    vhaddw.w.h   vr6,   vr4,   vr4
    vhaddw.w.h   vr7,   vr5,   vr5
    vpickev.h    vr8,   vr7,   vr6

    vssrarni.bu.h    vr9,  vr8,  6
    vshuf4i.b        vr10, vr9,  0xD8
    vstelm.w         vr10, a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.w         vr10, a2,   0,   1
endfunc

function x265_interp_4tap_vert_pp_4x4_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_chromaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    sub.d        a0,    a0,    a1
    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6

    add.d        t6,    a0,    t3
    fld.s        f0,    a0,    0    //0
    fldx.s       f1,    a0,    a1   //1
    fldx.s       f2,    a0,    t1   //2
    fldx.s       f3,    a0,    t2   //3
    fld.s        f4,    t6,    0    //4
    fldx.s       f5,    t6,    a1   //5
    fldx.s       f6,    t6,    t1   //6

    vilvl.b      vr8,   vr1,   vr0  //0, 1
    vilvl.b      vr9,   vr3,   vr2  //2, 3
    vilvl.b      vr10,  vr2,   vr1  //1, 2
    vilvl.b      vr11,  vr4,   vr3  //3, 4
    vilvl.b      vr12,  vr5,   vr4  //4, 5
    vilvl.b      vr14,  vr6,   vr5  //5, 6

    vilvl.d      vr0,   vr9,   vr8  //0,1,2,3
    vilvl.d      vr1,   vr11,  vr10 //1,2,3,4
    vilvl.d      vr2,   vr12,  vr9  //2,3,4,5
    vilvl.d      vr3,   vr14,  vr11 //3,4,5,6

    vmulwev.h.bu.b   vr9,  vr0,  vr16   //0, 2
    vmulwod.h.bu.b   vr10, vr0,  vr16   //1, 3

    VMADDW4_H vr1, vr2, vr17, vr18, vr9, vr10, vr9, vr10
    vmaddwev.h.bu.b  vr9,  vr3,  vr19
    vmaddwod.h.bu.b  vr10, vr3,  vr19
    vssrarni.bu.h    vr10, vr9,  6
    vstelm.w         vr10, a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.w         vr10, a2,   0,   2
    add.d            a2,   a2,   a3
    vstelm.w         vr10, a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.w         vr10, a2,   0,   3
endfunc

.macro VERT_4TAP_PP_4xH  h
function x265_interp_4tap_vert_pp_4x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_chromaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    sub.d        a0,    a0,    a1
    addi.d       t0,    zero,  \h/8
    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6

.loopV_4tap_4x\h:
    add.d        t6,    a0,    t3
    fld.s        f0,    a0,    0    //0
    fldx.s       f1,    a0,    a1   //1
    fldx.s       f2,    a0,    t1   //2
    fldx.s       f3,    a0,    t2   //3

    fld.s        f4,    t6,    0    //4
    fldx.s       f5,    t6,    a1   //5
    fldx.s       f6,    t6,    t1   //6
    fldx.s       f7,    t6,    t2   //7
    add.d        a0,    t6,    t3

    vilvl.b      vr8,   vr1,   vr0  //0, 1
    vilvl.b      vr9,   vr3,   vr2  //2, 3
    vilvl.b      vr10,  vr2,   vr1  //1, 2
    vilvl.b      vr11,  vr4,   vr3  //3, 4
    vilvl.b      vr12,  vr5,   vr4  //4, 5
    vilvl.b      vr13,  vr7,   vr6  //6, 7
    vilvl.b      vr14,  vr6,   vr5  //5, 6

    vilvl.d      vr0,   vr9,   vr8  //0,1,2,3
    vilvl.d      vr1,   vr11,  vr10 //1,2,3,4
    vilvl.d      vr2,   vr12,  vr9  //2,3,4,5
    vilvl.d      vr3,   vr14,  vr11 //3,4,5,6
    vilvl.d      vr4,   vr13,  vr12 //4,5,6,7

    fld.s        f8,    a0,    0    //8
    fldx.s       f9,    a0,    a1   //9
    fldx.s       f10,   a0,    t1   //10

    vilvl.b      vr15,  vr8,   vr7  //7, 8
    vilvl.b      vr11,  vr9,   vr8  //8, 9
    vilvl.b      vr12,  vr10,  vr9  //9, 10

    vilvl.d      vr5,   vr15,  vr14 //5,6,7,8
    vilvl.d      vr6,   vr11,  vr13 //6,7,8,9
    vilvl.d      vr7,   vr12,  vr15 //7,8,9,10

    VMULW4_H  vr0, vr4, vr16, vr16, vr9, vr10, vr11, vr12
    VMADDW4_H vr1, vr5, vr17, vr17, vr9, vr10, vr11, vr12
    VMADDW4_H vr2, vr6, vr18, vr18, vr9, vr10, vr11, vr12
    VMADDW4_H vr3, vr7, vr19, vr19, vr9, vr10, vr11, vr12

    vssrarni.bu.h    vr10, vr9,  6
    vssrarni.bu.h    vr12, vr11, 6
    addi.d           t0,   t0,   -1
    vstelm.w         vr10, a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.w         vr10, a2,   0,   2
    add.d            a2,   a2,   a3
    vstelm.w         vr10, a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.w         vr10, a2,   0,   3
    add.d            a2,   a2,   a3
    vstelm.w         vr12, a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.w         vr12, a2,   0,   2
    add.d            a2,   a2,   a3
    vstelm.w         vr12, a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.w         vr12, a2,   0,   3
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_4tap_4x\h
endfunc
.endm

VERT_4TAP_PP_4xH  8
VERT_4TAP_PP_4xH  16
VERT_4TAP_PP_4xH  32

.macro VERT_4TAP_PP_6xN  h
function x265_interp_4tap_vert_pp_6x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_chromaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    sub.d        t6,    a0,    a1
    addi.d       t0,    zero,  \h/4
    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6

    add.d        a0,    t6,    t2
    fld.d        f8,    t6,    0    //0
    fldx.d       f9,    t6,    a1   //1
    fldx.d       f10,   t6,    t1   //2

    vilvl.b      vr0,   vr9,   vr8  //0,1
    vilvl.b      vr1,   vr10,  vr9  //1,2
.loopV_4tap_6x\h:
    fld.d        f11,   a0,    0    //3
    fldx.d       f12,   a0,    a1   //4
    fldx.d       f13,   a0,    t1   //5
    fldx.d       f14,   a0,    t2   //6
    add.d        a0,    a0,    t3
    vilvl.b      vr2,   vr11,  vr10 //2,3
    vilvl.b      vr3,   vr12,  vr11 //3,4
    vilvl.b      vr4,   vr13,  vr12 //4,5
    vilvl.b      vr5,   vr14,  vr13 //5,6

    VMULW4_H  vr0, vr2, vr16, vr16, vr20, vr21, vr22, vr23
    VMADDW4_H vr1, vr3, vr17, vr17, vr20, vr21, vr22, vr23
    VMADDW4_H vr2, vr4, vr18, vr18, vr20, vr21, vr22, vr23
    VMADDW4_H vr3, vr5, vr19, vr19, vr20, vr21, vr22, vr23
    vor.v            vr0,  vr4,  vr4
    vor.v            vr1,  vr5,  vr5
    vor.v            vr10, vr14, vr14

    vssrarni.bu.h    vr21, vr20, 6
    vssrarni.bu.h    vr23, vr22, 6
    addi.d           t0,   t0,   -1
    vstelm.w         vr21, a2,   0,   0
    vstelm.h         vr21, a2,   4,   2
    add.d            a2,   a2,   a3
    vstelm.w         vr21, a2,   0,   2
    vstelm.h         vr21, a2,   4,   6
    add.d            a2,   a2,   a3
    vstelm.w         vr23, a2,   0,   0
    vstelm.h         vr23, a2,   4,   2
    add.d            a2,   a2,   a3
    vstelm.w         vr23, a2,   0,   2
    vstelm.h         vr23, a2,   4,   6
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_4tap_6x\h
endfunc
.endm

VERT_4TAP_PP_6xN 8
VERT_4TAP_PP_6xN 16

.macro VERT_4TAP_PP_8x2N  h
function x265_interp_4tap_vert_pp_8x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    la.local     t6,    g_chromaFilter
    add.d        t5,    t6,    t7
    add.d        t2,    t1,    a1
    sub.d        t6,    a0,    a1
    addi.d       t0,    zero,  \h/2
    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6

    add.d        a0,    t6,    t2
    fld.d        f8,    t6,    0    //0
    fldx.d       f9,    t6,    a1   //1
    fldx.d       f10,   t6,    t1

    vilvl.b      vr0,   vr9,   vr8  //0,1
    vilvl.b      vr1,   vr10,  vr9  //1,2
.loopV_4tap_8x\h:
    fld.d        f11,   a0,    0    //3
    fldx.d       f12,   a0,    a1   //4
    add.d        a0,    a0,    t1
    vilvl.b      vr2,   vr11,  vr10 //2,3
    vilvl.b      vr3,   vr12,  vr11 //3,4

    vmulwev.h.bu.b   vr20, vr0,  vr16
    vmulwod.h.bu.b   vr21, vr0,  vr16
    VMADDW4_H vr1, vr2, vr17, vr18, vr20, vr21, vr20, vr21
    vmaddwev.h.bu.b  vr20, vr3,  vr19
    vmaddwod.h.bu.b  vr21, vr3,  vr19

    vor.v            vr0,  vr2,  vr2
    vor.v            vr1,  vr3,  vr3
    vor.v            vr10, vr12, vr12
    vssrarni.bu.h    vr21, vr20, 6
    addi.d           t0,   t0,   -1
    vstelm.d         vr21, a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.d         vr21, a2,   0,   1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_4tap_8x\h
endfunc
.endm

VERT_4TAP_PP_8x2N 2
VERT_4TAP_PP_8x2N 6

.macro VERT_4TAP_PP_8xN  h
function x265_interp_4tap_vert_pp_8x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_chromaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    sub.d        t6,    a0,    a1
    addi.d       t0,    zero,  \h/4
    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6

    add.d        a0,    t6,    t2
    fld.d        f8,    t6,    0    //0
    fldx.d       f9,    t6,    a1   //1
    fldx.d       f10,   t6,    t1   //2

    vilvl.b      vr0,   vr9,   vr8  //0,1
    vilvl.b      vr1,   vr10,  vr9  //1,2
.loopV_4tap_8x\h:
    fld.d        f11,   a0,    0    //3
    fldx.d       f12,   a0,    a1   //4
    fldx.d       f13,   a0,    t1   //5
    fldx.d       f14,   a0,    t2   //6
    add.d        a0,    a0,    t3
    vilvl.b      vr2,   vr11,  vr10 //2,3
    vilvl.b      vr3,   vr12,  vr11 //3,4
    vilvl.b      vr4,   vr13,  vr12 //4,5
    vilvl.b      vr5,   vr14,  vr13 //5,6

    VMULW4_H  vr0, vr2, vr16, vr16, vr20, vr21, vr22, vr23
    VMADDW4_H vr1, vr3, vr17, vr17, vr20, vr21, vr22, vr23
    VMADDW4_H vr2, vr4, vr18, vr18, vr20, vr21, vr22, vr23
    VMADDW4_H vr3, vr5, vr19, vr19, vr20, vr21, vr22, vr23
    vor.v            vr0,  vr4,  vr4
    vor.v            vr1,  vr5,  vr5
    vor.v            vr10, vr14, vr14

    vssrarni.bu.h    vr21, vr20, 6
    vssrarni.bu.h    vr23, vr22, 6
    addi.d           t0,   t0,   -1
    vstelm.d         vr21, a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.d         vr21, a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.d         vr23, a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.d         vr23, a2,   0,   1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_4tap_8x\h
endfunc
.endm

VERT_4TAP_PP_8xN 4
VERT_4TAP_PP_8xN 8
VERT_4TAP_PP_8xN 12
VERT_4TAP_PP_8xN 16
VERT_4TAP_PP_8xN 32
VERT_4TAP_PP_8xN 64

.macro VERT_4TAP_PP_12xN  h
function x265_interp_4tap_vert_pp_12x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    la.local     t6,    g_chromaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/2
    sub.d        t6,    a0,    a1
    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6

    add.d        a0,    t6,    t2
    vld          vr0,   t6,    0    //0
    vldx         vr1,   t6,    a1   //1
    vldx         vr2,   t6,    t1   //2

.loopV_4tap_12x\h:
    vld          vr3,   a0,    0   //3
    vldx         vr4,   a0,    a1  //4
    VMULW4_H  vr0, vr1, vr16, vr16, vr10, vr11, vr12, vr13
    VMADDW4_H vr1, vr2, vr17, vr17, vr10, vr11, vr12, vr13
    VMADDW4_H vr2, vr3, vr18, vr18, vr10, vr11, vr12, vr13
    VMADDW4_H vr3, vr4, vr19, vr19, vr10, vr11, vr12, vr13
    vor.v            vr0,  vr2,  vr2
    vor.v            vr1,  vr3,  vr3
    vor.v            vr2,  vr4,  vr4

    vssrarni.bu.h    vr12, vr10, 6
    vssrarni.bu.h    vr13, vr11, 6
    addi.d           t0,   t0,   -1
    vilvl.b          vr14, vr13, vr12
    vilvh.b          vr15, vr13, vr12
    vstelm.d         vr14, a2,   0,   0
    vstelm.w         vr14, a2,   8,   2
    add.d            a2,   a2,   a3
    vstelm.d         vr15, a2,   0,   0
    vstelm.w         vr15, a2,   8,   2
    add.d            a0,   a0,   t1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_4tap_12x\h
endfunc
.endm

VERT_4TAP_PP_12xN  16
VERT_4TAP_PP_12xN  32

.macro VERT_4TAP_PP_16xN  h
function x265_interp_4tap_vert_pp_16x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    la.local     t6,    g_chromaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  \h/2
    sub.d        t6,    a0,    a1
    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6

    add.d        a0,    t6,    t2
    slli.d       t7,    a3,    1
    vld          vr0,   t6,    0    //0
    vldx         vr1,   t6,    a1   //1
    vldx         vr2,   t6,    t1   //2

.loopV_4tap_16x\h:
    vld          vr3,   a0,    0   //3
    vldx         vr4,   a0,    a1  //4
    VMULW4_H  vr0, vr1, vr16, vr16, vr10, vr11, vr12, vr13
    VMADDW4_H vr1, vr2, vr17, vr17, vr10, vr11, vr12, vr13
    VMADDW4_H vr2, vr3, vr18, vr18, vr10, vr11, vr12, vr13
    VMADDW4_H vr3, vr4, vr19, vr19, vr10, vr11, vr12, vr13
    vor.v            vr0,  vr2,  vr2
    vor.v            vr1,  vr3,  vr3
    vor.v            vr2,  vr4,  vr4

    vssrarni.bu.h    vr12, vr10, 6
    vssrarni.bu.h    vr13, vr11, 6
    vilvl.b          vr14, vr13, vr12
    vilvh.b          vr15, vr13, vr12
    vst              vr14, a2,   0
    vstx             vr15, a2,   a3
    add.d            a0,   a0,   t1
    addi.d           t0,   t0,   -1
    add.d            a2,   a2,   t7
    blt              zero, t0,   .loopV_4tap_16x\h
endfunc
.endm

VERT_4TAP_PP_16xN 4
VERT_4TAP_PP_16xN 8
VERT_4TAP_PP_16xN 12
VERT_4TAP_PP_16xN 16
VERT_4TAP_PP_16xN 24
VERT_4TAP_PP_16xN 32
VERT_4TAP_PP_16xN 64

.macro VERT_4TAP_PP_24xN h
function x265_interp_4tap_vert_pp_24x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    la.local     t6,    g_chromaFilter
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/2
    add.d        t2,    t1,    a1
    sub.d        a0,    a0,    a1

    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6

    addi.d       t6,    a0,    16
    vld          vr0,   a0,    0    //0
    vldx         vr1,   a0,    a1   //1
    vldx         vr2,   a0,    t1   //2

    add.d        a0,    a0,    t2
    fld.d        f5,    t6,    0
    fldx.d       f6,    t6,    a1
    fldx.d       f7,    t6,    t1
    vilvl.b      vr10,  vr6,   vr5  //0,1
    vilvl.b      vr11,  vr7,   vr6  //1,2

.loopV_4tap_24x\h:
    addi.d       t6,    a0,    16
    vld          vr3,   a0,    0   //3
    vldx         vr4,   a0,    a1  //4
    fld.d        f8,    t6,    0
    fldx.d       f9,    t6,    a1

    vilvl.b      vr12,  vr8,   vr7  //2,3
    vilvl.b      vr13,  vr9,   vr8  //3,4

    VMULW4_H  vr0, vr1, vr16, vr16, vr20, vr21, vr22, vr23
    vmulwev.h.bu.b vr14,  vr10, vr16
    vmulwod.h.bu.b vr15,  vr10, vr16
    VMADDW4_H vr1, vr2, vr17, vr17, vr20, vr21, vr22, vr23
    vmaddwev.h.bu.b vr14, vr11, vr17
    vmaddwod.h.bu.b vr15, vr11, vr17
    VMADDW4_H vr2, vr3, vr18, vr18, vr20, vr21, vr22, vr23
    vmaddwev.h.bu.b vr14, vr12, vr18
    vmaddwod.h.bu.b vr15, vr12, vr18
    VMADDW4_H vr3, vr4, vr19, vr19, vr20, vr21, vr22, vr23
    vmaddwev.h.bu.b vr14, vr13, vr19
    vmaddwod.h.bu.b vr15, vr13, vr19

    vssrarni.bu.h    vr22, vr20, 6
    vssrarni.bu.h    vr23, vr21, 6
    vssrarni.bu.h    vr15, vr14, 6
    vor.v            vr10, vr12, vr12
    vor.v            vr11, vr13, vr13
    vor.v            vr0,  vr2,  vr2
    vor.v            vr1,  vr3,  vr3
    vor.v            vr2,  vr4,  vr4
    vor.v            vr7,  vr9,  vr9

    vilvl.b          vr20, vr23, vr22
    vilvh.b          vr21, vr23, vr22

    vst              vr20, a2,   0
    vstelm.d         vr15, a2,   16,   0
    add.d            a2,   a2,   a3
    add.d            a0,   a0,   t1
    vst              vr21, a2,   0
    vstelm.d         vr15, a2,   16,   1
    addi.d           t0,   t0,   -1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_4tap_24x\h
endfunc
.endm

VERT_4TAP_PP_24xN 32
VERT_4TAP_PP_24xN 64

.macro VERT_4TAP_PP_32xN  h
function x265_interp_4tap_vert_pp_32x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    la.local     t6,    g_chromaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/2
    sub.d        a0,    a0,    a1

    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6

    addi.d       t6,    a0,    16
    vld          vr0,   a0,    0    //0
    vldx         vr1,   a0,    a1   //1
    vldx         vr2,   a0,    t1   //2

    add.d        a0,    a0,    t2
    vld          vr5,   t6,    0
    vldx         vr6,   t6,    a1
    vldx         vr7,   t6,    t1

.loopV_4tap_32x\h:
    addi.d       t6,    a0,    16
    vld          vr3,   a0,    0
    vldx         vr4,   a0,    a1  //7
    vld          vr8,   t6,    0
    vldx         vr9,   t6,    a1

    VMULW4_H  vr0, vr1, vr16, vr16, vr10, vr11, vr12, vr13
    VMULW4_H  vr5, vr6, vr16, vr16, vr20, vr21, vr22, vr23
    VMADDW4_H vr1, vr2, vr17, vr17, vr10, vr11, vr12, vr13
    VMADDW4_H vr6, vr7, vr17, vr17, vr20, vr21, vr22, vr23
    VMADDW4_H vr2, vr3, vr18, vr18, vr10, vr11, vr12, vr13
    VMADDW4_H vr7, vr8, vr18, vr18, vr20, vr21, vr22, vr23
    VMADDW4_H vr3, vr4, vr19, vr19, vr10, vr11, vr12, vr13
    VMADDW4_H vr8, vr9, vr19, vr19, vr20, vr21, vr22, vr23

    vor.v            vr0,  vr2,  vr2
    vor.v            vr1,  vr3,  vr3
    vor.v            vr2,  vr4,  vr4
    vor.v            vr5,  vr7,  vr7
    vor.v            vr6,  vr8,  vr8
    vor.v            vr7,  vr9,  vr9

    vssrarni.bu.h    vr12, vr10, 6
    vssrarni.bu.h    vr13, vr11, 6
    vssrarni.bu.h    vr22, vr20, 6
    vssrarni.bu.h    vr23, vr21, 6

    vilvl.b          vr10, vr13, vr12
    vilvh.b          vr11, vr13, vr12
    vilvl.b          vr20, vr23, vr22
    vilvh.b          vr21, vr23, vr22

    vst              vr10, a2,   0
    vst              vr20, a2,   16
    add.d            a0,   a0,   t1
    add.d            a2,   a2,   a3
    addi.d           t0,   t0,   -1
    vst              vr11, a2,   0
    vst              vr21, a2,   16
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_4tap_32x\h
endfunc
.endm

VERT_4TAP_PP_32xN 8
VERT_4TAP_PP_32xN 16
VERT_4TAP_PP_32xN 24
VERT_4TAP_PP_32xN 32
VERT_4TAP_PP_32xN 48
VERT_4TAP_PP_32xN 64

function x265_interp_4tap_vert_pp_48x64_lsx
    slli.d       t7,    a4,    5
    la.local     t6,    g_chromaFilter
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  64
    sub.d        a0,    a0,    a1

    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6

    add.d        t6,    a0,    a1
    vld          vr0,   a0,    0    //0
    vld          vr1,   a0,    16   //0
    vld          vr2,   a0,    32   //0

    add.d        a0,    t6,    a1
    vld          vr3,   t6,    0   //1
    vld          vr4,   t6,    16  //1
    vld          vr5,   t6,    32  //1

    add.d        t6,    a0,    a1
    vld          vr6,   a0,    0    //2
    vld          vr7,   a0,    16   //2
    vld          vr8,   a0,    32   //2
.loopV_4tap_48x64:
    vld          vr9,   t6,    0
    vld          vr10,  t6,    16
    vld          vr11,  t6,    32

    VMULW4_H  vr0, vr1, vr16, vr16, vr12, vr13, vr14, vr15
    vmulwev.h.bu.b  vr20, vr2,  vr16
    vmulwod.h.bu.b  vr21, vr2,  vr16
    VMADDW4_H vr3, vr4, vr17, vr17, vr12, vr13, vr14, vr15
    vmaddwev.h.bu.b vr20, vr5,  vr17
    vmaddwod.h.bu.b vr21, vr5,  vr17
    VMADDW4_H vr6, vr7, vr18, vr18, vr12, vr13, vr14, vr15
    vmaddwev.h.bu.b vr20, vr8,  vr18
    vmaddwod.h.bu.b vr21, vr8,  vr18
    VMADDW4_H vr9, vr10, vr19, vr19, vr12, vr13, vr14, vr15
    vmaddwev.h.bu.b vr20, vr11, vr19
    vmaddwod.h.bu.b vr21, vr11, vr19

    vssrarni.bu.h    vr14, vr12, 6
    vssrarni.bu.h    vr15, vr13, 6
    vssrarni.bu.h    vr22, vr20, 6
    vssrarni.bu.h    vr23, vr21, 6

    vor.v            vr0,  vr3,  vr3
    vor.v            vr1,  vr4,  vr4
    vor.v            vr2,  vr5,  vr5
    vor.v            vr3,  vr6,  vr6
    vor.v            vr4,  vr7,  vr7
    vor.v            vr5,  vr8,  vr8
    vor.v            vr6,  vr9,  vr9
    vor.v            vr7,  vr10, vr10
    vor.v            vr8,  vr11, vr11
    vilvl.b          vr12, vr15, vr14
    vilvh.b          vr13, vr15, vr14
    vilvl.b          vr20, vr23, vr22

    vst              vr12, a2,   0
    vst              vr13, a2,   16
    vst              vr20, a2,   32
    addi.d           t0,   t0,   -1
    add.d            t6,   t6,   a1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_4tap_48x64
endfunc

.macro VERT_4TAP_PP_64xN  h
function x265_interp_4tap_vert_pp_64x\h\()_lsx
    slli.d       t7,    a4,    5
    la.local     t6,    g_chromaFilter
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h
    sub.d        a0,    a0,    a1
    addi.d       sp,    sp,    -32
    fst.d        f24,   sp,    0
    fst.d        f25,   sp,    8
    fst.d        f26,   sp,    16
    fst.d        f27,   sp,    24

    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6

    add.d        t6,    a0,    a1
    vld          vr0,   a0,    0    //0
    vld          vr1,   a0,    16
    vld          vr2,   a0,    32
    vld          vr3,   a0,    48

    add.d        a0,    t6,    a1
    vld          vr4,   t6,    0    //1
    vld          vr5,   t6,    16
    vld          vr6,   t6,    32
    vld          vr7,   t6,    48

    add.d        t6,    a0,    a1
    vld          vr8,   a0,    0    //2
    vld          vr9,   a0,    16
    vld          vr10,  a0,    32
    vld          vr11,  a0,    48
.loopV_4tap_64x\h:
    vld          vr12,  t6,    0    //3
    vld          vr13,  t6,    16
    vld          vr14,  t6,    32
    vld          vr15,  t6,    48

    VMULW4_H  vr0, vr1, vr16, vr16, vr20, vr21, vr22, vr23
    VMULW4_H  vr2, vr3, vr16, vr16, vr24, vr25, vr26, vr27
    VMADDW4_H vr4, vr5, vr17, vr17, vr20, vr21, vr22, vr23
    VMADDW4_H vr6, vr7, vr17, vr17, vr24, vr25, vr26, vr27
    VMADDW4_H vr8, vr9, vr18, vr18, vr20, vr21, vr22, vr23
    VMADDW4_H vr10, vr11, vr18, vr18, vr24, vr25, vr26, vr27
    VMADDW4_H vr12, vr13, vr19, vr19, vr20, vr21, vr22, vr23
    VMADDW4_H vr14, vr15, vr19, vr19, vr24, vr25, vr26, vr27

    vor.v            vr0,  vr4,  vr4
    vor.v            vr1,  vr5,  vr5
    vor.v            vr2,  vr6,  vr6
    vor.v            vr3,  vr7,  vr7

    vssrarni.bu.h    vr22, vr20, 6
    vssrarni.bu.h    vr23, vr21, 6
    vssrarni.bu.h    vr26, vr24, 6
    vssrarni.bu.h    vr27, vr25, 6

    vor.v            vr4,  vr8,  vr8
    vor.v            vr5,  vr9,  vr9
    vor.v            vr6,  vr10, vr10
    vor.v            vr7,  vr11, vr11

    vilvl.b          vr20, vr23, vr22
    vilvh.b          vr21, vr23, vr22
    vilvl.b          vr24, vr27, vr26
    vilvh.b          vr25, vr27, vr26

    vor.v            vr8,  vr12, vr12
    vor.v            vr9,  vr13, vr13
    vor.v            vr10, vr14, vr14
    vor.v            vr11, vr15, vr15

    vst              vr20, a2,   0
    vst              vr21, a2,   16
    vst              vr24, a2,   32
    vst              vr25, a2,   48
    addi.d           t0,   t0,   -1
    add.d            t6,   t6,   a1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_4tap_64x\h
    fld.d        f24,   sp,    0
    fld.d        f25,   sp,    8
    fld.d        f26,   sp,    16
    fld.d        f27,   sp,    24
    addi.d       sp,    sp,    32
endfunc
.endm

VERT_4TAP_PP_64xN 16
VERT_4TAP_PP_64xN 32
VERT_4TAP_PP_64xN 48
VERT_4TAP_PP_64xN 64

.macro LASX_VERT_4TAP_PP_16xN  h
function x265_interp_4tap_vert_pp_16x\h\()_lasx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    la.local     t6,    g_chromaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/2
    sub.d        a0,    a0,    a1
    slli.d       t7,    a3,    1

    xvldrepl.b   xr16,  t5,    0
    xvldrepl.b   xr17,  t5,    2
    xvldrepl.b   xr18,  t5,    4
    xvldrepl.b   xr19,  t5,    6

    add.d        t6,    a0,    t2
    vld          vr0,   a0,    0    //0
    vldx         vr1,   a0,    a1   //1
    vldx         vr2,   a0,    t1   //2
    xvpermi.q    xr0,   xr1,   0x2  //0,1
    xvpermi.q    xr1,   xr2,   0x2  //1,2
.lasx_loopV_4tap_16x\h:
    xvld         xr3,   t6,    0   //3
    xvldx        xr4,   t6,    a1  //4
    xvpermi.q    xr2,   xr3,   0x2  //2,3
    xvpermi.q    xr3,   xr4,   0x2  //3,4

    xvmulwev.h.bu.b  xr10, xr0, xr16
    xvmulwod.h.bu.b  xr11, xr0, xr16
    XMADDW4_H xr1, xr2, xr17, xr18, xr10, xr11, xr10, xr11
    xvmaddwev.h.bu.b xr10, xr3, xr19
    xvmaddwod.h.bu.b xr11, xr3, xr19

    xvor.v           xr0,  xr2,  xr2
    xvor.v           xr1,  xr3,  xr3
    xvor.v           xr2,  xr4,  xr4

    xvssrarni.bu.h   xr11, xr10, 6
    xvpermi.d        xr12, xr11, 0xB1
    add.d            t6,   t6,   t1
    xvilvl.b         xr13, xr12, xr11
    addi.d           t0,   t0,   -1
    xvpermi.d        xr14, xr13, 0x4E
    vst              vr13, a2,   0
    vstx             vr14, a2,   a3
    add.d            a2,   a2,   t7
    blt              zero, t0,   .lasx_loopV_4tap_16x\h
endfunc
.endm

LASX_VERT_4TAP_PP_16xN 4
LASX_VERT_4TAP_PP_16xN 8
LASX_VERT_4TAP_PP_16xN 12
LASX_VERT_4TAP_PP_16xN 16
LASX_VERT_4TAP_PP_16xN 24
LASX_VERT_4TAP_PP_16xN 32
LASX_VERT_4TAP_PP_16xN 64

.macro LASX_VERT_4TAP_PP_24xN  h
function x265_interp_4tap_vert_pp_24x\h\()_lasx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    la.local     t6,    g_chromaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/2
    sub.d        a0,    a0,    a1

    xvldrepl.b   xr16,  t5,    0
    xvldrepl.b   xr17,  t5,    2
    xvldrepl.b   xr18,  t5,    4
    xvldrepl.b   xr19,  t5,    6

    add.d        t6,    a0,    t2
    xvld         xr0,   a0,    0    //0
    xvldx        xr1,   a0,    a1   //1
    xvldx        xr2,   a0,    t1   //2

.lasx_loopV_4tap_24x\h:
    xvld         xr3,   t6,    0   //3
    xvldx        xr4,   t6,    a1  //4

    XMULW4_H  xr0, xr1, xr16, xr16, xr10, xr11, xr12, xr13
    XMADDW4_H xr1, xr2, xr17, xr17, xr10, xr11, xr12, xr13
    XMADDW4_H xr2, xr3, xr18, xr18, xr10, xr11, xr12, xr13
    XMADDW4_H xr3, xr4, xr19, xr19, xr10, xr11, xr12, xr13

    xvor.v           xr0,  xr2,  xr2
    xvor.v           xr1,  xr3,  xr3
    xvor.v           xr2,  xr4,  xr4

    xvssrarni.bu.h   xr12, xr10, 6
    xvssrarni.bu.h   xr13, xr11, 6
    add.d            t7,   a2,   a3
    xvilvl.b         xr14, xr13, xr12
    xvilvh.b         xr15, xr13, xr12

    vst              vr14, a2,   0
    xvstelm.d        xr14, a2,   16,  2
    vst              vr15, t7,   0
    xvstelm.d        xr15, t7,   16,  2
    add.d            t6,   t6,   t1
    add.d            a2,   a3,   t7
    addi.d           t0,   t0,   -1
    blt              zero, t0,   .lasx_loopV_4tap_24x\h
endfunc
.endm

LASX_VERT_4TAP_PP_24xN 32
LASX_VERT_4TAP_PP_24xN 64

function x265_interp_4tap_vert_pp_48x64_lasx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    la.local     t6,    g_chromaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  32
    sub.d        a0,    a0,    a1

    xvldrepl.b   xr16,  t5,    0
    xvldrepl.b   xr17,  t5,    2
    xvldrepl.b   xr18,  t5,    4
    xvldrepl.b   xr19,  t5,    6

    addi.d       t6,    a0,    32
    xvld         xr0,   a0,    0    //0
    xvldx        xr1,   a0,    a1   //1
    xvldx        xr2,   a0,    t1   //2
    add.d        a0,    a0,    t2

    vld          vr5,   t6,    0
    vldx         vr6,   t6,    a1
    vldx         vr7,   t6,    t1

    xvpermi.q    xr5,   xr6,   0x2
    xvpermi.q    xr6,   xr7,   0x2
.lasx_loopV_4tap_48x64:
    addi.d       t6,    a0,    32
    xvld         xr3,   a0,    0   //3
    xvldx        xr4,   a0,    a1  //4
    vld          vr8,   t6,    0
    vldx         vr9,   t6,    a1

    xvpermi.q    xr7,   xr8,   0x2
    xvpermi.q    xr8,   xr9,   0x2
    XMULW4_H  xr0, xr1, xr16, xr16, xr10, xr11, xr12, xr13
    xvmulwev.h.bu.b  xr14, xr5,  xr16
    xvmulwod.h.bu.b  xr15, xr5,  xr16
    XMADDW4_H xr1, xr2, xr17, xr17, xr10, xr11, xr12, xr13
    xvmaddwev.h.bu.b xr14, xr6,  xr17
    xvmaddwod.h.bu.b xr15, xr6,  xr17
    XMADDW4_H xr2, xr3, xr18, xr18, xr10, xr11, xr12, xr13
    xvmaddwev.h.bu.b xr14, xr7,  xr18
    xvmaddwod.h.bu.b xr15, xr7,  xr18
    XMADDW4_H xr3, xr4, xr19, xr19, xr10, xr11, xr12, xr13
    xvmaddwev.h.bu.b xr14, xr8,  xr19
    xvmaddwod.h.bu.b xr15, xr8,  xr19

    xvor.v           xr0,  xr2,  xr2
    xvor.v           xr1,  xr3,  xr3
    xvor.v           xr2,  xr4,  xr4
    xvor.v           xr5,  xr7,  xr7
    xvor.v           xr6,  xr8,  xr8
    xvor.v           xr7,  xr9,  xr9

    xvssrarni.bu.h   xr15, xr14, 6
    xvssrarni.bu.h   xr12, xr10, 6
    xvssrarni.bu.h   xr13, xr11, 6
    xvpermi.d        xr14, xr15, 0xB1
    add.d            t7,   a2,   a3
    xvilvl.b         xr20, xr13, xr12
    xvilvh.b         xr21, xr13, xr12
    xvilvl.b         xr22, xr14, xr15
    xvst             xr20, a2,   0
    vst              vr22, a2,   32
    xvpermi.d        xr23, xr22, 0x4E
    add.d            a0,   a0,   t1
    xvst             xr21, t7,   0
    vst              vr23, t7,   32
    add.d            a2,   a3,   t7
    addi.d           t0,   t0,   -1
    blt              zero, t0,   .lasx_loopV_4tap_48x64
endfunc

.macro LASX_VERT_4TAP_PP_32xN  h
function x265_interp_4tap_vert_pp_32x\h\()_lasx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    la.local     t6,    g_chromaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/2
    sub.d        a0,    a0,    a1
    slli.d       t7,    a3,    1

    xvldrepl.b   xr16,  t5,    0
    xvldrepl.b   xr17,  t5,    2
    xvldrepl.b   xr18,  t5,    4
    xvldrepl.b   xr19,  t5,    6

    add.d        t6,    a0,    t2
    xvld         xr0,   a0,    0    //0
    xvldx        xr1,   a0,    a1   //1
    xvldx        xr2,   a0,    t1   //2

.lasx_loopV_4tap_32x\h:
    xvld         xr3,   t6,    0   //3
    xvldx        xr4,   t6,    a1  //4

    XMULW4_H  xr0, xr1, xr16, xr16, xr10, xr11, xr12, xr13
    XMADDW4_H xr1, xr2, xr17, xr17, xr10, xr11, xr12, xr13
    XMADDW4_H xr2, xr3, xr18, xr18, xr10, xr11, xr12, xr13
    XMADDW4_H xr3, xr4, xr19, xr19, xr10, xr11, xr12, xr13

    xvor.v           xr0,  xr2,  xr2
    xvor.v           xr1,  xr3,  xr3
    xvor.v           xr2,  xr4,  xr4

    xvssrarni.bu.h   xr12, xr10, 6
    xvssrarni.bu.h   xr13, xr11, 6
    xvilvl.b         xr14, xr13, xr12
    xvilvh.b         xr15, xr13, xr12

    xvst             xr14, a2,   0
    xvstx            xr15, a2,   a3
    add.d            t6,   t6,   t1
    add.d            a2,   a2,   t7
    addi.d           t0,   t0,   -1
    blt              zero, t0,   .lasx_loopV_4tap_32x\h
endfunc
.endm

LASX_VERT_4TAP_PP_32xN 8
LASX_VERT_4TAP_PP_32xN 16
LASX_VERT_4TAP_PP_32xN 24
LASX_VERT_4TAP_PP_32xN 32
LASX_VERT_4TAP_PP_32xN 48
LASX_VERT_4TAP_PP_32xN 64

.macro LASX_VERT_4TAP_PP_64xN  h
function x265_interp_4tap_vert_pp_64x\h\()_lasx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    la.local     t6,    g_chromaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/2
    sub.d        a0,    a0,    a1

    xvldrepl.b   xr16,  t5,    0
    xvldrepl.b   xr17,  t5,    2
    xvldrepl.b   xr18,  t5,    4
    xvldrepl.b   xr19,  t5,    6

    addi.d       t6,    a0,    32
    xvld         xr0,   a0,    0    //0
    xvldx        xr1,   a0,    a1   //1
    xvldx        xr2,   a0,    t1   //2

    add.d        a0,    a0,    t2
    xvld         xr5,   t6,    0
    xvldx        xr6,   t6,    a1
    xvldx        xr7,   t6,    t1

.lasx_loopV_4tap_64x\h:
    addi.d       t6,    a0,    32
    xvld         xr3,   a0,    0
    xvldx        xr4,   a0,    a1  //7
    xvld         xr8,   t6,    0
    xvldx        xr9,   t6,    a1

    XMULW4_H  xr0, xr1, xr16, xr16, xr10, xr11, xr12, xr13
    XMULW4_H  xr5, xr6, xr16, xr16, xr20, xr21, xr22, xr23
    XMADDW4_H xr1, xr2, xr17, xr17, xr10, xr11, xr12, xr13
    XMADDW4_H xr6, xr7, xr17, xr17, xr20, xr21, xr22, xr23
    XMADDW4_H xr2, xr3, xr18, xr18, xr10, xr11, xr12, xr13
    XMADDW4_H xr7, xr8, xr18, xr18, xr20, xr21, xr22, xr23
    XMADDW4_H xr3, xr4, xr19, xr19, xr10, xr11, xr12, xr13
    XMADDW4_H xr8, xr9, xr19, xr19, xr20, xr21, xr22, xr23

    xvor.v           xr0,  xr2,  xr2
    xvor.v           xr1,  xr3,  xr3
    xvor.v           xr2,  xr4,  xr4
    xvor.v           xr5,  xr7,  xr7
    xvor.v           xr6,  xr8,  xr8
    xvor.v           xr7,  xr9,  xr9

    xvssrarni.bu.h   xr12, xr10, 6
    xvssrarni.bu.h   xr13, xr11, 6
    xvssrarni.bu.h   xr22, xr20, 6
    xvssrarni.bu.h   xr23, xr21, 6

    xvilvl.b         xr10, xr13, xr12
    xvilvh.b         xr11, xr13, xr12
    xvilvl.b         xr20, xr23, xr22
    xvilvh.b         xr21, xr23, xr22

    xvst             xr10, a2,   0
    xvst             xr20, a2,   32
    add.d            a0,   a0,   t1
    add.d            a2,   a2,   a3
    addi.d           t0,   t0,   -1
    xvst             xr11, a2,   0
    xvst             xr21, a2,   32
    add.d            a2,   a2,   a3
    blt              zero, t0,   .lasx_loopV_4tap_64x\h
endfunc
.endm

LASX_VERT_4TAP_PP_64xN 16
LASX_VERT_4TAP_PP_64xN 32
LASX_VERT_4TAP_PP_64xN 48
LASX_VERT_4TAP_PP_64xN 64

function x265_interp_4tap_vert_ps_2x4_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    slli.d       a3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    sub.d        a0,    a0,    a1  //src -= srcStride
    vldx         vr16,  t6,    t7
    vld          vr17,  t4,    0

    add.d        t6,    a0,    t3
    fld.s        f0,    a0,    0    //0
    fldx.s       f1,    a0,    a1   //1
    fldx.s       f2,    a0,    t1   //2
    fldx.s       f3,    a0,    t2   //3
    fld.s        f4,    t6,    0    //4
    fldx.s       f5,    t6,    a1   //5
    fldx.s       f6,    t6,    t1   //6

    vilvl.h      vr8,   vr1,   vr0  //0, 1
    vilvl.h      vr9,   vr3,   vr2  //2, 3
    vilvl.h      vr10,  vr2,   vr1  //1, 2
    vilvl.h      vr11,  vr4,   vr3  //3, 4
    vilvl.h      vr12,  vr5,   vr4  //4, 5
    vilvl.h      vr14,  vr6,   vr5  //5, 6

    vilvl.w      vr0,   vr9,   vr8  //0,1,2,3
    vilvl.w      vr1,   vr11,  vr10 //1,2,3,4
    vilvl.w      vr2,   vr12,  vr9  //2,3,4,5
    vilvl.w      vr3,   vr14,  vr11 //3,4,5,6

    vilvl.d      vr4,   vr1,   vr0  //0,1,2,3,1,2,3,4
    vilvl.d      vr5,   vr3,   vr2  //2,3,4,5,3,4,5,6

    VMULW4_H  vr4, vr5, vr16, vr16, vr6, vr7, vr8, vr9
    vhaddw.w.h   vr0,   vr6,   vr6
    vhaddw.w.h   vr1,   vr7,   vr7
    vhaddw.w.h   vr2,   vr8,   vr8
    vhaddw.w.h   vr3,   vr9,   vr9

    vpickev.h    vr4,   vr2,   vr0
    vpickev.h    vr5,   vr3,   vr1
    vhaddw.w.h   vr6,   vr4,   vr4
    vhaddw.w.h   vr7,   vr5,   vr5
    vpackev.h    vr8,   vr7,   vr6

    vadd.h       vr10,  vr8,   vr17

    vstelm.w         vr10, a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.w         vr10, a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.w         vr10, a2,   0,   2
    add.d            a2,   a2,   a3
    vstelm.w         vr10, a2,   0,   3
endfunc

.macro VERT_4TAP_PS_2xH  h
function x265_interp_4tap_vert_ps_2x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    slli.d       a3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    sub.d        a0,    a0,    a1  //src -= srcStride
    addi.d       t0,    zero,  \h/8
    vldx         vr16,  t6,    t7
    vld          vr17,  t4,    0

.loopV_ps_4tap_2x\h:
    add.d        t6,    a0,    t3
    fld.s        f0,    a0,    0    //0
    fldx.s       f1,    a0,    a1   //1
    fldx.s       f2,    a0,    t1   //2
    fldx.s       f3,    a0,    t2   //3

    fld.s        f4,    t6,    0    //4
    fldx.s       f5,    t6,    a1   //5
    fldx.s       f6,    t6,    t1   //6
    fldx.s       f7,    t6,    t2   //7
    add.d        a0,    t6,    t3

    vilvl.h      vr8,   vr1,   vr0  //0, 1
    vilvl.h      vr9,   vr3,   vr2  //2, 3
    vilvl.h      vr10,  vr2,   vr1  //1, 2
    vilvl.h      vr11,  vr4,   vr3  //3, 4
    vilvl.h      vr12,  vr5,   vr4  //4, 5
    vilvl.h      vr13,  vr7,   vr6  //6, 7
    vilvl.h      vr14,  vr6,   vr5  //5, 6

    vilvl.w      vr0,   vr9,   vr8  //0,1,2,3
    vilvl.w      vr1,   vr11,  vr10 //1,2,3,4
    vilvl.w      vr2,   vr12,  vr9  //2,3,4,5
    vilvl.w      vr3,   vr14,  vr11 //3,4,5,6
    vilvl.w      vr4,   vr13,  vr12 //4,5,6,7

    fld.s        f8,    a0,    0    //8
    fldx.s       f9,    a0,    a1   //9
    fldx.s       f10,   a0,    t1   //10

    vilvl.h      vr15,  vr8,   vr7  //7, 8
    vilvl.h      vr11,  vr9,   vr8  //8, 9
    vilvl.h      vr12,  vr10,  vr9  //9, 10

    vilvl.w      vr5,   vr15,  vr14 //5,6,7,8
    vilvl.w      vr6,   vr11,  vr13 //6,7,8,9
    vilvl.w      vr7,   vr12,  vr15 //7,8,9,10

    vilvl.d      vr8,   vr1,   vr0
    vilvl.d      vr9,   vr3,   vr2
    vilvl.d      vr10,  vr5,   vr4
    vilvl.d      vr11,  vr7,   vr6

    VMULW4_H  vr8, vr9, vr16, vr16, vr0, vr1, vr2, vr3
    VMULW4_H  vr10, vr11, vr16, vr16, vr4, vr5, vr6, vr7

.irp x, vr0, vr1, vr2, vr3, vr4, vr5, vr6, vr7
    vhaddw.w.h  \x, \x, \x
.endr

    vpickev.h    vr8,   vr2,   vr0
    vpickev.h    vr9,   vr3,   vr1
    vpickev.h    vr10,  vr6,   vr4
    vpickev.h    vr11,  vr7,   vr5
.irp x, vr8, vr9, vr10, vr11
    vhaddw.w.h  \x, \x, \x
.endr
    vpackev.h    vr0,   vr9,   vr8
    vpackev.h    vr1,   vr11,  vr10
    vadd.h       vr0,   vr0,   vr17
    vadd.h       vr1,   vr1,   vr17
    addi.d           t0,   t0,   -1
    vstelm.w         vr0,  a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.w         vr0,  a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.w         vr0,  a2,   0,   2
    add.d            a2,   a2,   a3
    vstelm.w         vr0,  a2,   0,   3
    add.d            a2,   a2,   a3
    vstelm.w         vr1,  a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.w         vr1,  a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.w         vr1,  a2,   0,   2
    add.d            a2,   a2,   a3
    vstelm.w         vr1,  a2,   0,   3
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_ps_4tap_2x\h
endfunc
.endm

VERT_4TAP_PS_2xH  8
VERT_4TAP_PS_2xH  16

function x265_interp_4tap_vert_ps_4x2_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    slli.d       a3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    sub.d        a0,    a0,    a1  //src -= srcStride
    vldx         vr16,  t6,    t7
    vld          vr17,  t4,    0

    fld.s        f0,    a0,    0    //0
    fldx.s       f1,    a0,    a1   //1
    fldx.s       f2,    a0,    t1   //2
    fldx.s       f3,    a0,    t2   //3
    fldx.s       f4,    a0,    t3   //4

    vilvl.h      vr8,   vr1,   vr0  //0, 1
    vilvl.h      vr9,   vr3,   vr2  //2, 3
    vilvl.h      vr10,  vr2,   vr1  //1, 2
    vilvl.h      vr11,  vr4,   vr3  //3, 4

    vilvl.w      vr0,   vr9,   vr8  //0,1,2,3
    vilvl.w      vr1,   vr11,  vr10 //1,2,3,4

    VMULW4_H vr0, vr1, vr16, vr16, vr9, vr10, vr11, vr12

    vhaddw.w.h   vr0,   vr9,   vr9
    vhaddw.w.h   vr1,   vr10,  vr10
    vhaddw.w.h   vr2,   vr11,  vr11
    vhaddw.w.h   vr3,   vr12,  vr12

    vpickev.h    vr4,   vr1,   vr0
    vpickev.h    vr5,   vr3,   vr2
    vhaddw.w.h   vr6,   vr4,   vr4
    vhaddw.w.h   vr7,   vr5,   vr5
    vpickev.h    vr8,   vr7,   vr6
    vadd.h       vr9,   vr8,   vr17

    vshuf4i.h        vr10, vr9,  0xD8
    vstelm.d         vr10, a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.d         vr10, a2,   0,   1
endfunc

function x265_interp_4tap_vert_ps_4x4_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    slli.d       a3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    sub.d        a0,    a0,    a1  //src -= srcStride
    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vld          vr20,  t4,    0

    add.d        t6,    a0,    t3
    fld.s        f0,    a0,    0    //0
    fldx.s       f1,    a0,    a1   //1
    fldx.s       f2,    a0,    t1   //2
    fldx.s       f3,    a0,    t2   //3
    fld.s        f4,    t6,    0    //4
    fldx.s       f5,    t6,    a1   //5
    fldx.s       f6,    t6,    t1   //6

    vilvl.b      vr8,   vr1,   vr0  //0, 1
    vilvl.b      vr9,   vr3,   vr2  //2, 3
    vilvl.b      vr10,  vr2,   vr1  //1, 2
    vilvl.b      vr11,  vr4,   vr3  //3, 4
    vilvl.b      vr12,  vr5,   vr4  //4, 5
    vilvl.b      vr14,  vr6,   vr5  //5, 6

    vilvl.d      vr0,   vr9,   vr8  //0,1,2,3
    vilvl.d      vr1,   vr11,  vr10 //1,2,3,4
    vilvl.d      vr2,   vr12,  vr9  //2,3,4,5
    vilvl.d      vr3,   vr14,  vr11 //3,4,5,6

    vor.v        vr9,   vr20,  vr20

    VMADDW4_H vr0, vr1, vr16, vr17, vr9, vr20, vr9, vr20
    VMADDW4_H vr2, vr3, vr18, vr19, vr9, vr20, vr9, vr20
    vstelm.d         vr9,  a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.d         vr20, a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.d         vr9,  a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.d         vr20, a2,   0,   1
endfunc

.macro VERT_4TAP_PS_4xH  h
function x265_interp_4tap_vert_ps_4x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    slli.d       a3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    sub.d        a0,    a0,    a1  //src -= srcStride
    addi.d       t0,    zero,  \h/8
    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vld          vr20,  t4,    0

.loopV_ps_4tap_4x\h:
    add.d        t6,    a0,    t3
    fld.s        f0,    a0,    0    //0
    fldx.s       f1,    a0,    a1   //1
    fldx.s       f2,    a0,    t1   //2
    fldx.s       f3,    a0,    t2   //3

    fld.s        f4,    t6,    0    //4
    fldx.s       f5,    t6,    a1   //5
    fldx.s       f6,    t6,    t1   //6
    fldx.s       f7,    t6,    t2   //7
    add.d        a0,    t6,    t3

    vilvl.b      vr8,   vr1,   vr0  //0, 1
    vilvl.b      vr9,   vr3,   vr2  //2, 3
    vilvl.b      vr10,  vr2,   vr1  //1, 2
    vilvl.b      vr11,  vr4,   vr3  //3, 4
    vilvl.b      vr12,  vr5,   vr4  //4, 5
    vilvl.b      vr13,  vr7,   vr6  //6, 7
    vilvl.b      vr14,  vr6,   vr5  //5, 6

    vilvl.d      vr0,   vr9,   vr8  //0,1,2,3
    vilvl.d      vr1,   vr11,  vr10 //1,2,3,4
    vilvl.d      vr2,   vr12,  vr9  //2,3,4,5
    vilvl.d      vr3,   vr14,  vr11 //3,4,5,6
    vilvl.d      vr4,   vr13,  vr12 //4,5,6,7

    fld.s        f8,    a0,    0    //8
    fldx.s       f9,    a0,    a1   //9
    fldx.s       f10,   a0,    t1   //10

    vilvl.b      vr15,  vr8,   vr7  //7, 8
    vilvl.b      vr11,  vr9,   vr8  //8, 9
    vilvl.b      vr12,  vr10,  vr9  //9, 10

    vilvl.d      vr5,   vr15,  vr14 //5,6,7,8
    vilvl.d      vr6,   vr11,  vr13 //6,7,8,9
    vilvl.d      vr7,   vr12,  vr15 //7,8,9,10

.irp x, vr9, vr10, vr11, vr12
    vor.v        \x,    vr20,  vr20
.endr
    VMADDW4_H vr0, vr4, vr16, vr16, vr9, vr10, vr11, vr12
    VMADDW4_H vr1, vr5, vr17, vr17, vr9, vr10, vr11, vr12
    VMADDW4_H vr2, vr6, vr18, vr18, vr9, vr10, vr11, vr12
    VMADDW4_H vr3, vr7, vr19, vr19, vr9, vr10, vr11, vr12

    addi.d           t0,   t0,   -1
    vstelm.d         vr9,  a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.d         vr10, a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.d         vr9,  a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.d         vr10, a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.d         vr11, a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.d         vr12, a2,   0,   0
    add.d            a2,   a2,   a3
    vstelm.d         vr11, a2,   0,   1
    add.d            a2,   a2,   a3
    vstelm.d         vr12, a2,   0,   1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_ps_4tap_4x\h
endfunc
.endm

VERT_4TAP_PS_4xH  8
VERT_4TAP_PS_4xH  16
VERT_4TAP_PS_4xH  32

.macro VERT_4TAP_PS_6xN  h
function x265_interp_4tap_vert_ps_6x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    slli.d       a3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    sub.d        t6,    a0,    a1  //src -= srcStride
    addi.d       t0,    zero,  \h/4
    vld          vr15,  t4,    0
    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6

    add.d        a0,    t6,    t2
    fld.d        f8,    t6,    0    //0
    fldx.d       f9,    t6,    a1   //1
    fldx.d       f10,   t6,    t1   //2

    vilvl.b      vr0,   vr9,   vr8  //0,1
    vilvl.b      vr1,   vr10,  vr9  //1,2
.loopV_ps_4tap_6x\h:
    fld.d        f11,   a0,    0    //3
    fldx.d       f12,   a0,    a1   //4
    fldx.d       f13,   a0,    t1   //5
    fldx.d       f14,   a0,    t2   //6
    add.d        a0,    a0,    t3
    vilvl.b      vr2,   vr11,  vr10 //2,3
    vilvl.b      vr3,   vr12,  vr11 //3,4
    vilvl.b      vr4,   vr13,  vr12 //4,5
    vilvl.b      vr5,   vr14,  vr13 //5,6

.irp x, vr20, vr21, vr22, vr23
    vor.v        \x,    vr15,  vr15
.endr
    VMADDW4_H vr0, vr2, vr16, vr16, vr20, vr21, vr22, vr23
    VMADDW4_H vr1, vr3, vr17, vr17, vr20, vr21, vr22, vr23
    VMADDW4_H vr2, vr4, vr18, vr18, vr20, vr21, vr22, vr23
    VMADDW4_H vr3, vr5, vr19, vr19, vr20, vr21, vr22, vr23
    vor.v            vr0,  vr4,  vr4
    vor.v            vr1,  vr5,  vr5
    vor.v            vr10, vr14, vr14

    addi.d           t0,   t0,   -1
    vstelm.d         vr20, a2,   0,   0
    vstelm.w         vr20, a2,   8,   2
    add.d            a2,   a2,   a3
    vstelm.d         vr21, a2,   0,   0
    vstelm.w         vr21, a2,   8,   2
    add.d            a2,   a2,   a3
    vstelm.d         vr22, a2,   0,   0
    vstelm.w         vr22, a2,   8,   2
    add.d            a2,   a2,   a3
    vstelm.d         vr23, a2,   0,   0
    vstelm.w         vr23, a2,   8,   2
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_ps_4tap_6x\h
endfunc
.endm

VERT_4TAP_PS_6xN 8
VERT_4TAP_PS_6xN 16

.macro VERT_4TAP_PS_8x2N  h
function x265_interp_4tap_vert_ps_8x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       a3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t5,    t6,    t7
    add.d        t2,    t1,    a1
    sub.d        t6,    a0,    a1  //src -= srcStride
    addi.d       t0,    zero,  \h/2
    slli.d       t7,    a3,    1
    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vld          vr20,  t4,    0

    add.d        a0,    t6,    t2
    fld.d        f8,    t6,    0    //0
    fldx.d       f9,    t6,    a1   //1
    fldx.d       f10,   t6,    t1

    vilvl.b      vr0,   vr9,   vr8  //0,1
    vilvl.b      vr1,   vr10,  vr9  //1,2
.loopV_ps_4tap_8x\h:
    fld.d        f11,   a0,    0    //3
    fldx.d       f12,   a0,    a1   //4
    add.d        a0,    a0,    t1
    vilvl.b      vr2,   vr11,  vr10 //2,3
    vilvl.b      vr3,   vr12,  vr11 //3,4

    vor.v        vr21,  vr20,  vr20
    vor.v        vr22,  vr20,  vr20
    VMADDW4_H vr0, vr1, vr16, vr17, vr21, vr22, vr21, vr22
    VMADDW4_H vr2, vr3, vr18, vr19, vr21, vr22, vr21, vr22

    vor.v            vr0,  vr2,  vr2
    vor.v            vr1,  vr3,  vr3
    vor.v            vr10, vr12, vr12
    addi.d           t0,   t0,   -1
    vst              vr21, a2,   0
    vstx             vr22, a2,   a3
    add.d            a2,   a2,   t7
    blt              zero, t0,   .loopV_ps_4tap_8x\h
endfunc
.endm

VERT_4TAP_PS_8x2N 2
VERT_4TAP_PS_8x2N 6

.macro VERT_4TAP_PS_8xN  h
function x265_interp_4tap_vert_ps_8x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    slli.d       a3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    sub.d        t6,    a0,    a1  //src -= srcStride
    addi.d       t0,    zero,  \h/4
    vld          vr15,  t4,    0
    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    slli.d       t4,    a3,    1  //dstStride * 2
    slli.d       t7,    a3,    2  //dstStride * 4
    add.d        t5,    t4,    a3

    add.d        a0,    t6,    t2
    fld.d        f8,    t6,    0    //0
    fldx.d       f9,    t6,    a1   //1
    fldx.d       f10,   t6,    t1   //2

    vilvl.b      vr0,   vr9,   vr8  //0,1
    vilvl.b      vr1,   vr10,  vr9  //1,2
.loopV_ps_4tap_8x\h:
    fld.d        f11,   a0,    0    //3
    fldx.d       f12,   a0,    a1   //4
    fldx.d       f13,   a0,    t1   //5
    fldx.d       f14,   a0,    t2   //6
    add.d        a0,    a0,    t3
    vilvl.b      vr2,   vr11,  vr10 //2,3
    vilvl.b      vr3,   vr12,  vr11 //3,4
    vilvl.b      vr4,   vr13,  vr12 //4,5
    vilvl.b      vr5,   vr14,  vr13 //5,6

.irp x, vr20, vr21, vr22, vr23
    vor.v        \x,    vr15,  vr15
.endr
    VMADDW4_H vr0, vr2, vr16, vr16, vr20, vr21, vr22, vr23
    VMADDW4_H vr1, vr3, vr17, vr17, vr20, vr21, vr22, vr23
    VMADDW4_H vr2, vr4, vr18, vr18, vr20, vr21, vr22, vr23
    VMADDW4_H vr3, vr5, vr19, vr19, vr20, vr21, vr22, vr23
    vor.v            vr0,  vr4,  vr4
    vor.v            vr1,  vr5,  vr5
    vor.v            vr10, vr14, vr14

    addi.d           t0,   t0,   -1
    vst              vr20, a2,   0
    vstx             vr21, a2,   a3
    vstx             vr22, a2,   t4
    vstx             vr23, a2,   t5
    add.d            a2,   a2,   t7
    blt              zero, t0,   .loopV_ps_4tap_8x\h
endfunc
.endm

VERT_4TAP_PS_8xN 4
VERT_4TAP_PS_8xN 8
VERT_4TAP_PS_8xN 12
VERT_4TAP_PS_8xN 16
VERT_4TAP_PS_8xN 32
VERT_4TAP_PS_8xN 64

.macro VERT_4TAP_PS_12xN  h
function x265_interp_4tap_vert_ps_12x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       a3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/2
    sub.d        t6,    a0,    a1
    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vld          vr20,  t4,    0

    add.d        a0,    t6,    t2
    vld          vr0,   t6,    0    //0
    vldx         vr1,   t6,    a1   //1
    vldx         vr2,   t6,    t1   //2

.loopV_ps_4tap_12x\h:
    vld          vr3,   a0,    0   //3
    vldx         vr4,   a0,    a1  //4
.irp x, vr10, vr11, vr12, vr13
    vor.v        \x,    vr20,  vr20
.endr
    VMADDW4_H vr0, vr1, vr16, vr16, vr10, vr11, vr12, vr13
    VMADDW4_H vr1, vr2, vr17, vr17, vr10, vr11, vr12, vr13
    VMADDW4_H vr2, vr3, vr18, vr18, vr10, vr11, vr12, vr13
    VMADDW4_H vr3, vr4, vr19, vr19, vr10, vr11, vr12, vr13
    vor.v        vr0,   vr2,   vr2
    vor.v        vr1,   vr3,   vr3
    vor.v        vr2,   vr4,   vr4

    vilvl.h      vr5,   vr11,  vr10
    vilvh.h      vr6,   vr11,  vr10
    vilvl.h      vr7,   vr13,  vr12
    vilvh.h      vr8,   vr13,  vr12

    addi.d           t0,   t0,   -1
    vst              vr5,  a2,   0
    vstelm.d         vr6,  a2,   16,  0
    add.d            a2,   a2,   a3
    vst              vr7,  a2,   0
    vstelm.d         vr8,  a2,   16,  0
    add.d            a0,   a0,   t1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_ps_4tap_12x\h
endfunc
.endm

VERT_4TAP_PS_12xN  16
VERT_4TAP_PS_12xN  32

.macro VERT_4TAP_PS_16xN  h
function x265_interp_4tap_vert_ps_16x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       a3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7  //g_lumaFilter
    addi.d       t0,    zero,  \h/2
    sub.d        t6,    a0,    a1
    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vld          vr20,  t4,    0

    add.d        a0,    t6,    t2
    vld          vr0,   t6,    0    //0
    vldx         vr1,   t6,    a1   //1
    vldx         vr2,   t6,    t1   //2

.loopV_ps_4tap_16x\h:
    vld          vr3,   a0,    0   //3
    vldx         vr4,   a0,    a1  //4
.irp x, vr10, vr11, vr12, vr13
    vor.v        \x,    vr20,  vr20
.endr
    VMADDW4_H vr0, vr1, vr16, vr16, vr10, vr11, vr12, vr13
    VMADDW4_H vr1, vr2, vr17, vr17, vr10, vr11, vr12, vr13
    VMADDW4_H vr2, vr3, vr18, vr18, vr10, vr11, vr12, vr13
    VMADDW4_H vr3, vr4, vr19, vr19, vr10, vr11, vr12, vr13
    vor.v        vr0,   vr2,   vr2
    vor.v        vr1,   vr3,   vr3
    vor.v        vr2,   vr4,   vr4

    vilvl.h      vr5,   vr11,  vr10
    vilvh.h      vr6,   vr11,  vr10
    vilvl.h      vr7,   vr13,  vr12
    vilvh.h      vr8,   vr13,  vr12

    vst              vr5,  a2,   0
    vst              vr6,  a2,   16
    add.d            a2,   a2,   a3
    add.d            a0,   a0,   t1
    addi.d           t0,   t0,   -1
    vst              vr7,  a2,   0
    vst              vr8,  a2,   16
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_ps_4tap_16x\h
endfunc
.endm

VERT_4TAP_PS_16xN 4
VERT_4TAP_PS_16xN 8
VERT_4TAP_PS_16xN 12
VERT_4TAP_PS_16xN 16
VERT_4TAP_PS_16xN 24
VERT_4TAP_PS_16xN 32
VERT_4TAP_PS_16xN 64

.macro VERT_4TAP_PS_24xN h
function x265_interp_4tap_vert_ps_24x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       a3,    a3,    1
    addi.d       sp,    sp,    -8
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    fst.d        f24,   sp,    0
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/2
    add.d        t2,    t1,    a1
    sub.d        a0,    a0,    a1

    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vld          vr24,  t4,    0

    addi.d       t6,    a0,    16
    vld          vr0,   a0,    0    //0
    vldx         vr1,   a0,    a1   //1
    vldx         vr2,   a0,    t1   //2

    add.d        a0,    a0,    t2
    fld.d        f5,    t6,    0
    fldx.d       f6,    t6,    a1
    fldx.d       f7,    t6,    t1
    vilvl.b      vr10,  vr6,   vr5  //0,1
    vilvl.b      vr11,  vr7,   vr6  //1,2

.loopV_ps_4tap_24x\h:
    addi.d       t6,    a0,    16
    vld          vr3,   a0,    0   //3
    vldx         vr4,   a0,    a1  //4
    fld.d        f8,    t6,    0
    fldx.d       f9,    t6,    a1

    vilvl.b      vr12,  vr8,   vr7  //2,3
    vilvl.b      vr13,  vr9,   vr8  //3,4

.irp x, vr20, vr21, vr22, vr23, vr14, vr15
    vor.v        \x,    vr24,  vr24
.endr
    VMADDW4_H  vr0, vr1, vr16, vr16, vr20, vr21, vr22, vr23
    vmaddwev.h.bu.b vr14,  vr10, vr16
    vmaddwod.h.bu.b vr15,  vr10, vr16
    VMADDW4_H vr1, vr2, vr17, vr17, vr20, vr21, vr22, vr23
    vmaddwev.h.bu.b vr14, vr11, vr17
    vmaddwod.h.bu.b vr15, vr11, vr17
    VMADDW4_H vr2, vr3, vr18, vr18, vr20, vr21, vr22, vr23
    vmaddwev.h.bu.b vr14, vr12, vr18
    vmaddwod.h.bu.b vr15, vr12, vr18
    VMADDW4_H vr3, vr4, vr19, vr19, vr20, vr21, vr22, vr23
    vmaddwev.h.bu.b vr14, vr13, vr19
    vmaddwod.h.bu.b vr15, vr13, vr19

    vor.v            vr10, vr12, vr12
    vor.v            vr11, vr13, vr13
    vor.v            vr0,  vr2,  vr2
    vor.v            vr1,  vr3,  vr3
    vor.v            vr2,  vr4,  vr4
    vor.v            vr7,  vr9,  vr9

    vilvl.h          vr5,  vr21, vr20
    vilvh.h          vr6,  vr21, vr20
    vilvl.h          vr8,  vr23, vr22
    vilvh.h          vr9,  vr23, vr22

    vst              vr5,  a2,   0
    vst              vr6,  a2,   16
    vst              vr14, a2,   32
    add.d            a2,   a2,   a3
    add.d            a0,   a0,   t1
    vst              vr8,  a2,   0
    vst              vr9,  a2,   16
    vst              vr15, a2,   32
    addi.d           t0,   t0,   -1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_ps_4tap_24x\h
    fld.d            f24,  sp,   0
    addi.d           sp,   sp,   8
endfunc
.endm

VERT_4TAP_PS_24xN 32
VERT_4TAP_PS_24xN 64

.macro VERT_4TAP_PS_32xN  h
function x265_interp_4tap_vert_ps_32x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       a3,    a3,    1
    addi.d       sp,    sp,    -8
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/2
    sub.d        a0,    a0,    a1
    fst.d        f24,   sp,    0

    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vld          vr24,  t4,    0

    addi.d       t6,    a0,    16
    vld          vr0,   a0,    0    //0
    vldx         vr1,   a0,    a1   //1
    vldx         vr2,   a0,    t1   //2

    add.d        a0,    a0,    t2
    vld          vr5,   t6,    0
    vldx         vr6,   t6,    a1
    vldx         vr7,   t6,    t1

.loopV_ps_4tap_32x\h:
    addi.d       t6,    a0,    16
    vld          vr3,   a0,    0
    vldx         vr4,   a0,    a1  //7
    vld          vr8,   t6,    0
    vldx         vr9,   t6,    a1

.irp x, vr10, vr11, vr12, vr13, vr20, vr21, vr22, vr23
    vor.v        \x,    vr24,  vr24
.endr
    VMADDW4_H vr0, vr1, vr16, vr16, vr10, vr11, vr12, vr13
    VMADDW4_H vr5, vr6, vr16, vr16, vr20, vr21, vr22, vr23
    VMADDW4_H vr1, vr2, vr17, vr17, vr10, vr11, vr12, vr13
    VMADDW4_H vr6, vr7, vr17, vr17, vr20, vr21, vr22, vr23
    VMADDW4_H vr2, vr3, vr18, vr18, vr10, vr11, vr12, vr13
    VMADDW4_H vr7, vr8, vr18, vr18, vr20, vr21, vr22, vr23
    VMADDW4_H vr3, vr4, vr19, vr19, vr10, vr11, vr12, vr13
    VMADDW4_H vr8, vr9, vr19, vr19, vr20, vr21, vr22, vr23

    vor.v            vr0,  vr2,  vr2
    vor.v            vr1,  vr3,  vr3
    vor.v            vr2,  vr4,  vr4
    vor.v            vr5,  vr7,  vr7
    vor.v            vr6,  vr8,  vr8
    vor.v            vr7,  vr9,  vr9

    vilvl.h          vr3,  vr11, vr10
    vilvh.h          vr4,  vr11, vr10
    vilvl.h          vr8,  vr13, vr12
    vilvh.h          vr9,  vr13, vr12

    vilvl.h          vr10, vr21, vr20
    vilvh.h          vr11, vr21, vr20
    vilvl.h          vr12, vr23, vr22
    vilvh.h          vr13, vr23, vr22

    vst              vr3,  a2,   0
    vst              vr4,  a2,   16
    vst              vr10, a2,   32
    vst              vr11, a2,   48
    add.d            a2,   a2,   a3
    add.d            a0,   a0,   t1
    addi.d           t0,   t0,   -1
    vst              vr8,  a2,   0
    vst              vr9,  a2,   16
    vst              vr12, a2,   32
    vst              vr13, a2,   48
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_ps_4tap_32x\h
    fld.d            f24,  sp,   0
    addi.d           sp,   sp,   8
endfunc
.endm

VERT_4TAP_PS_32xN 8
VERT_4TAP_PS_32xN 16
VERT_4TAP_PS_32xN 24
VERT_4TAP_PS_32xN 32
VERT_4TAP_PS_32xN 48
VERT_4TAP_PS_32xN 64

function x265_interp_4tap_vert_ps_48x64_lsx
    slli.d       t7,    a4,    5
    slli.d       a3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  64
    sub.d        a0,    a0,    a1

    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vld          vr23,  t4,    0

    add.d        t6,    a0,    a1
    vld          vr0,   a0,    0    //0
    vld          vr1,   a0,    16   //0
    vld          vr2,   a0,    32   //0

    add.d        a0,    t6,    a1
    vld          vr3,   t6,    0   //1
    vld          vr4,   t6,    16  //1
    vld          vr5,   t6,    32  //1

    add.d        t6,    a0,    a1
    vld          vr6,   a0,    0    //2
    vld          vr7,   a0,    16   //2
    vld          vr8,   a0,    32   //2
.loopV_ps_4tap_48x64:
    vld          vr9,   t6,    0
    vld          vr10,  t6,    16
    vld          vr11,  t6,    32

.irp x, vr12, vr13, vr14, vr15, vr20, vr21
    vor.v        \x,    vr23,  vr23
.endr
    VMADDW4_H vr0, vr1, vr16, vr16, vr12, vr13, vr14, vr15
    vmaddwev.h.bu.b  vr20, vr2,  vr16
    vmaddwod.h.bu.b  vr21, vr2,  vr16
    VMADDW4_H vr3, vr4, vr17, vr17, vr12, vr13, vr14, vr15
    vmaddwev.h.bu.b vr20, vr5,  vr17
    vmaddwod.h.bu.b vr21, vr5,  vr17
    VMADDW4_H vr6, vr7, vr18, vr18, vr12, vr13, vr14, vr15
    vmaddwev.h.bu.b vr20, vr8,  vr18
    vmaddwod.h.bu.b vr21, vr8,  vr18
    VMADDW4_H vr9, vr10, vr19, vr19, vr12, vr13, vr14, vr15
    vmaddwev.h.bu.b vr20, vr11, vr19
    vmaddwod.h.bu.b vr21, vr11, vr19

    vor.v            vr0,  vr3,  vr3
    vor.v            vr1,  vr4,  vr4
    vor.v            vr2,  vr5,  vr5
    vor.v            vr3,  vr6,  vr6
    vor.v            vr4,  vr7,  vr7
    vor.v            vr5,  vr8,  vr8
    vor.v            vr6,  vr9,  vr9
    vor.v            vr7,  vr10, vr10
    vor.v            vr8,  vr11, vr11

    vilvl.h          vr9,  vr13, vr12
    vilvh.h          vr10, vr13, vr12
    vilvl.h          vr11, vr15, vr14
    vilvh.h          vr22, vr15, vr14
    vilvl.h          vr12, vr21, vr20
    vilvh.h          vr13, vr21, vr20
    vst              vr9,  a2,   0
    vst              vr10, a2,   16
    vst              vr11, a2,   32
    vst              vr22, a2,   48
    vst              vr12, a2,   64
    vst              vr13, a2,   80
    addi.d           t0,   t0,   -1
    add.d            t6,   t6,   a1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_ps_4tap_48x64
endfunc

.macro VERT_4TAP_PS_64xN  h
function x265_interp_4tap_vert_ps_64x\h\()_lsx
    slli.d       t7,    a4,    5
    slli.d       a3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h
    sub.d        a0,    a0,    a1
    addi.d       sp,    sp,    -40
    fst.d        f24,   sp,    0
    fst.d        f25,   sp,    8
    fst.d        f26,   sp,    16
    fst.d        f27,   sp,    24
    fst.d        f28,   sp,    32

    vldrepl.b    vr16,  t5,    0
    vldrepl.b    vr17,  t5,    2
    vldrepl.b    vr18,  t5,    4
    vldrepl.b    vr19,  t5,    6
    vld          vr28,  t4,    0

    add.d        t6,    a0,    a1
    vld          vr0,   a0,    0    //0
    vld          vr1,   a0,    16
    vld          vr2,   a0,    32
    vld          vr3,   a0,    48

    add.d        a0,    t6,    a1
    vld          vr4,   t6,    0    //1
    vld          vr5,   t6,    16
    vld          vr6,   t6,    32
    vld          vr7,   t6,    48

    add.d        t6,    a0,    a1
    vld          vr8,   a0,    0    //2
    vld          vr9,   a0,    16
    vld          vr10,  a0,    32
    vld          vr11,  a0,    48
.loopV_ps_4tap_64x\h:
    vld          vr12,  t6,    0    //3
    vld          vr13,  t6,    16
    vld          vr14,  t6,    32
    vld          vr15,  t6,    48

.irp x, vr20, vr21, vr22, vr23, vr24, vr25, vr26, vr27
    vor.v        \x,    vr28,  vr28
.endr
    VMADDW4_H vr0, vr1, vr16, vr16, vr20, vr21, vr22, vr23
    VMADDW4_H vr2, vr3, vr16, vr16, vr24, vr25, vr26, vr27
    VMADDW4_H vr4, vr5, vr17, vr17, vr20, vr21, vr22, vr23
    VMADDW4_H vr6, vr7, vr17, vr17, vr24, vr25, vr26, vr27
    VMADDW4_H vr8, vr9, vr18, vr18, vr20, vr21, vr22, vr23
    VMADDW4_H vr10, vr11, vr18, vr18, vr24, vr25, vr26, vr27
    VMADDW4_H vr12, vr13, vr19, vr19, vr20, vr21, vr22, vr23
    VMADDW4_H vr14, vr15, vr19, vr19, vr24, vr25, vr26, vr27

    vor.v            vr0,  vr4,  vr4
    vor.v            vr1,  vr5,  vr5
    vor.v            vr2,  vr6,  vr6
    vor.v            vr3,  vr7,  vr7
    vor.v            vr4,  vr8,  vr8
    vor.v            vr5,  vr9,  vr9
    vor.v            vr6,  vr10, vr10
    vor.v            vr7,  vr11, vr11
    vor.v            vr8,  vr12, vr12
    vor.v            vr9,  vr13, vr13
    vor.v            vr10, vr14, vr14
    vor.v            vr11, vr15, vr15

    vilvl.h          vr12, vr21, vr20
    vilvh.h          vr13, vr21, vr20
    vilvl.h          vr14, vr23, vr22
    vilvh.h          vr15, vr23, vr22
    vilvl.h          vr20, vr25, vr24
    vilvh.h          vr21, vr25, vr24
    vilvl.h          vr22, vr27, vr26
    vilvh.h          vr23, vr27, vr26

    vst              vr12, a2,   0
    vst              vr13, a2,   16
    vst              vr14, a2,   32
    vst              vr15, a2,   48
    vst              vr20, a2,   64
    vst              vr21, a2,   80
    vst              vr22, a2,   96
    vst              vr23, a2,   112
    addi.d           t0,   t0,   -1
    add.d            t6,   t6,   a1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_ps_4tap_64x\h
    fld.d        f24,   sp,    0
    fld.d        f25,   sp,    8
    fld.d        f26,   sp,    16
    fld.d        f27,   sp,    24
    fld.d        f28,   sp,    32
    addi.d       sp,    sp,    40
endfunc
.endm

VERT_4TAP_PS_64xN 16
VERT_4TAP_PS_64xN 32
VERT_4TAP_PS_64xN 48
VERT_4TAP_PS_64xN 64

.macro LASX_VERT_4TAP_PS_16xN  h
function x265_interp_4tap_vert_ps_16x\h\()_lasx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       a3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/2
    sub.d        a0,    a0,    a1
    slli.d       t7,    a3,    1

    xvldrepl.b   xr16,  t5,    0
    xvldrepl.b   xr17,  t5,    2
    xvldrepl.b   xr18,  t5,    4
    xvldrepl.b   xr19,  t5,    6
    xvld         xr20,  t4,    0

    add.d        t6,    a0,    t2
    vld          vr0,   a0,    0    //0
    vldx         vr1,   a0,    a1   //1
    vldx         vr2,   a0,    t1   //2

    xvpermi.q    xr0,   xr1,   0x2
    xvpermi.q    xr1,   xr2,   0x2
.lasx_loopV_ps_4tap_16x\h:
    xvld         xr3,   t6,    0   //3
    xvldx        xr4,   t6,    a1  //4
    xvor.v       xr10,  xr20,  xr20
    xvor.v       xr11,  xr20,  xr20
    xvpermi.q    xr2,   xr3,   0x2
    xvpermi.q    xr3,   xr4,   0x2
    XMADDW4_H xr0, xr1, xr16, xr16, xr10, xr11, xr12, xr13
    XMADDW4_H xr1, xr2, xr17, xr17, xr10, xr11, xr12, xr13
    XMADDW4_H xr2, xr3, xr18, xr18, xr10, xr11, xr12, xr13
    XMADDW4_H xr3, xr4, xr19, xr19, xr10, xr11, xr12, xr13

    xvor.v           xr0,  xr2,  xr2
    xvor.v           xr1,  xr3,  xr3
    xvor.v           xr2,  xr4,  xr4

    xvilvl.h         xr12, xr11, xr10
    xvilvh.h         xr13, xr11, xr10
    xvor.v           xr9,  xr12, xr12
    xvpermi.q        xr12, xr13, 0x02
    xvpermi.q        xr9,  xr13, 0x13
    add.d            t6,   t6,   t1
    xvst             xr12, a2,   0
    xvstx            xr9,  a2,   a3
    addi.d           t0,   t0,   -1
    add.d            a2,   a2,   t7
    blt              zero, t0,   .lasx_loopV_ps_4tap_16x\h
endfunc
.endm

LASX_VERT_4TAP_PS_16xN 4
LASX_VERT_4TAP_PS_16xN 8
LASX_VERT_4TAP_PS_16xN 12
LASX_VERT_4TAP_PS_16xN 16
LASX_VERT_4TAP_PS_16xN 24
LASX_VERT_4TAP_PS_16xN 32
LASX_VERT_4TAP_PS_16xN 64

.macro LASX_VERT_4TAP_PS_24xN  h
function x265_interp_4tap_vert_ps_24x\h\()_lasx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       a3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/2
    sub.d        a0,    a0,    a1

    xvldrepl.b   xr16,  t5,    0
    xvldrepl.b   xr17,  t5,    2
    xvldrepl.b   xr18,  t5,    4
    xvldrepl.b   xr19,  t5,    6
    xvld         xr20,  t4,    0

    add.d        t6,    a0,    t2
    xvld         xr0,   a0,    0    //0
    xvldx        xr1,   a0,    a1   //1
    xvldx        xr2,   a0,    t1   //2

.lasx_loopV_ps_4tap_24x\h:
    xvld         xr3,   t6,    0   //3
    xvldx        xr4,   t6,    a1  //4

.irp x, xr10, xr11, xr12, xr13
    xvor.v       \x,    xr20,  xr20
.endr
    XMADDW4_H xr0, xr1, xr16, xr16, xr10, xr11, xr12, xr13
    XMADDW4_H xr1, xr2, xr17, xr17, xr10, xr11, xr12, xr13
    XMADDW4_H xr2, xr3, xr18, xr18, xr10, xr11, xr12, xr13
    XMADDW4_H xr3, xr4, xr19, xr19, xr10, xr11, xr12, xr13

    xvor.v           xr0,  xr2,  xr2
    xvor.v           xr1,  xr3,  xr3
    xvor.v           xr2,  xr4,  xr4

    xvpermi.d        xr10, xr10, 0xD8
    xvpermi.d        xr11, xr11, 0xD8
    xvpermi.d        xr12, xr12, 0xD8
    xvpermi.d        xr13, xr13, 0xD8
    xvilvl.h         xr9,  xr11, xr10
    xvilvh.h         xr14, xr11, xr10
    xvilvl.h         xr7,  xr13, xr12
    xvilvh.h         xr8,  xr13, xr12

    xvst             xr9,  a2,   0
    vst              vr14, a2,   32
    add.d            a2,   a2,   a3
    add.d            t6,   t6,   t1
    addi.d           t0,   t0,   -1
    xvst             xr7,  a2,   0
    vst              vr8,  a2,   32
    add.d            a2,   a2,   a3
    blt              zero, t0,   .lasx_loopV_ps_4tap_24x\h
endfunc
.endm

LASX_VERT_4TAP_PS_24xN 32
LASX_VERT_4TAP_PS_24xN 64

function x265_interp_4tap_vert_ps_48x64_lasx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       a3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  32
    sub.d        a0,    a0,    a1

    xvldrepl.b   xr16,  t5,    0
    xvldrepl.b   xr17,  t5,    2
    xvldrepl.b   xr18,  t5,    4
    xvldrepl.b   xr19,  t5,    6
    xvld         xr20,  t4,    0

    addi.d       t6,    a0,    32
    xvld         xr0,   a0,    0    //0
    xvldx        xr1,   a0,    a1   //1
    xvldx        xr2,   a0,    t1   //2
    add.d        a0,    a0,    t2
    vld          vr5,   t6,    0
    vldx         vr6,   t6,    a1
    vldx         vr7,   t6,    t1
    xvpermi.q    xr5,   xr6,   0x2
    xvpermi.q    xr6,   xr7,   0x2
.lasx_loopV_ps_4tap_48x64:
    addi.d       t6,    a0,    32
    xvld         xr3,   a0,    0   //3
    xvldx        xr4,   a0,    a1  //4
    vld          vr8,   t6,    0
    vldx         vr9,   t6,    a1

.irp x, xr10, xr11, xr12, xr13, xr14, xr15
    xvor.v       \x,    xr20,  xr20
.endr
    xvpermi.q    xr7,   xr8,   0x2
    xvpermi.q    xr8,   xr9,   0x2

    XMADDW4_H xr0,  xr1,  xr16, xr16, xr10, xr11, xr12, xr13
    XMADDW4_H xr5,  xr1,  xr16, xr17, xr14, xr15, xr10, xr11
    XMADDW4_H xr2,  xr6,  xr17, xr17, xr12, xr13, xr14, xr15
    XMADDW4_H xr2,  xr3,  xr18, xr18, xr10, xr11, xr12, xr13
    XMADDW4_H xr7,  xr3,  xr18, xr19, xr14, xr15, xr10, xr11
    XMADDW4_H xr4,  xr8,  xr19, xr19, xr12, xr13, xr14, xr15
    xvor.v           xr0,  xr2,  xr2
    xvor.v           xr1,  xr3,  xr3
    xvor.v           xr2,  xr4,  xr4
    xvor.v           xr5,  xr7,  xr7
    xvor.v           xr6,  xr8,  xr8
    xvor.v           xr7,  xr9,  xr9
    xvpermi.d        xr10, xr10, 0xD8
    xvpermi.d        xr11, xr11, 0xD8
    xvpermi.d        xr12, xr12, 0xD8
    xvpermi.d        xr13, xr13, 0xD8

    xvilvl.h         xr3,  xr11, xr10
    xvilvh.h         xr4,  xr11, xr10
    xvilvl.h         xr8,  xr13, xr12
    xvilvh.h         xr9,  xr13, xr12
    xvilvl.h         xr21, xr15, xr14
    xvilvh.h         xr22, xr15, xr14
    xvor.v           xr23, xr21, xr21
    xvpermi.q        xr21, xr22, 0x2
    xvpermi.q        xr23, xr22, 0x13

    xvst             xr3,  a2,   0
    xvst             xr4,  a2,   32
    xvst             xr21, a2,   64
    add.d            a2,   a2,   a3
    add.d            a0,   a0,   t1
    xvst             xr8,  a2,   0
    xvst             xr9,  a2,   32
    xvst             xr23, a2,   64
    addi.d           t0,   t0,   -1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .lasx_loopV_ps_4tap_48x64
endfunc

.macro LASX_VERT_4TAP_PS_32xN  h
function x265_interp_4tap_vert_ps_32x\h\()_lasx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       a3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/2
    sub.d        a0,    a0,    a1

    xvldrepl.b   xr16,  t5,    0
    xvldrepl.b   xr17,  t5,    2
    xvldrepl.b   xr18,  t5,    4
    xvldrepl.b   xr19,  t5,    6
    xvld         xr20,  t4,    0

    add.d        t6,    a0,    t2
    xvld         xr0,   a0,    0    //0
    xvldx        xr1,   a0,    a1   //1
    xvldx        xr2,   a0,    t1   //2

.lasx_loopV_ps_4tap_32x\h:
    xvld         xr3,   t6,    0   //3
    xvldx        xr4,   t6,    a1  //4

.irp x, xr10, xr11, xr12, xr13
    xvor.v       \x,    xr20,  xr20
.endr
    XMADDW4_H xr0, xr1, xr16, xr16, xr10, xr11, xr12, xr13
    XMADDW4_H xr1, xr2, xr17, xr17, xr10, xr11, xr12, xr13
    XMADDW4_H xr2, xr3, xr18, xr18, xr10, xr11, xr12, xr13
    XMADDW4_H xr3, xr4, xr19, xr19, xr10, xr11, xr12, xr13

    xvor.v           xr0,  xr2,  xr2
    xvor.v           xr1,  xr3,  xr3
    xvor.v           xr2,  xr4,  xr4

    xvilvl.h         xr5,  xr11, xr10
    xvilvh.h         xr6,  xr11, xr10
    xvilvl.h         xr7,  xr13, xr12
    xvilvh.h         xr8,  xr13, xr12

    xvor.v           xr14, xr6,  xr6
    xvor.v           xr15, xr8,  xr8

    xvpermi.q        xr6,  xr5,  0x20
    xvpermi.q        xr14, xr5,  0x31
    xvpermi.q        xr8,  xr7,  0x20
    xvpermi.q        xr15, xr7,  0x31
    xvst             xr6,  a2,   0
    xvst             xr14, a2,   32
    add.d            a2,   a2,   a3
    add.d            t6,   t6,   t1
    xvst             xr8,  a2,   0
    xvst             xr15, a2,   32
    addi.d           t0,   t0,   -1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .lasx_loopV_ps_4tap_32x\h
endfunc
.endm

LASX_VERT_4TAP_PS_32xN 8
LASX_VERT_4TAP_PS_32xN 16
LASX_VERT_4TAP_PS_32xN 24
LASX_VERT_4TAP_PS_32xN 32
LASX_VERT_4TAP_PS_32xN 48
LASX_VERT_4TAP_PS_32xN 64

.macro LASX_VERT_4TAP_PS_64xN  h
function x265_interp_4tap_vert_ps_64x\h\()_lasx
    slli.d       t7,    a4,    5
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       a3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/2
    sub.d        a0,    a0,    a1

    xvld         xr15,  t4,    0
    xvldrepl.b   xr16,  t5,    0
    xvldrepl.b   xr17,  t5,    2
    xvldrepl.b   xr18,  t5,    4
    xvldrepl.b   xr19,  t5,    6

    addi.d       t6,    a0,    32
    xvld         xr0,   a0,    0    //0
    xvldx        xr1,   a0,    a1   //1
    xvldx        xr2,   a0,    t1   //2

    add.d        a0,    a0,    t2
    xvld         xr5,   t6,    0
    xvldx        xr6,   t6,    a1
    xvldx        xr7,   t6,    t1

.lasx_loopV_ps_4tap_64x\h:
    addi.d       t6,    a0,    32
    xvld         xr3,   a0,    0
    xvldx        xr4,   a0,    a1  //7
    xvld         xr8,   t6,    0
    xvldx        xr9,   t6,    a1

.irp x, xr10, xr11, xr12, xr13, xr20, xr21, xr22, xr23
    xvor.v       \x,    xr15,  xr15
.endr
    XMADDW4_H xr0, xr1, xr16, xr16, xr10, xr11, xr12, xr13
    XMADDW4_H xr5, xr6, xr16, xr16, xr20, xr21, xr22, xr23
    XMADDW4_H xr1, xr2, xr17, xr17, xr10, xr11, xr12, xr13
    XMADDW4_H xr6, xr7, xr17, xr17, xr20, xr21, xr22, xr23
    XMADDW4_H xr2, xr3, xr18, xr18, xr10, xr11, xr12, xr13
    XMADDW4_H xr7, xr8, xr18, xr18, xr20, xr21, xr22, xr23
    XMADDW4_H xr3, xr4, xr19, xr19, xr10, xr11, xr12, xr13
    XMADDW4_H xr8, xr9, xr19, xr19, xr20, xr21, xr22, xr23

    xvor.v           xr0,  xr2,  xr2
    xvor.v           xr1,  xr3,  xr3
    xvor.v           xr2,  xr4,  xr4
    xvor.v           xr5,  xr7,  xr7
    xvor.v           xr6,  xr8,  xr8
    xvor.v           xr7,  xr9,  xr9

    xvilvl.h         xr3,  xr11, xr10
    xvilvh.h         xr4,  xr11, xr10
    xvilvl.h         xr8,  xr13, xr12
    xvilvh.h         xr9,  xr13, xr12
    xvilvl.h         xr10, xr21, xr20
    xvilvh.h         xr11, xr21, xr20
    xvilvl.h         xr12, xr23, xr22
    xvilvh.h         xr13, xr23, xr22

    xvor.v           xr20, xr4,  xr4
    xvor.v           xr21, xr9,  xr9
    xvor.v           xr22, xr11, xr11
    xvor.v           xr23, xr13, xr13

    xvpermi.q        xr4,  xr3,  0x20
    xvpermi.q        xr20, xr3,  0x31
    xvpermi.q        xr9,  xr8,  0x20
    xvpermi.q        xr21, xr8,  0x31
    xvpermi.q        xr11, xr10, 0x20
    xvpermi.q        xr22, xr10, 0x31
    xvpermi.q        xr13, xr12, 0x20
    xvpermi.q        xr23, xr12, 0x31

    xvst             xr4,  a2,   0
    xvst             xr20, a2,   32
    xvst             xr11, a2,   64
    xvst             xr22, a2,   96
    add.d            a0,   a0,   t1
    add.d            a2,   a2,   a3
    addi.d           t0,   t0,   -1
    xvst             xr9,  a2,   0
    xvst             xr21, a2,   32
    xvst             xr13, a2,   64
    xvst             xr23, a2,   96
    add.d            a2,   a2,   a3
    blt              zero, t0,   .lasx_loopV_ps_4tap_64x\h
endfunc
.endm

LASX_VERT_4TAP_PS_64xN 16
LASX_VERT_4TAP_PS_64xN 32
LASX_VERT_4TAP_PS_64xN 48
LASX_VERT_4TAP_PS_64xN 64

.macro FILTER_VERT_4TAP_SP_2xN  h
function x265_interp_4tap_vert_sp_2x\h\()_lsx
    slli.d       a1,    a1,    1
    slli.d       t7,    a4,    3
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/4
    sub.d        t6,    a0,    a1
    vldrepl.h    vr16,  t5,    0 + 256
    vldrepl.h    vr17,  t5,    2 + 256
    vldrepl.h    vr18,  t5,    4 + 256
    vldrepl.h    vr19,  t5,    6 + 256
    vld          vr15,  t4,    32

    add.d        a0,    t6,    t2
    fld.s        f8,    t6,    0    //0
    fldx.s       f9,    t6,    a1   //1
    fldx.s       f10,   t6,    t1   //2

    vilvl.h      vr0,   vr9,   vr8  //0,1
    vilvl.h      vr1,   vr10,  vr9  //1,2

.loopV_4tap_sp_2x\h:
    fld.d        f11,   a0,    0    //3
    fldx.d       f12,   a0,    a1   //4
    fldx.d       f13,   a0,    t1   //5
    fldx.d       f14,   a0,    t2   //6
    vilvl.h      vr2,   vr11,  vr10 //2,3
    vilvl.h      vr3,   vr12,  vr11 //3,4
    vilvl.h      vr4,   vr13,  vr12 //4,5
    vilvl.h      vr5,   vr14,  vr13 //5,6

    vilvl.d      vr6,   vr2,   vr0  //0,1,2,3
    vilvl.d      vr7,   vr3,   vr1  //1,2,3,4
    vilvl.d      vr8,   vr4,   vr2  //2,3,4,5
    vilvl.d      vr9,   vr5,   vr3  //3,4,5,6
    vor.v        vr20,  vr15,  vr15
    vor.v        vr21,  vr15,  vr15
    VMADD4_W vr6, vr7, vr16, vr17, vr20, vr21, vr20, vr21
    VMADD4_W vr8, vr9, vr18, vr19, vr20, vr21, vr20, vr21
    vor.v            vr0,  vr4,  vr4
    vor.v            vr1,  vr5,  vr5

    vssrani.h.w      vr21, vr20, 12
    vor.v            vr10, vr14, vr14
    vssrani.bu.h     vr9,  vr21, 0
    vstelm.h         vr9,  a2,   0,  0
    add.d            a2,   a2,   a3
    vstelm.h         vr9,  a2,   0,  2
    add.d            a2,   a2,   a3
    vstelm.h         vr9,  a2,   0,  1
    add.d            a2,   a2,   a3
    vstelm.h         vr9,  a2,   0,  3
    add.d            a0,   a0,   t3
    add.d            a2,   a2,   a3
    addi.d           t0,   t0,   -1
    blt              zero, t0,   .loopV_4tap_sp_2x\h
endfunc
.endm

FILTER_VERT_4TAP_SP_2xN  4
FILTER_VERT_4TAP_SP_2xN  8
FILTER_VERT_4TAP_SP_2xN  16

function x265_interp_4tap_vert_sp_4x2_lsx
    slli.d       a1,    a1,    1
    slli.d       t7,    a4,    3
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    sub.d        t6,    a0,    a1
    vldrepl.h    vr16,  t5,    0 + 256
    vldrepl.h    vr17,  t5,    2 + 256
    vldrepl.h    vr18,  t5,    4 + 256
    vldrepl.h    vr19,  t5,    6 + 256
    vld          vr20,  t4,    32

    fld.d        f8,    t6,    0    //0
    fldx.d       f9,    t6,    a1   //1
    fldx.d       f10,   t6,    t1   //2
    fldx.d       f11,   t6,    t2   //3
    fldx.d       f12,   t6,    t3   //4

    vilvl.h      vr0,   vr9,   vr8  //0,1
    vilvl.h      vr1,   vr10,  vr9  //1,2
    vilvl.h      vr2,   vr11,  vr10 //2,3
    vilvl.h      vr3,   vr12,  vr11 //3,4
    vor.v        vr6,   vr20,  vr20
    vor.v        vr7,   vr20,  vr20
    VMADD4_W vr0, vr1, vr16, vr17, vr6, vr7, vr6, vr7
    VMADD4_W vr2, vr3, vr18, vr19, vr6, vr7, vr6, vr7

    vssrani.h.w      vr7,  vr6,  12
    vssrani.bu.h     vr9,  vr7,  0
    vstelm.w         vr9,  a2,   0,  0
    add.d            a2,   a2,   a3
    vstelm.w         vr9,  a2,   0,  1
endfunc

.macro FILTER_VERT_4TAP_SP_4xN  h
function x265_interp_4tap_vert_sp_4x\h\()_lsx
    slli.d       a1,    a1,    1
    slli.d       t7,    a4,    3
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/4
    sub.d        t6,    a0,    a1
    vldrepl.h    vr16,  t5,    0 + 256
    vldrepl.h    vr17,  t5,    2 + 256
    vldrepl.h    vr18,  t5,    4 + 256
    vldrepl.h    vr19,  t5,    6 + 256
    vld          vr20,  t4,    32

    add.d        a0,    t6,    t2
    fld.d        f8,    t6,    0    //0
    fldx.d       f9,    t6,    a1   //1
    fldx.d       f10,   t6,    t1   //2

    vilvl.h      vr0,   vr9,   vr8  //0,1
    vilvl.h      vr1,   vr10,  vr9  //1,2
.loopV_4tap_sp_4x\h:
    fld.d        f11,   a0,    0    //3
    fldx.d       f12,   a0,    a1   //4
    fldx.d       f13,   a0,    t1   //5
    fldx.d       f14,   a0,    t2   //6
    vilvl.h      vr2,   vr11,  vr10 //2,3
    vilvl.h      vr3,   vr12,  vr11 //3,4
    vilvl.h      vr4,   vr13,  vr12 //4,5
    vilvl.h      vr5,   vr14,  vr13 //5,6
.irp x, vr6, vr7, vr8, vr9
    vor.v        \x,    vr20,  vr20
.endr
    VMADD4_W vr0, vr2, vr16, vr16, vr6, vr7, vr8, vr9
    VMADD4_W vr1, vr3, vr17, vr17, vr6, vr7, vr8, vr9
    VMADD4_W vr2, vr4, vr18, vr18, vr6, vr7, vr8, vr9
    VMADD4_W vr3, vr5, vr19, vr19, vr6, vr7, vr8, vr9
    vor.v            vr0,  vr4,  vr4
    vor.v            vr1,  vr5,  vr5

    vssrani.h.w      vr7,  vr6,  12
    vssrani.h.w      vr9,  vr8,  12
    vor.v            vr10, vr14, vr14
    vssrani.bu.h     vr9,  vr7,  0
    vstelm.w         vr9,  a2,   0,  0
    add.d            a2,   a2,   a3
    vstelm.w         vr9,  a2,   0,  1
    add.d            a2,   a2,   a3
    vstelm.w         vr9,  a2,   0,  2
    add.d            a2,   a2,   a3
    vstelm.w         vr9,  a2,   0,  3
    add.d            a0,   a0,   t3
    add.d            a2,   a2,   a3
    addi.d           t0,   t0,   -1
    blt              zero, t0,   .loopV_4tap_sp_4x\h
endfunc
.endm

FILTER_VERT_4TAP_SP_4xN 4
FILTER_VERT_4TAP_SP_4xN 8
FILTER_VERT_4TAP_SP_4xN 16
FILTER_VERT_4TAP_SP_4xN 32

.macro FILTER_VERT_4TAP_SP_6xN  h
function x265_interp_4tap_vert_sp_6x\h\()_lsx
    slli.d       a1,    a1,    1
    slli.d       t7,    a4,    3
    slli.d       t1,    a1,    1   //srcStride * 2
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/2
    sub.d        t6,    a0,    a1
    vldrepl.h    vr16,  t5,    0 + 256
    vldrepl.h    vr17,  t5,    2 + 256
    vldrepl.h    vr18,  t5,    4 + 256
    vldrepl.h    vr19,  t5,    6 + 256
    vld          vr15,  t4,    32

    add.d        a0,    t6,    t2
    vld          vr0,   t6,    0    //0
    vldx         vr1,   t6,    a1   //1
    vldx         vr2,   t6,    t1   //2

.loopV_4tap_sp_6x\h:
    vld          vr3,   a0,    0   //3
    vldx         vr4,   a0,    a1  //4
.irp x, vr10, vr11, vr12, vr13
    vor.v        \x,    vr15,  vr15
.endr
    VMADD4_W vr0, vr1, vr16, vr16, vr10, vr11, vr12, vr13
    VMADD4_W vr1, vr2, vr17, vr17, vr10, vr11, vr12, vr13
    VMADD4_W vr2, vr3, vr18, vr18, vr10, vr11, vr12, vr13
    VMADD4_W vr3, vr4, vr19, vr19, vr10, vr11, vr12, vr13

    vor.v            vr0,  vr2,  vr2
    vor.v            vr1,  vr3,  vr3
    vssrani.h.w      vr12, vr10, 12
    vssrani.h.w      vr13, vr11, 12
    vssrani.bu.h     vr13, vr12, 0
    vor.v            vr2,  vr4,  vr4
    vbsrl.v          vr10, vr13, 8
    vilvl.b          vr11, vr10, vr13

    vstelm.w         vr11, a2,   0,  0
    vstelm.h         vr11, a2,   4,  2
    add.d            a2,   a2,   a3
    vstelm.w         vr11, a2,   0,  2
    vstelm.h         vr11, a2,   4,  6
    add.d            a0,   a0,   t1
    addi.d           t0,   t0,   -1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_4tap_sp_6x\h
endfunc
.endm

FILTER_VERT_4TAP_SP_6xN 8
FILTER_VERT_4TAP_SP_6xN 16

.macro FILTER_VERT_4TAP_SP_8xN  h
function x265_interp_4tap_vert_sp_8x\h\()_lsx
    slli.d       a1,    a1,    1
    slli.d       t7,    a4,    3
    slli.d       t1,    a1,    1   //srcStride * 2
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/2
    sub.d        t6,    a0,    a1
    vldrepl.h    vr16,  t5,    0 + 256
    vldrepl.h    vr17,  t5,    2 + 256
    vldrepl.h    vr18,  t5,    4 + 256
    vldrepl.h    vr19,  t5,    6 + 256
    vld          vr15,  t4,    32

    add.d        a0,    t6,    t2
    vld          vr0,   t6,    0    //0
    vldx         vr1,   t6,    a1   //1
    vldx         vr2,   t6,    t1   //2

.loopV_4tap_sp_8x\h:
    vld          vr3,   a0,    0   //3
    vldx         vr4,   a0,    a1  //4
.irp x, vr10, vr11, vr12, vr13
    vor.v        \x,    vr15,  vr15
.endr
    VMADD4_W vr0, vr1, vr16, vr16, vr10, vr11, vr12, vr13
    VMADD4_W vr1, vr2, vr17, vr17, vr10, vr11, vr12, vr13
    VMADD4_W vr2, vr3, vr18, vr18, vr10, vr11, vr12, vr13
    VMADD4_W vr3, vr4, vr19, vr19, vr10, vr11, vr12, vr13

    vor.v            vr0,  vr2,  vr2
    vor.v            vr1,  vr3,  vr3
    vssrani.h.w      vr12, vr10, 12
    vssrani.h.w      vr13, vr11, 12
    vssrani.bu.h     vr13, vr12, 0
    vor.v            vr2,  vr4,  vr4
    vbsrl.v          vr10, vr13, 8
    vilvl.b          vr11, vr10, vr13

    vstelm.d         vr11, a2,   0,  0
    add.d            a2,   a2,   a3
    vstelm.d         vr11, a2,   0,  1
    add.d            a0,   a0,   t1
    addi.d           t0,   t0,   -1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_4tap_sp_8x\h
endfunc
.endm

FILTER_VERT_4TAP_SP_8xN 2
FILTER_VERT_4TAP_SP_8xN 4
FILTER_VERT_4TAP_SP_8xN 6
FILTER_VERT_4TAP_SP_8xN 8
FILTER_VERT_4TAP_SP_8xN 12
FILTER_VERT_4TAP_SP_8xN 16
FILTER_VERT_4TAP_SP_8xN 32
FILTER_VERT_4TAP_SP_8xN 64

.macro FILTER_VERT_4TAP_SP_12xN h
function x265_interp_4tap_vert_sp_12x\h\()_lsx
    slli.d       a1,    a1,    1
    slli.d       t7,    a4,    3
    slli.d       t1,    a1,    1   //srcStride * 2
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/2
    sub.d        a0,    a0,    a1

    vldrepl.h    vr16,  t5,    0 + 256
    vldrepl.h    vr17,  t5,    2 + 256
    vldrepl.h    vr18,  t5,    4 + 256
    vldrepl.h    vr19,  t5,    6 + 256
    vld          vr20,  t4,    32

    addi.d       t6,    a0,    16
    vld          vr0,   a0,    0    //0
    vldx         vr1,   a0,    a1   //1
    vldx         vr2,   a0,    t1   //2

    add.d        a0,    a0,    t2
    fld.d        f5,    t6,    0
    fldx.d       f6,    t6,    a1
    fldx.d       f7,    t6,    t1
    vilvl.h      vr5,   vr6,   vr5  //0,1

.loopV_4tap_sp_12x\h:
    add.d        t6,    a0,    a1
    vld          vr3,   a0,    0   //3
    fld.d        f8,    a0,    16  //3
    vld          vr4,   t6,    0   //4
    fld.d        f9,    t6,    16  //4
    vilvl.h      vr6,   vr8,   vr7 //2, 3
    vilvl.h      vr21,  vr20,  vr9 //4

.irp x, vr10, vr11, vr12, vr13, vr14, vr15
    vor.v        \x,    vr20,  vr20
.endr

    VMADD4_W vr0, vr1, vr16, vr16, vr10, vr11, vr12, vr13
    vmaddwev.w.h  vr14, vr5, vr16
    vmaddwod.w.h  vr15, vr5, vr16
    VMADD4_W vr1, vr2, vr17, vr17, vr10, vr11, vr12, vr13
    vmaddwod.w.h  vr14, vr5, vr17
    vmaddwev.w.h  vr15, vr6, vr17
    VMADD4_W vr2, vr3, vr18, vr18, vr10, vr11, vr12, vr13
    vmaddwev.w.h  vr14, vr6, vr18
    vmaddwod.w.h  vr15, vr6, vr18
    VMADD4_W vr3, vr4, vr19, vr19, vr10, vr11, vr12, vr13
    vmaddwod.w.h  vr14, vr6, vr19
    vmaddwev.w.h  vr15, vr21,vr19

    vor.v         vr0,  vr2,  vr2
    vor.v         vr1,  vr3,  vr3
    vssrani.h.w   vr12, vr10, 12
    vssrani.h.w   vr13, vr11, 12
    vssrani.h.w   vr15, vr14, 12
    vor.v         vr2,  vr4,  vr4
    vor.v         vr5,  vr6,  vr6
    vilvl.h       vr10, vr13, vr12
    vilvh.h       vr11, vr13, vr12
    vor.v         vr7,  vr9,  vr9
    vssrani.bu.h  vr11, vr10, 0
    vssrani.bu.h  vr12, vr15, 0

    vstelm.d         vr11, a2,   0,  0
    vstelm.w         vr12, a2,   8,  0
    add.d            a2,   a2,   a3
    add.d            a0,   t6,   a1
    addi.d           t0,   t0,   -1
    vstelm.d         vr11, a2,   0,  1
    vstelm.w         vr12, a2,   8,  1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_4tap_sp_12x\h
endfunc
.endm

FILTER_VERT_4TAP_SP_12xN 16
FILTER_VERT_4TAP_SP_12xN 32

.macro FILTER_VERT_4TAP_SP_16xN  h
function x265_interp_4tap_vert_sp_16x\h\()_lsx
    slli.d       a1,    a1,    1
    slli.d       t7,    a4,    3
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a3,    1
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/2
    sub.d        a0,    a0,    a1

    vldrepl.h    vr16,  t5,    0 + 256
    vldrepl.h    vr17,  t5,    2 + 256
    vldrepl.h    vr18,  t5,    4 + 256
    vldrepl.h    vr19,  t5,    6 + 256
    vld          vr20,  t4,    32

    addi.d       t6,    a0,    16
    vld          vr0,   a0,    0    //0
    vldx         vr1,   a0,    a1   //1
    vldx         vr2,   a0,    t1   //2

    add.d        a0,    a0,    t2
    vld          vr5,   t6,    0
    vldx         vr6,   t6,    a1
    vldx         vr7,   t6,    t1
.loopV_4tap_sp_16x\h:
    add.d        t6,    a0,    a1
    vld          vr3,   a0,    0   //3
    vld          vr8,   a0,    16
    vld          vr4,   t6,    0   //4
    vld          vr9,   t6,    16
.irp x, vr10, vr11, vr12, vr13, vr14, vr15, vr21, vr22
    vor.v        \x,    vr20,  vr20
.endr
    VMADD4_W vr0, vr1, vr16, vr16, vr10, vr11, vr12, vr13
    VMADD4_W vr5, vr6, vr16, vr16, vr14, vr15, vr21, vr22
    VMADD4_W vr1, vr2, vr17, vr17, vr10, vr11, vr12, vr13
    VMADD4_W vr6, vr7, vr17, vr17, vr14, vr15, vr21, vr22
    VMADD4_W vr2, vr3, vr18, vr18, vr10, vr11, vr12, vr13
    VMADD4_W vr7, vr8, vr18, vr18, vr14, vr15, vr21, vr22
    VMADD4_W vr3, vr4, vr19, vr19, vr10, vr11, vr12, vr13
    VMADD4_W vr8, vr9, vr19, vr19, vr14, vr15, vr21, vr22

    vor.v            vr0,  vr2,  vr2
    vor.v            vr1,  vr3,  vr3
    vor.v            vr2,  vr4,  vr4

    vssrani.h.w      vr12, vr10, 12
    vssrani.h.w      vr13, vr11, 12
    vssrani.h.w      vr21, vr14, 12
    vssrani.h.w      vr22, vr15, 12
    vor.v            vr5,  vr7,  vr7
    vor.v            vr6,  vr8,  vr8
    vor.v            vr7,  vr9,  vr9
    vilvl.h          vr10, vr13, vr12
    vilvh.h          vr11, vr13, vr12
    vilvl.h          vr14, vr22, vr21
    vilvh.h          vr15, vr22, vr21
    vssrani.bu.h     vr14, vr10, 0
    vssrani.bu.h     vr15, vr11, 0

    vst              vr14, a2,   0
    vstx             vr15, a2,   a3
    add.d            a0,   t6,   a1
    addi.d           t0,   t0,   -1
    add.d            a2,   a2,   t3
    blt              zero, t0,   .loopV_4tap_sp_16x\h
endfunc
.endm

FILTER_VERT_4TAP_SP_16xN 4
FILTER_VERT_4TAP_SP_16xN 8
FILTER_VERT_4TAP_SP_16xN 12
FILTER_VERT_4TAP_SP_16xN 16
FILTER_VERT_4TAP_SP_16xN 24
FILTER_VERT_4TAP_SP_16xN 32
FILTER_VERT_4TAP_SP_16xN 64

.macro FILTER_VERT_4TAP_SP_24xN h
function x265_interp_4tap_vert_sp_24x\h\()_lsx
    slli.d       a1,    a1,    1
    slli.d       t7,    a4,    3
    slli.d       t1,    a1,    1   //srcStride * 2
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h
    sub.d        a0,    a0,    a1

    vldrepl.h    vr16,  t5,    0 + 256
    vldrepl.h    vr17,  t5,    2 + 256
    vldrepl.h    vr18,  t5,    4 + 256
    vldrepl.h    vr19,  t5,    6 + 256
    vld          vr20,  t4,    32

    addi.d       t6,    a0,    16
    addi.d       t7,    a0,    32
    vld          vr0,   a0,    0    //0
    vldx         vr1,   a0,    a1   //1
    vldx         vr2,   a0,    t1   //2

    add.d        a0,    a0,    t2
    vld          vr4,   t6,    0
    vldx         vr5,   t6,    a1
    vldx         vr6,   t6,    t1

    vld          vr7,   t7,    0
    vldx         vr8,   t7,    a1
    vldx         vr9,   t7,    t1
.loopV_4tap_sp_24x\h:
    vld          vr3,   a0,    0
    vld          vr21,  a0,    16
    vld          vr22,  a0,    32

.irp x, vr10, vr11, vr12, vr13, vr14, vr15
    vor.v        \x,    vr20,  vr20
.endr

    VMADD4_W vr0, vr4, vr16, vr16, vr10, vr11, vr12, vr13
    vmaddwev.w.h  vr14, vr7, vr16
    vmaddwod.w.h  vr15, vr7, vr16
    VMADD4_W vr1, vr5, vr17, vr17, vr10, vr11, vr12, vr13
    vmaddwev.w.h  vr14, vr8, vr17
    vmaddwod.w.h  vr15, vr8, vr17
    VMADD4_W vr2, vr6, vr18, vr18, vr10, vr11, vr12, vr13
    vmaddwev.w.h  vr14, vr9, vr18
    vmaddwod.w.h  vr15, vr9, vr18
    VMADD4_W vr3, vr21, vr19, vr19, vr10, vr11, vr12, vr13
    vmaddwev.w.h  vr14, vr22, vr19
    vmaddwod.w.h  vr15, vr22, vr19

    vor.v         vr0,  vr1,  vr1
    vor.v         vr1,  vr2,  vr2
    vor.v         vr2,  vr3,  vr3
    vssrani.h.w   vr12, vr10, 12
    vssrani.h.w   vr13, vr11, 12
    vssrani.h.w   vr15, vr14, 12
    vor.v         vr4,  vr5,  vr5
    vor.v         vr5,  vr6,  vr6
    vor.v         vr6,  vr21, vr21
    vilvl.h       vr10, vr13, vr12
    vilvh.h       vr11, vr13, vr12
    vssrani.bu.h  vr14, vr15, 0
    vor.v         vr7,  vr8,  vr8
    vor.v         vr8,  vr9,  vr9
    vssrani.bu.h  vr11, vr10, 0
    vbsrl.v       vr12, vr14, 4
    vor.v         vr9,  vr22, vr22
    vilvl.b       vr10, vr12, vr14

    vst              vr11, a2,   0
    vstelm.d         vr10, a2,   16,  0
    add.d            a2,   a2,   a3
    add.d            a0,   a0,   a1
    addi.d           t0,   t0,   -1
    blt              zero, t0,   .loopV_4tap_sp_24x\h
endfunc
.endm

FILTER_VERT_4TAP_SP_24xN 32
FILTER_VERT_4TAP_SP_24xN 64

function x265_interp_4tap_vert_sp_48x64_lsx
    slli.d       a1,    a1,    1
    slli.d       t7,    a4,    3
    slli.d       t1,    a1,    1
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  64
    sub.d        a0,    a0,    a1

    vldrepl.h    vr16,  t5,    0 + 256
    vldrepl.h    vr17,  t5,    2 + 256
    vldrepl.h    vr18,  t5,    4 + 256
    vldrepl.h    vr19,  t5,    6 + 256
    vld          vr7,   t4,    32

.loopV_4tap_sp_48x64:
    vld          vr0,   a0,    0
    vld          vr1,   a0,    16
    vld          vr2,   a0,    32
    vld          vr3,   a0,    48
    vld          vr4,   a0,    64
    vld          vr5,   a0,    80
    add.d        t5,    a0,    a1
.irp x, vr8, vr9, vr10, vr11, vr12, vr13, vr14, vr15, vr20, vr21, vr22, vr23
    vor.v        \x,    vr7,   vr7
.endr
    VMADD4_W vr0, vr1, vr16, vr16, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr16, vr16, vr12, vr13, vr14, vr15
    VMADD4_W vr4, vr5, vr16, vr16, vr20, vr21, vr22, vr23
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    vld          vr4,   t5,    64
    vld          vr5,   t5,    80
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr17, vr17, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr17, vr17, vr12, vr13, vr14, vr15
    VMADD4_W vr4, vr5, vr17, vr17, vr20, vr21, vr22, vr23
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    vld          vr4,   t5,    64
    vld          vr5,   t5,    80
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr18, vr18, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr18, vr18, vr12, vr13, vr14, vr15
    VMADD4_W vr4, vr5, vr18, vr18, vr20, vr21, vr22, vr23
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    vld          vr4,   t5,    64
    vld          vr5,   t5,    80
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr19, vr19, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr19, vr19, vr12, vr13, vr14, vr15
    VMADD4_W vr4, vr5, vr19, vr19, vr20, vr21, vr22, vr23

    vssrani.h.w  vr10, vr8,  12
    vssrani.h.w  vr11, vr9,  12
    vssrani.h.w  vr14, vr12, 12
    vssrani.h.w  vr15, vr13, 12
    vssrani.h.w  vr22, vr20, 12
    vssrani.h.w  vr23, vr21, 12
    vssrani.bu.h vr14, vr10, 0
    vssrani.bu.h vr15, vr11, 0
    vssrani.bu.h vr23, vr22, 0
    vilvl.b      vr4,  vr15, vr14
    vilvh.b      vr5,  vr15, vr14
    vbsrl.v      vr22, vr23, 8
    vilvl.b      vr6,  vr22, vr23
    vst          vr4,  a2,   0
    vst          vr5,  a2,   16
    vst          vr6,  a2,   32
    addi.d       t0,   t0,   -1
    add.d        a0,   a0,   a1
    add.d        a2,   a2,   a3
    blt          zero, t0,   .loopV_4tap_sp_48x64
endfunc

.macro FILTER_VERT_4TAP_SP_WxN  w, h, rep
function x265_interp_4tap_vert_sp_\w\()x\h\()_lsx
    slli.d       a1,    a1,    1
    slli.d       t7,    a4,    3
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h
    sub.d        a0,    a0,    a1

    vldrepl.h    vr16,  t5,    0 + 256
    vldrepl.h    vr17,  t5,    2 + 256
    vldrepl.h    vr18,  t5,    4 + 256
    vldrepl.h    vr19,  t5,    6 + 256
    vld          vr7,   t4,    32

.loopV_4tap_sp_\w\()x\h:
    move         t1,    a0
    move         t2,    a2
.rept \rep
    vld          vr0,   t1,    0
    vld          vr1,   t1,    16
    vld          vr2,   t1,    32
    vld          vr3,   t1,    48
    add.d        t5,    t1,    a1
.irp x, vr8, vr9, vr10, vr11, vr12, vr13, vr14, vr15
    vor.v        \x,    vr7,   vr7
.endr
    VMADD4_W vr0, vr1, vr16, vr16, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr16, vr16, vr12, vr13, vr14, vr15
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr17, vr17, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr17, vr17, vr12, vr13, vr14, vr15
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr18, vr18, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr18, vr18, vr12, vr13, vr14, vr15
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr19, vr19, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr19, vr19, vr12, vr13, vr14, vr15

    vssrani.h.w  vr10, vr8,  12
    vssrani.h.w  vr11, vr9,  12
    vssrani.h.w  vr14, vr12, 12
    vssrani.h.w  vr15, vr13, 12
    vssrani.bu.h vr14, vr10, 0
    vssrani.bu.h vr15, vr11, 0
    addi.d       t1,   t1,   64
    vilvl.b      vr4,  vr15, vr14
    vilvh.b      vr5,  vr15, vr14
    vst          vr4,  t2,   0
    vst          vr5,  t2,   16
    addi.d       t2,   t2,   32
.endr
    addi.d       t0,   t0,   -1
    add.d        a0,   a0,   a1
    add.d        a2,   a2,   a3
    blt          zero, t0,   .loopV_4tap_sp_\w\()x\h
endfunc
.endm

FILTER_VERT_4TAP_SP_WxN 32, 8,  1
FILTER_VERT_4TAP_SP_WxN 32, 16, 1
FILTER_VERT_4TAP_SP_WxN 32, 24, 1
FILTER_VERT_4TAP_SP_WxN 32, 32, 1
FILTER_VERT_4TAP_SP_WxN 32, 48, 1
FILTER_VERT_4TAP_SP_WxN 32, 64, 1
FILTER_VERT_4TAP_SP_WxN 64, 16, 2
FILTER_VERT_4TAP_SP_WxN 64, 32, 2
FILTER_VERT_4TAP_SP_WxN 64, 48, 2
FILTER_VERT_4TAP_SP_WxN 64, 64, 2

.macro FILTER_VERT_4TAP_SP_16xN_LASX h
function x265_interp_4tap_vert_sp_16x\h\()_lasx
    slli.d       a1,    a1,    1
    slli.d       t7,    a4,    3
    slli.d       t1,    a1,    1
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t5,    t6,    t7
    add.d        t2,    t1,    a1
    addi.d       t0,    zero,  \h/2
    sub.d        t6,    a0,    a1

    slli.d       t7,    a3,    1
    xvldrepl.h   xr16,  t5,    0 + 256
    xvldrepl.h   xr17,  t5,    2 + 256
    xvldrepl.h   xr18,  t5,    4 + 256
    xvldrepl.h   xr19,  t5,    6 + 256
    xvld         xr20,  t4,    32
    add.d        a0,    t6,    t2
    xvld         xr0,   t6,    0
    xvldx        xr1,   t6,    a1
    xvldx        xr2,   t6,    t1
.loopV_4tap_sp_lasx_16x\h:
    xvld         xr3,   a0,    0
    xvldx        xr4,   a0,    a1
.irp x, xr10, xr11, xr12, xr13
    xvor.v       \x,    xr20,  xr20
.endr
    XMADD4_W xr0, xr1, xr16, xr16, xr10, xr11, xr12, xr13
    XMADD4_W xr1, xr2, xr17, xr17, xr10, xr11, xr12, xr13
    XMADD4_W xr2, xr3, xr18, xr18, xr10, xr11, xr12, xr13
    XMADD4_W xr3, xr4, xr19, xr19, xr10, xr11, xr12, xr13
    xvor.v        xr0,  xr2,  xr2
    xvor.v        xr1,  xr3,  xr3
    xvor.v        xr2,  xr4,  xr4
    xvssrani.h.w  xr12, xr10, 12
    xvssrani.h.w  xr13, xr11, 12
    xvilvl.h      xr10, xr13, xr12
    xvilvh.h      xr11, xr13, xr12
    add.d         a0,   a0,   t1
    xvssrani.bu.h xr11, xr10, 0
    addi.d        t0,   t0,   -1
    xvpermi.d     xr12, xr11, 0xD8
    xvpermi.d     xr13, xr11, 0x8D
    vst           vr12, a2,   0
    vstx          vr13, a2,   a3
    add.d         a2,   a2,   t7
    blt           zero, t0,   .loopV_4tap_sp_lasx_16x\h
endfunc
.endm

FILTER_VERT_4TAP_SP_16xN_LASX 4
FILTER_VERT_4TAP_SP_16xN_LASX 8
FILTER_VERT_4TAP_SP_16xN_LASX 12
FILTER_VERT_4TAP_SP_16xN_LASX 16
FILTER_VERT_4TAP_SP_16xN_LASX 24
FILTER_VERT_4TAP_SP_16xN_LASX 32
FILTER_VERT_4TAP_SP_16xN_LASX 64

.macro FILTER_VERT_4TAP_SP_24xN_LASX h
function x265_interp_4tap_vert_sp_24x\h\()_lasx
    slli.d       a1,    a1,    1
    slli.d       t7,    a4,    3
    slli.d       t1,    a1,    1
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t5,    t6,    t7
    add.d        t2,    t1,    a1
    addi.d       t0,    zero,  \h/2
    sub.d        a0,    a0,    a1

    xvldrepl.h   xr16,  t5,    0 + 256
    xvldrepl.h   xr17,  t5,    2 + 256
    xvldrepl.h   xr18,  t5,    4 + 256
    xvldrepl.h   xr19,  t5,    6 + 256
    xvld         xr20,  t4,    32
    addi.d       t6,    a0,    32
    xvld         xr0,   a0,    0
    xvldx        xr1,   a0,    a1
    xvldx        xr2,   a0,    t1
    add.d        a0,    a0,    t2
    vld          vr5,   t6,    0
    vldx         vr6,   t6,    a1
    vldx         vr7,   t6,    t1
    xvpermi.q    xr5,   xr6,   0x2
    xvpermi.q    xr6,   xr7,   0x2
.loopV_4tap_sp_lasx_24x\h:
    addi.d       t6,    a0,    32
    xvld         xr3,   a0,    0
    xvldx        xr4,   a0,    a1
    xvld         xr8,   t6,    0
    xvldx        xr9,   t6,    a1
.irp x, xr10, xr11, xr12, xr13, xr14, xr15
    xvor.v       \x,    xr20,  xr20
.endr
    xvpermi.q    xr7,   xr8,   0x2
    xvpermi.q    xr8,   xr9,   0x2
    XMADD4_W xr0,  xr1,  xr16, xr16, xr10, xr11, xr12, xr13
    XMADD4_W xr5,  xr1,  xr16, xr17, xr14, xr15, xr10, xr11
    XMADD4_W xr2,  xr6,  xr17, xr17, xr12, xr13, xr14, xr15
    XMADD4_W xr2,  xr3,  xr18, xr18, xr10, xr11, xr12, xr13
    XMADD4_W xr7,  xr3,  xr18, xr19, xr14, xr15, xr10, xr11
    XMADD4_W xr4,  xr8,  xr19, xr19, xr12, xr13, xr14, xr15

    xvor.v        xr0,  xr2,  xr2
    xvor.v        xr1,  xr3,  xr3
    xvor.v        xr2,  xr4,  xr4
    xvor.v        xr5,  xr7,  xr7
    xvor.v        xr6,  xr8,  xr8
    xvor.v        xr7,  xr9,  xr9
    xvssrani.h.w  xr15, xr14, 12
    xvssrani.h.w  xr12, xr10, 12
    xvssrani.h.w  xr13, xr11, 12
    xvpermi.d     xr14, xr15, 0xB1
    xvilvl.h      xr3,  xr13, xr12
    xvilvh.h      xr4,  xr13, xr12
    xvilvl.h      xr8,  xr14, xr15
    addi.d        t0,   t0,   -1
    xvssrani.bu.h xr4,  xr3,  0
    xvssrani.bu.h xr9,  xr8,  0
    xvpermi.d     xr21, xr4,  0xD8
    xvpermi.d     xr22, xr4,  0x8D
    vst           vr21, a2,   0
    xvstelm.d     xr9,  a2,   16,  0
    add.d         a2,   a2,   a3
    add.d         a0,   a0,   t1
    vst           vr22, a2,   0
    xvstelm.d     xr9,  a2,   16,  2
    add.d         a2,   a2,   a3
    blt           zero, t0,   .loopV_4tap_sp_lasx_24x\h
endfunc
.endm

FILTER_VERT_4TAP_SP_24xN_LASX 32
FILTER_VERT_4TAP_SP_24xN_LASX 64

function x265_interp_4tap_vert_sp_48x64_lasx
    slli.d       a1,    a1,    1
    slli.d       t7,    a4,    3
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  64
    sub.d        a0,    a0,    a1

    xvldrepl.h   xr16,  t5,    0 + 256
    xvldrepl.h   xr17,  t5,    2 + 256
    xvldrepl.h   xr18,  t5,    4 + 256
    xvldrepl.h   xr19,  t5,    6 + 256
    xvld         xr20,  t4,    32

.loopV_4tap_sp_lasx_48x64:
    xvld         xr0,   a0,    0
    xvld         xr1,   a0,    32
    xvld         xr2,   a0,    64
    add.d        t5,    a0,    a1
.irp x, xr8, xr9, xr10, xr11, xr12, xr13
    xvor.v       \x,    xr20,  xr20
.endr
    XMADD4_W xr0, xr1, xr16, xr16, xr8, xr9, xr10, xr11
    xvmaddwev.w.h xr12, xr2, xr16
    xvmaddwod.w.h xr13, xr2, xr16
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    xvld         xr2,   t5,    64
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr17, xr17, xr8, xr9, xr10, xr11
    xvmaddwev.w.h xr12, xr2, xr17
    xvmaddwod.w.h xr13, xr2, xr17
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    xvld         xr2,   t5,    64
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr18, xr18, xr8, xr9, xr10, xr11
    xvmaddwev.w.h xr12, xr2, xr18
    xvmaddwod.w.h xr13, xr2, xr18
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    xvld         xr2,   t5,    64
    XMADD4_W xr0, xr1, xr19, xr19, xr8, xr9, xr10, xr11
    xvmaddwev.w.h xr12, xr2, xr19
    xvmaddwod.w.h xr13, xr2, xr19

    xvssrani.h.w  xr13, xr12, 12
    xvssrani.h.w  xr10, xr8,  12
    xvssrani.h.w  xr11, xr9,  12
    xvpermi.d     xr14, xr13, 0xB1
    xvilvl.h      xr3,  xr11, xr10
    xvilvh.h      xr4,  xr11, xr10
    xvilvl.h      xr5,  xr14, xr13
    xvssrani.bu.h xr4,  xr3,  0
    xvssrani.bu.h xr6,  xr5,  0
    xvpermi.d     xr0,  xr4,  0xD8
    xvpermi.d     xr1,  xr6,  0xD8
    addi.d        t0,   t0,   -1
    add.d         a0,   a0,   a1
    xvst          xr0,  a2,   0
    vst           vr1,  a2,   32
    add.d         a2,   a2,   a3
    blt           zero, t0,   .loopV_4tap_sp_lasx_48x64
endfunc

.macro FILTER_VERT_4TAP_SP_WxN_LASX  w, h, rep
function x265_interp_4tap_vert_sp_\w\()x\h\()_lasx
    slli.d       a1,    a1,    1
    slli.d       t7,    a4,    3
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h
    sub.d        a0,    a0,    a1

    xvldrepl.h   xr16,  t5,    0 + 256
    xvldrepl.h   xr17,  t5,    2 + 256
    xvldrepl.h   xr18,  t5,    4 + 256
    xvldrepl.h   xr19,  t5,    6 + 256
    xvld         xr7,   t4,    32

.loopV_4tap_sp_lasx_\w\()x\h:
    move         t1,    a0
    move         t2,    a2
.rept \rep
    xvld         xr0,   t1,    0
    xvld         xr1,   t1,    32
    add.d        t5,    t1,    a1
    xvor.v       xr8,   xr7,   xr7
    xvor.v       xr9,   xr7,   xr7
    xvor.v       xr10,  xr7,   xr7
    xvor.v       xr11,  xr7,   xr7
    XMADD4_W xr0, xr1, xr16, xr16, xr8, xr9, xr10, xr11
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr17, xr17, xr8, xr9, xr10, xr11
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr18, xr18, xr8, xr9, xr10, xr11
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    XMADD4_W xr0, xr1, xr19, xr19, xr8, xr9, xr10, xr11

    xvssrani.h.w  xr10, xr8,  12
    xvssrani.h.w  xr11, xr9,  12
    addi.d        t1,   t1,   64
    xvilvl.h      xr12, xr11, xr10
    xvilvh.h      xr13, xr11, xr10
    xvssrani.bu.h xr13, xr12, 0
    xvpermi.d     xr14, xr13, 0xD8
    xvst          xr14, t2,   0
    addi.d        t2,   t2,   32
.endr
    addi.d        t0,   t0,   -1
    add.d         a0,   a0,   a1
    add.d         a2,   a2,   a3
    blt           zero, t0,   .loopV_4tap_sp_lasx_\w\()x\h
endfunc
.endm

FILTER_VERT_4TAP_SP_WxN_LASX 32, 8,  1
FILTER_VERT_4TAP_SP_WxN_LASX 32, 16, 1
FILTER_VERT_4TAP_SP_WxN_LASX 32, 24, 1
FILTER_VERT_4TAP_SP_WxN_LASX 32, 32, 1
FILTER_VERT_4TAP_SP_WxN_LASX 32, 48, 1
FILTER_VERT_4TAP_SP_WxN_LASX 32, 64, 1
FILTER_VERT_4TAP_SP_WxN_LASX 64, 16, 2
FILTER_VERT_4TAP_SP_WxN_LASX 64, 32, 2
FILTER_VERT_4TAP_SP_WxN_LASX 64, 48, 2
FILTER_VERT_4TAP_SP_WxN_LASX 64, 64, 2

.macro FILTER_VERT_4TAP_SS_2xN  h
function x265_interp_4tap_vert_ss_2x\h\()_lsx
    slli.d       a1,    a1,    1
    slli.d       a3,    a3,    1
    slli.d       t7,    a4,    3
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_chromaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/4
    sub.d        t6,    a0,    a1
    vldrepl.h    vr16,  t5,    0 + 256
    vldrepl.h    vr17,  t5,    2 + 256
    vldrepl.h    vr18,  t5,    4 + 256
    vldrepl.h    vr19,  t5,    6 + 256

    add.d        a0,    t6,    t2
    fld.s        f8,    t6,    0    //0
    fldx.s       f9,    t6,    a1   //1
    fldx.s       f10,   t6,    t1   //2

    vilvl.h      vr0,   vr9,   vr8  //0,1
    vilvl.h      vr1,   vr10,  vr9  //1,2

.loopV_4tap_ss_2x\h:
    fld.d        f11,   a0,    0    //3
    fldx.d       f12,   a0,    a1   //4
    fldx.d       f13,   a0,    t1   //5
    fldx.d       f14,   a0,    t2   //6
    vilvl.h      vr2,   vr11,  vr10 //2,3
    vilvl.h      vr3,   vr12,  vr11 //3,4
    vilvl.h      vr4,   vr13,  vr12 //4,5
    vilvl.h      vr5,   vr14,  vr13 //5,6

    vilvl.d      vr6,   vr2,   vr0  //0,1,2,3
    vilvl.d      vr7,   vr3,   vr1  //1,2,3,4
    vilvl.d      vr8,   vr4,   vr2  //2,3,4,5
    vilvl.d      vr9,   vr5,   vr3  //3,4,5,6
    vmulwev.w.h  vr20,  vr6,   vr16
    vmulwod.w.h  vr21,  vr6,   vr16
    VMADD4_W vr7, vr8, vr17, vr18, vr20, vr21, vr20, vr21
    vmaddwev.w.h vr20,  vr9,   vr19
    vmaddwod.w.h vr21,  vr9,   vr19
    vor.v            vr0,  vr4,  vr4
    vor.v            vr1,  vr5,  vr5
    vor.v            vr10, vr14, vr14

    vssrani.h.w      vr21, vr20, 6
    vstelm.w         vr21, a2,   0,  0
    add.d            a2,   a2,   a3
    vstelm.w         vr21, a2,   0,  2
    add.d            a2,   a2,   a3
    vstelm.w         vr21, a2,   0,  1
    add.d            a2,   a2,   a3
    vstelm.w         vr21, a2,   0,  3
    add.d            a0,   a0,   t3
    add.d            a2,   a2,   a3
    addi.d           t0,   t0,   -1
    blt              zero, t0,   .loopV_4tap_ss_2x\h
endfunc
.endm

FILTER_VERT_4TAP_SS_2xN  4
FILTER_VERT_4TAP_SS_2xN  8
FILTER_VERT_4TAP_SS_2xN  16

function x265_interp_4tap_vert_ss_4x2_lsx
    slli.d       a1,    a1,    1
    slli.d       a3,    a3,    1
    slli.d       t7,    a4,    3
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_chromaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    sub.d        t6,    a0,    a1
    vldrepl.h    vr16,  t5,    0 + 256
    vldrepl.h    vr17,  t5,    2 + 256
    vldrepl.h    vr18,  t5,    4 + 256
    vldrepl.h    vr19,  t5,    6 + 256

    fld.d        f8,    t6,    0    //0
    fldx.d       f9,    t6,    a1   //1
    fldx.d       f10,   t6,    t1   //2
    fldx.d       f11,   t6,    t2   //3
    fldx.d       f12,   t6,    t3   //4

    vilvl.h      vr0,   vr9,   vr8  //0,1
    vilvl.h      vr1,   vr10,  vr9  //1,2
    vilvl.h      vr2,   vr11,  vr10 //2,3
    vilvl.h      vr3,   vr12,  vr11 //3,4
    vmulwev.w.h  vr6,   vr0,   vr16
    vmulwod.w.h  vr7,   vr0,   vr16
    VMADD4_W vr1, vr2, vr17, vr18, vr6, vr7, vr6, vr7
    vmaddwev.w.h vr6,   vr3,   vr19
    vmaddwod.w.h vr7,   vr3,   vr19

    vssrani.h.w  vr7,   vr6,   6
    vstelm.d     vr7,   a2,    0,  0
    add.d        a2,    a2,    a3
    vstelm.d     vr7,   a2,    0,  1
endfunc

.macro FILTER_VERT_4TAP_SS_4xN  h
function x265_interp_4tap_vert_ss_4x\h\()_lsx
    slli.d       a1,    a1,    1
    slli.d       a3,    a3,    1
    slli.d       t7,    a4,    3
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a1,    2   //srcStride * 4
    la.local     t6,    g_chromaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/4
    sub.d        t6,    a0,    a1
    vldrepl.h    vr16,  t5,    0 + 256
    vldrepl.h    vr17,  t5,    2 + 256
    vldrepl.h    vr18,  t5,    4 + 256
    vldrepl.h    vr19,  t5,    6 + 256

    add.d        a0,    t6,    t2
    fld.d        f8,    t6,    0    //0
    fldx.d       f9,    t6,    a1   //1
    fldx.d       f10,   t6,    t1   //2

    vilvl.h      vr0,   vr9,   vr8  //0,1
    vilvl.h      vr1,   vr10,  vr9  //1,2
.loopV_4tap_ss_4x\h:
    fld.d        f11,   a0,    0    //3
    fldx.d       f12,   a0,    a1   //4
    fldx.d       f13,   a0,    t1   //5
    fldx.d       f14,   a0,    t2   //6
    vilvl.h      vr2,   vr11,  vr10 //2,3
    vilvl.h      vr3,   vr12,  vr11 //3,4
    vilvl.h      vr4,   vr13,  vr12 //4,5
    vilvl.h      vr5,   vr14,  vr13 //5,6
    VMULW4_W vr0, vr2, vr16, vr16, vr6, vr7, vr8, vr9
    VMADD4_W vr1, vr3, vr17, vr17, vr6, vr7, vr8, vr9
    VMADD4_W vr2, vr4, vr18, vr18, vr6, vr7, vr8, vr9
    VMADD4_W vr3, vr5, vr19, vr19, vr6, vr7, vr8, vr9
    vor.v            vr0,  vr4,  vr4
    vor.v            vr1,  vr5,  vr5
    vor.v            vr10, vr14, vr14

    vssrani.h.w      vr7,  vr6,  6
    vssrani.h.w      vr9,  vr8,  6
    vstelm.d         vr7,  a2,   0,  0
    add.d            a2,   a2,   a3
    vstelm.d         vr7,  a2,   0,  1
    add.d            a2,   a2,   a3
    vstelm.d         vr9,  a2,   0,  0
    add.d            a2,   a2,   a3
    vstelm.d         vr9,  a2,   0,  1
    add.d            a0,   a0,   t3
    add.d            a2,   a2,   a3
    addi.d           t0,   t0,   -1
    blt              zero, t0,   .loopV_4tap_ss_4x\h
endfunc
.endm

FILTER_VERT_4TAP_SS_4xN 4
FILTER_VERT_4TAP_SS_4xN 8
FILTER_VERT_4TAP_SS_4xN 16
FILTER_VERT_4TAP_SS_4xN 32

.macro FILTER_VERT_4TAP_SS_6xN  h
function x265_interp_4tap_vert_ss_6x\h\()_lsx
    slli.d       a1,    a1,    1
    slli.d       a3,    a3,    1
    slli.d       t7,    a4,    3
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a3,    1
    la.local     t6,    g_chromaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/2
    sub.d        t6,    a0,    a1
    vldrepl.h    vr16,  t5,    0 + 256
    vldrepl.h    vr17,  t5,    2 + 256
    vldrepl.h    vr18,  t5,    4 + 256
    vldrepl.h    vr19,  t5,    6 + 256

    add.d        a0,    t6,    t2
    vld          vr0,   t6,    0    //0
    vldx         vr1,   t6,    a1   //1
    vldx         vr2,   t6,    t1   //2

.loopV_4tap_ss_6x\h:
    vld          vr3,   a0,    0   //3
    vldx         vr4,   a0,    a1  //4
    VMULW4_W vr0, vr1, vr16, vr16, vr10, vr11, vr12, vr13
    VMADD4_W vr1, vr2, vr17, vr17, vr10, vr11, vr12, vr13
    VMADD4_W vr2, vr3, vr18, vr18, vr10, vr11, vr12, vr13
    VMADD4_W vr3, vr4, vr19, vr19, vr10, vr11, vr12, vr13

    vor.v            vr0,  vr2,  vr2
    vor.v            vr1,  vr3,  vr3
    vssrani.h.w      vr12, vr10, 6
    vssrani.h.w      vr13, vr11, 6
    vor.v            vr2,  vr4,  vr4
    vilvl.h          vr10, vr13, vr12
    vilvh.h          vr11, vr13, vr12

    vstelm.d         vr10, a2,   0,    0
    vstelm.w         vr10, a2,   8,    2
    add.d            a2,   a2,   a3
    add.d            a0,   a0,   t1
    vstelm.d         vr11, a2,   0,    0
    vstelm.w         vr11, a2,   8,    2
    addi.d           t0,   t0,   -1
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_4tap_ss_6x\h
endfunc
.endm

FILTER_VERT_4TAP_SS_6xN 8
FILTER_VERT_4TAP_SS_6xN 16

.macro FILTER_VERT_4TAP_SS_8xN  h
function x265_interp_4tap_vert_ss_8x\h\()_lsx
    slli.d       a1,    a1,    1
    slli.d       a3,    a3,    1
    slli.d       t7,    a4,    3
    slli.d       t1,    a1,    1   //srcStride * 2
    slli.d       t3,    a3,    1
    la.local     t6,    g_chromaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/2
    sub.d        t6,    a0,    a1
    vldrepl.h    vr16,  t5,    0 + 256
    vldrepl.h    vr17,  t5,    2 + 256
    vldrepl.h    vr18,  t5,    4 + 256
    vldrepl.h    vr19,  t5,    6 + 256

    add.d        a0,    t6,    t2
    vld          vr0,   t6,    0    //0
    vldx         vr1,   t6,    a1   //1
    vldx         vr2,   t6,    t1   //2

.loopV_4tap_ss_8x\h:
    vld          vr3,   a0,    0   //3
    vldx         vr4,   a0,    a1  //4
    VMULW4_W vr0, vr1, vr16, vr16, vr10, vr11, vr12, vr13
    VMADD4_W vr1, vr2, vr17, vr17, vr10, vr11, vr12, vr13
    VMADD4_W vr2, vr3, vr18, vr18, vr10, vr11, vr12, vr13
    VMADD4_W vr3, vr4, vr19, vr19, vr10, vr11, vr12, vr13

    vor.v            vr0,  vr2,  vr2
    vor.v            vr1,  vr3,  vr3
    vssrani.h.w      vr12, vr10, 6
    vssrani.h.w      vr13, vr11, 6
    vor.v            vr2,  vr4,  vr4
    vilvl.h          vr10, vr13, vr12
    vilvh.h          vr11, vr13, vr12

    vst              vr10, a2,   0
    vstx             vr11, a2,   a3
    add.d            a0,   a0,   t1
    addi.d           t0,   t0,   -1
    add.d            a2,   a2,   t3
    blt              zero, t0,   .loopV_4tap_ss_8x\h
endfunc
.endm

FILTER_VERT_4TAP_SS_8xN 2
FILTER_VERT_4TAP_SS_8xN 4
FILTER_VERT_4TAP_SS_8xN 6
FILTER_VERT_4TAP_SS_8xN 8
FILTER_VERT_4TAP_SS_8xN 12
FILTER_VERT_4TAP_SS_8xN 16
FILTER_VERT_4TAP_SS_8xN 32
FILTER_VERT_4TAP_SS_8xN 64

.macro FILTER_VERT_4TAP_SS_12xN h
function x265_interp_4tap_vert_ss_12x\h\()_lsx
    slli.d       a1,    a1,    1
    slli.d       a3,    a3,    1
    slli.d       t7,    a4,    3
    slli.d       t1,    a1,    1   //srcStride * 2
    la.local     t6,    g_chromaFilter
    add.d        t2,    t1,    a1  //srcStride * 3
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/2
    sub.d        a0,    a0,    a1

    vldrepl.h    vr16,  t5,    0 + 256
    vldrepl.h    vr17,  t5,    2 + 256
    vldrepl.h    vr18,  t5,    4 + 256
    vldrepl.h    vr19,  t5,    6 + 256

    addi.d       t6,    a0,    16
    vld          vr0,   a0,    0    //0
    vldx         vr1,   a0,    a1   //1
    vldx         vr2,   a0,    t1   //2

    add.d        a0,    a0,    t2
    fld.d        f5,    t6,    0
    fldx.d       f6,    t6,    a1
    fldx.d       f7,    t6,    t1
    vilvl.h      vr5,   vr6,   vr5  //0,1

.loopV_4tap_ss_12x\h:
    add.d        t6,    a0,    a1
    vld          vr3,   a0,    0   //3
    fld.d        f8,    a0,    16  //3
    vld          vr4,   t6,    0   //4
    fld.d        f9,    t6,    16  //4
    vilvl.h      vr6,   vr8,   vr7 //2, 3
    vilvl.h      vr21,  vr20,  vr9 //4

    VMULW4_W vr0, vr1, vr16, vr16, vr10, vr11, vr12, vr13
    vmulwev.w.h  vr14, vr5, vr16
    vmulwod.w.h  vr15, vr5, vr16
    VMADD4_W vr1, vr2, vr17, vr17, vr10, vr11, vr12, vr13
    vmaddwod.w.h  vr14, vr5, vr17
    vmaddwev.w.h  vr15, vr6, vr17
    VMADD4_W vr2, vr3, vr18, vr18, vr10, vr11, vr12, vr13
    vmaddwev.w.h  vr14, vr6, vr18
    vmaddwod.w.h  vr15, vr6, vr18
    VMADD4_W vr3, vr4, vr19, vr19, vr10, vr11, vr12, vr13
    vmaddwod.w.h  vr14, vr6, vr19
    vmaddwev.w.h  vr15, vr21,vr19

    vor.v         vr0,  vr2,  vr2
    vor.v         vr1,  vr3,  vr3
    vssrani.h.w   vr12, vr10, 6
    vssrani.h.w   vr13, vr11, 6
    vssrani.h.w   vr15, vr14, 6
    vor.v         vr2,  vr4,  vr4
    vor.v         vr5,  vr6,  vr6
    vilvl.h       vr10, vr13, vr12
    vilvh.h       vr11, vr13, vr12
    vor.v         vr7,  vr9,  vr9

    vst           vr10, a2,   0
    vstelm.d      vr15, a2,   16,  0
    add.d         a2,   a2,   a3
    add.d         a0,   t6,   a1
    addi.d        t0,   t0,   -1
    vst           vr11, a2,   0
    vstelm.d      vr15, a2,   16,  1
    add.d         a2,   a2,   a3
    blt           zero, t0,   .loopV_4tap_ss_12x\h
endfunc
.endm

FILTER_VERT_4TAP_SS_12xN 16
FILTER_VERT_4TAP_SS_12xN 32

.macro FILTER_VERT_4TAP_SS_16xN  h
function x265_interp_4tap_vert_ss_16x\h\()_lsx
    slli.d       a1,    a1,    1
    slli.d       a3,    a3,    1
    slli.d       t7,    a4,    3
    slli.d       t1,    a1,    1   //srcStride * 2
    la.local     t6,    g_chromaFilter
    add.d        t2,    t1,    a1
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/2
    sub.d        a0,    a0,    a1

    vldrepl.h    vr16,  t5,    0 + 256
    vldrepl.h    vr17,  t5,    2 + 256
    vldrepl.h    vr18,  t5,    4 + 256
    vldrepl.h    vr19,  t5,    6 + 256

    addi.d       t6,    a0,    16
    vld          vr0,   a0,    0    //0
    vldx         vr1,   a0,    a1   //1
    vldx         vr2,   a0,    t1   //2

    add.d        a0,    a0,    t2
    vld          vr5,   t6,    0
    vldx         vr6,   t6,    a1
    vldx         vr7,   t6,    t1
.loopV_4tap_ss_16x\h:
    add.d        t6,    a0,    a1
    vld          vr3,   a0,    0   //3
    vld          vr8,   a0,    16
    vld          vr4,   t6,    0   //4
    vld          vr9,   t6,    16
    VMULW4_W vr0, vr1, vr16, vr16, vr10, vr11, vr12, vr13
    VMULW4_W vr5, vr6, vr16, vr16, vr14, vr15, vr21, vr22
    VMADD4_W vr1, vr2, vr17, vr17, vr10, vr11, vr12, vr13
    VMADD4_W vr6, vr7, vr17, vr17, vr14, vr15, vr21, vr22
    VMADD4_W vr2, vr3, vr18, vr18, vr10, vr11, vr12, vr13
    VMADD4_W vr7, vr8, vr18, vr18, vr14, vr15, vr21, vr22
    VMADD4_W vr3, vr4, vr19, vr19, vr10, vr11, vr12, vr13
    VMADD4_W vr8, vr9, vr19, vr19, vr14, vr15, vr21, vr22

    vor.v            vr0,  vr2,  vr2
    vor.v            vr1,  vr3,  vr3
    vor.v            vr2,  vr4,  vr4

    vssrani.h.w      vr12, vr10, 6
    vssrani.h.w      vr13, vr11, 6
    vssrani.h.w      vr21, vr14, 6
    vssrani.h.w      vr22, vr15, 6
    vor.v            vr5,  vr7,  vr7
    vor.v            vr6,  vr8,  vr8
    vor.v            vr7,  vr9,  vr9
    vilvl.h          vr10, vr13, vr12
    vilvh.h          vr11, vr13, vr12
    vilvl.h          vr14, vr22, vr21
    vilvh.h          vr15, vr22, vr21

    vst              vr10, a2,   0
    vst              vr14, a2,   16
    add.d            a2,   a2,   a3
    add.d            a0,   t6,   a1
    addi.d           t0,   t0,   -1
    vst              vr11, a2,   0
    vst              vr15, a2,   16
    add.d            a2,   a2,   a3
    blt              zero, t0,   .loopV_4tap_ss_16x\h
endfunc
.endm

FILTER_VERT_4TAP_SS_16xN 4
FILTER_VERT_4TAP_SS_16xN 8
FILTER_VERT_4TAP_SS_16xN 12
FILTER_VERT_4TAP_SS_16xN 16
FILTER_VERT_4TAP_SS_16xN 24
FILTER_VERT_4TAP_SS_16xN 32
FILTER_VERT_4TAP_SS_16xN 64

.macro FILTER_VERT_4TAP_SS_24xN h
function x265_interp_4tap_vert_ss_24x\h\()_lsx
    slli.d       a1,    a1,    1
    slli.d       a3,    a3,    1
    slli.d       t7,    a4,    3
    slli.d       t1,    a1,    1   //srcStride * 2
    la.local     t6,    g_chromaFilter
    add.d        t2,    t1,    a1
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h
    sub.d        a0,    a0,    a1

    vldrepl.h    vr16,  t5,    0 + 256
    vldrepl.h    vr17,  t5,    2 + 256
    vldrepl.h    vr18,  t5,    4 + 256
    vldrepl.h    vr19,  t5,    6 + 256

    addi.d       t6,    a0,    16
    addi.d       t7,    a0,    32
    vld          vr0,   a0,    0    //0
    vldx         vr1,   a0,    a1   //1
    vldx         vr2,   a0,    t1   //2

    add.d        a0,    a0,    t2
    vld          vr4,   t6,    0
    vldx         vr5,   t6,    a1
    vldx         vr6,   t6,    t1

    vld          vr7,   t7,    0
    vldx         vr8,   t7,    a1
    vldx         vr9,   t7,    t1
.loopV_4tap_ss_24x\h:
    vld          vr3,   a0,    0
    vld          vr21,  a0,    16
    vld          vr22,  a0,    32

    VMULW4_W vr0, vr4, vr16, vr16, vr10, vr11, vr12, vr13
    vmulwev.w.h  vr14, vr7, vr16
    vmulwod.w.h  vr15, vr7, vr16
    VMADD4_W vr1, vr5, vr17, vr17, vr10, vr11, vr12, vr13
    vmaddwev.w.h  vr14, vr8, vr17
    vmaddwod.w.h  vr15, vr8, vr17
    VMADD4_W vr2, vr6, vr18, vr18, vr10, vr11, vr12, vr13
    vmaddwev.w.h  vr14, vr9, vr18
    vmaddwod.w.h  vr15, vr9, vr18
    VMADD4_W vr3, vr21, vr19, vr19, vr10, vr11, vr12, vr13
    vmaddwev.w.h  vr14, vr22, vr19
    vmaddwod.w.h  vr15, vr22, vr19

    vor.v         vr0,  vr1,  vr1
    vor.v         vr1,  vr2,  vr2
    vor.v         vr2,  vr3,  vr3
    vssrani.h.w   vr12, vr10, 6
    vssrani.h.w   vr13, vr11, 6
    vssrani.h.w   vr15, vr14, 6
    vor.v         vr4,  vr5,  vr5
    vor.v         vr5,  vr6,  vr6
    vor.v         vr6,  vr21, vr21
    vilvl.h       vr10, vr13, vr12
    vilvh.h       vr11, vr13, vr12
    vbsrl.v       vr14, vr15, 8
    vor.v         vr7,  vr8,  vr8
    vor.v         vr8,  vr9,  vr9
    vor.v         vr9,  vr22, vr22
    vilvl.h       vr12, vr14, vr15

    vst           vr10, a2,   0
    vst           vr11, a2,   16
    vst           vr12, a2,   32
    add.d         a2,   a2,   a3
    add.d         a0,   a0,   a1
    addi.d        t0,   t0,   -1
    blt           zero, t0,   .loopV_4tap_ss_24x\h
endfunc
.endm

FILTER_VERT_4TAP_SS_24xN 32
FILTER_VERT_4TAP_SS_24xN 64

function x265_interp_4tap_vert_ss_48x64_lsx
    slli.d       a1,    a1,    1
    slli.d       a3,    a3,    1
    slli.d       t7,    a4,    3
    slli.d       t1,    a1,    1
    la.local     t6,    g_chromaFilter
    la.local     t4,    h_psOffset
    add.d        t2,    t1,    a1
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  64
    sub.d        a0,    a0,    a1

    vldrepl.h    vr16,  t5,    0 + 256
    vldrepl.h    vr17,  t5,    2 + 256
    vldrepl.h    vr18,  t5,    4 + 256
    vldrepl.h    vr19,  t5,    6 + 256

.loopV_4tap_ss_48x64:
    vld          vr0,   a0,    0
    vld          vr1,   a0,    16
    vld          vr2,   a0,    32
    vld          vr3,   a0,    48
    vld          vr4,   a0,    64
    vld          vr5,   a0,    80
    add.d        t5,    a0,    a1
    VMULW4_W vr0, vr1, vr16, vr16, vr8, vr9, vr10, vr11
    VMULW4_W vr2, vr3, vr16, vr16, vr12, vr13, vr14, vr15
    VMULW4_W vr4, vr5, vr16, vr16, vr20, vr21, vr22, vr23
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    vld          vr4,   t5,    64
    vld          vr5,   t5,    80
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr17, vr17, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr17, vr17, vr12, vr13, vr14, vr15
    VMADD4_W vr4, vr5, vr17, vr17, vr20, vr21, vr22, vr23
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    vld          vr4,   t5,    64
    vld          vr5,   t5,    80
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr18, vr18, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr18, vr18, vr12, vr13, vr14, vr15
    VMADD4_W vr4, vr5, vr18, vr18, vr20, vr21, vr22, vr23
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    vld          vr4,   t5,    64
    vld          vr5,   t5,    80
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr19, vr19, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr19, vr19, vr12, vr13, vr14, vr15
    VMADD4_W vr4, vr5, vr19, vr19, vr20, vr21, vr22, vr23

    vssrani.h.w  vr10, vr8,  6
    vssrani.h.w  vr11, vr9,  6
    vssrani.h.w  vr14, vr12, 6
    vssrani.h.w  vr15, vr13, 6
    vssrani.h.w  vr22, vr20, 6
    vssrani.h.w  vr23, vr21, 6
    vilvl.h      vr8,  vr11, vr10
    vilvh.h      vr9,  vr11, vr10
    vilvl.h      vr12, vr15, vr14
    vilvh.h      vr13, vr15, vr14
    vilvl.h      vr20, vr23, vr22
    vilvh.h      vr21, vr23, vr22
    vst          vr8,  a2,   0
    vst          vr9,  a2,   16
    vst          vr12, a2,   32
    vst          vr13, a2,   48
    vst          vr20, a2,   64
    vst          vr21, a2,   80
    addi.d       t0,   t0,   -1
    add.d        a0,   a0,   a1
    add.d        a2,   a2,   a3
    blt          zero, t0,   .loopV_4tap_ss_48x64
endfunc

.macro FILTER_VERT_4TAP_SS_WxN  w, h, rep
function x265_interp_4tap_vert_ss_\w\()x\h\()_lsx
    slli.d       a1,    a1,    1
    slli.d       a3,    a3,    1
    slli.d       t7,    a4,    3
    la.local     t6,    g_chromaFilter
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h
    sub.d        a0,    a0,    a1

    vldrepl.h    vr16,  t5,    0 + 256
    vldrepl.h    vr17,  t5,    2 + 256
    vldrepl.h    vr18,  t5,    4 + 256
    vldrepl.h    vr19,  t5,    6 + 256

.loopV_4tap_ss_\w\()x\h:
    move         t1,    a0
    move         t2,    a2
.rept \rep
    vld          vr0,   t1,    0
    vld          vr1,   t1,    16
    vld          vr2,   t1,    32
    vld          vr3,   t1,    48
    add.d        t5,    t1,    a1
    VMULW4_W vr0, vr1, vr16, vr16, vr8, vr9, vr10, vr11
    VMULW4_W vr2, vr3, vr16, vr16, vr12, vr13, vr14, vr15
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr17, vr17, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr17, vr17, vr12, vr13, vr14, vr15
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr18, vr18, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr18, vr18, vr12, vr13, vr14, vr15
    vld          vr0,   t5,    0
    vld          vr1,   t5,    16
    vld          vr2,   t5,    32
    vld          vr3,   t5,    48
    add.d        t5,    t5,    a1
    VMADD4_W vr0, vr1, vr19, vr19, vr8, vr9, vr10, vr11
    VMADD4_W vr2, vr3, vr19, vr19, vr12, vr13, vr14, vr15

    vssrani.h.w  vr10, vr8,  6
    vssrani.h.w  vr11, vr9,  6
    vssrani.h.w  vr14, vr12, 6
    vssrani.h.w  vr15, vr13, 6
    addi.d       t1,   t1,   64
    vilvl.h      vr8,  vr11, vr10
    vilvh.h      vr9,  vr11, vr10
    vilvl.h      vr12, vr15, vr14
    vilvh.h      vr13, vr15, vr14
    vst          vr8,  t2,   0
    vst          vr9,  t2,   16
    vst          vr12, t2,   32
    vst          vr13, t2,   48
    addi.d       t2,   t2,   64
.endr
    addi.d       t0,   t0,   -1
    add.d        a0,   a0,   a1
    add.d        a2,   a2,   a3
    blt          zero, t0,   .loopV_4tap_ss_\w\()x\h
endfunc
.endm

FILTER_VERT_4TAP_SS_WxN 32, 8,  1
FILTER_VERT_4TAP_SS_WxN 32, 16, 1
FILTER_VERT_4TAP_SS_WxN 32, 24, 1
FILTER_VERT_4TAP_SS_WxN 32, 32, 1
FILTER_VERT_4TAP_SS_WxN 32, 48, 1
FILTER_VERT_4TAP_SS_WxN 32, 64, 1
FILTER_VERT_4TAP_SS_WxN 64, 16, 2
FILTER_VERT_4TAP_SS_WxN 64, 32, 2
FILTER_VERT_4TAP_SS_WxN 64, 48, 2
FILTER_VERT_4TAP_SS_WxN 64, 64, 2

.macro FILTER_VERT_4TAP_SS_16xN_LASX  h
function x265_interp_4tap_vert_ss_16x\h\()_lasx
    slli.d       a1,    a1,    1
    slli.d       a3,    a3,    1
    slli.d       t7,    a4,    3
    slli.d       t1,    a1,    1
    la.local     t6,    g_chromaFilter
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/2
    add.d        t2,    t1,    a1
    sub.d        t6,    a0,    a1

    slli.d       t7,    a3,    1
    xvldrepl.h   xr16,  t5,    0 + 256
    xvldrepl.h   xr17,  t5,    2 + 256
    xvldrepl.h   xr18,  t5,    4 + 256
    xvldrepl.h   xr19,  t5,    6 + 256

    add.d        a0,    t6,    t2
    xvld         xr0,   t6,    0
    xvldx        xr1,   t6,    a1
    xvldx        xr2,   t6,    t1
.loopV_4tap_ss_lasx_16x\h:
    xvld         xr3,   a0,    0
    xvldx        xr4,   a0,    a1
    XMULW4_W xr0, xr1, xr16, xr16, xr10, xr11, xr12, xr13
    XMADD4_W xr1, xr2, xr17, xr17, xr10, xr11, xr12, xr13
    XMADD4_W xr2, xr3, xr18, xr18, xr10, xr11, xr12, xr13
    XMADD4_W xr3, xr4, xr19, xr19, xr10, xr11, xr12, xr13
    xvor.v       xr0,   xr2,   xr2
    xvor.v       xr1,   xr3,   xr3
    xvor.v       xr2,   xr4,   xr4

    xvssrani.h.w  xr12, xr10, 6
    xvssrani.h.w  xr13, xr11, 6
    xvilvl.h      xr14, xr13, xr12
    xvilvh.h      xr15, xr13, xr12
    addi.d        t0,   t0,   -1
    xvst          xr14, a2,   0
    xvstx         xr15, a2,   a3
    add.d         a0,   a0,   t1
    add.d         a2,   a2,   t7
    blt           zero, t0,   .loopV_4tap_ss_lasx_16x\h
endfunc
.endm

FILTER_VERT_4TAP_SS_16xN_LASX 4
FILTER_VERT_4TAP_SS_16xN_LASX 8
FILTER_VERT_4TAP_SS_16xN_LASX 12
FILTER_VERT_4TAP_SS_16xN_LASX 16
FILTER_VERT_4TAP_SS_16xN_LASX 24
FILTER_VERT_4TAP_SS_16xN_LASX 32
FILTER_VERT_4TAP_SS_16xN_LASX 64

.macro FILTER_VERT_4TAP_SS_24xN_LASX  h
function x265_interp_4tap_vert_ss_24x\h\()_lasx
    slli.d       a1,    a1,    1
    slli.d       a3,    a3,    1
    slli.d       t7,    a4,    3
    slli.d       t1,    a1,    1
    la.local     t6,    g_chromaFilter
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h/2
    add.d        t2,    t1,    a1
    sub.d        a0,    a0,    a1

    xvldrepl.h   xr16,  t5,    0 + 256
    xvldrepl.h   xr17,  t5,    2 + 256
    xvldrepl.h   xr18,  t5,    4 + 256
    xvldrepl.h   xr19,  t5,    6 + 256

    addi.d       t6,    a0,    32
    xvld         xr0,   a0,    0
    xvldx        xr1,   a0,    a1
    xvldx        xr2,   a0,    t1
    vld          vr5,   t6,    0
    vldx         vr6,   t6,    a1
    vldx         vr7,   t6,    t1
    add.d        a0,    a0,    t2
    xvpermi.q    xr5,   xr6,   0x2
    xvpermi.q    xr6,   xr7,   0x2
.loopV_4tap_ss_lasx_24x\h:
    addi.d       t6,    a0,    32
    xvld         xr3,   a0,    0
    xvldx        xr4,   a0,    a1
    vld          vr8,   t6,    0
    vldx         vr9,   t6,    a1
    XMULW4_W xr0, xr1, xr16, xr16, xr10, xr11, xr12, xr13
    xvmulwev.w.h  xr14, xr5,   xr16
    xvmulwod.w.h  xr15, xr5,   xr16
    xvpermi.q     xr7,  xr8,   0x2
    xvpermi.q     xr8,  xr9,   0x2
    XMADD4_W xr1, xr2, xr17, xr17, xr10, xr11, xr12, xr13
    xvmaddwev.w.h xr14, xr6,   xr17
    xvmaddwod.w.h xr15, xr6,   xr17
    XMADD4_W xr2, xr3, xr18, xr18, xr10, xr11, xr12, xr13
    xvmaddwev.w.h xr14, xr7,   xr18
    xvmaddwod.w.h xr15, xr7,   xr18
    XMADD4_W xr3, xr4, xr19, xr19, xr10, xr11, xr12, xr13
    xvmaddwev.w.h xr14, xr8,   xr19
    xvmaddwod.w.h xr15, xr8,   xr19
    xvor.v       xr0,   xr2,   xr2
    xvor.v       xr1,   xr3,   xr3
    xvor.v       xr2,   xr4,   xr4
    xvor.v       xr5,   xr7,   xr7
    xvor.v       xr6,   xr8,   xr8
    xvor.v       xr7,   xr9,   xr9

    xvssrani.h.w  xr15, xr14, 6
    xvssrani.h.w  xr12, xr10, 6
    xvssrani.h.w  xr13, xr11, 6
    xvpermi.d     xr14, xr15, 0xB1
    xvilvl.h      xr3,  xr13, xr12
    xvilvh.h      xr4,  xr13, xr12
    xvilvl.h      xr8,  xr14, xr15
    addi.d        t0,   t0,   -1
    xvst          xr3,  a2,   0
    vst           vr8,  a2,   32
    add.d         a2,   a2,   a3
    xvpermi.d     xr9,  xr8,  0x4E
    add.d         a0,   a0,   t1
    xvst          xr4,  a2,   0
    vst           vr9,  a2,   32
    add.d         a2,   a2,   a3
    blt           zero, t0,   .loopV_4tap_ss_lasx_24x\h
endfunc
.endm

FILTER_VERT_4TAP_SS_24xN_LASX 32
FILTER_VERT_4TAP_SS_24xN_LASX 64

function x265_interp_4tap_vert_ss_48x64_lasx
    slli.d       a1,    a1,    1
    slli.d       a3,    a3,    1
    slli.d       t7,    a4,    3
    la.local     t6,    g_chromaFilter
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  64
    sub.d        a0,    a0,    a1

    xvldrepl.h   xr16,  t5,    0 + 256
    xvldrepl.h   xr17,  t5,    2 + 256
    xvldrepl.h   xr18,  t5,    4 + 256
    xvldrepl.h   xr19,  t5,    6 + 256

.loopV_4tap_ss_lasx_48x64:
    xvld         xr0,   a0,    0
    xvld         xr1,   a0,    32
    xvld         xr2,   a0,    64
    add.d        t5,    a0,    a1
    XMULW4_W xr0, xr1, xr16, xr16, xr8, xr9, xr10, xr11
    xvmulwev.w.h  xr12, xr2,   xr16
    xvmulwod.w.h  xr13, xr2,   xr16
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    xvld         xr2,   t5,    64
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr17, xr17, xr8, xr9, xr10, xr11
    xvmaddwev.w.h xr12, xr2,   xr17
    xvmaddwod.w.h xr13, xr2,   xr17
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    xvld         xr2,   t5,    64
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr18, xr18, xr8, xr9, xr10, xr11
    xvmaddwev.w.h xr12, xr2,   xr18
    xvmaddwod.w.h xr13, xr2,   xr18
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    xvld         xr2,   t5,    64
    XMADD4_W xr0, xr1, xr19, xr19, xr8, xr9, xr10, xr11
    xvmaddwev.w.h xr12, xr2,   xr19
    xvmaddwod.w.h xr13, xr2,   xr19

    xvssrani.h.w  xr13, xr12, 6
    xvssrani.h.w  xr10, xr8,  6
    xvssrani.h.w  xr11, xr9,  6
    xvpermi.d     xr14, xr13, 0xB1
    xvilvl.h      xr3,  xr11, xr10
    xvilvh.h      xr4,  xr11, xr10
    xvilvl.h      xr5,  xr14, xr13
    xvst          xr3,  a2,   0
    xvst          xr4,  a2,   32
    xvst          xr5,  a2,   64
    addi.d        t0,   t0,   -1
    add.d         a0,   a0,   a1
    add.d         a2,   a2,   a3
    blt           zero, t0,   .loopV_4tap_ss_lasx_48x64
endfunc

.macro FILTER_VERT_4TAP_SS_WxN_LASX  w, h, rep
function x265_interp_4tap_vert_ss_\w\()x\h\()_lasx
    slli.d       a1,    a1,    1
    slli.d       a3,    a3,    1
    slli.d       t7,    a4,    3
    la.local     t6,    g_chromaFilter
    add.d        t5,    t6,    t7
    addi.d       t0,    zero,  \h
    sub.d        a0,    a0,    a1

    xvldrepl.h   xr16,  t5,    0 + 256
    xvldrepl.h   xr17,  t5,    2 + 256
    xvldrepl.h   xr18,  t5,    4 + 256
    xvldrepl.h   xr19,  t5,    6 + 256

.loopV_4tap_ss_lasx_\w\()x\h:
    move         t1,    a0
    move         t2,    a2
.rept \rep
    xvld         xr0,   t1,    0
    xvld         xr1,   t1,    32
    add.d        t5,    t1,    a1
    XMULW4_W xr0, xr1, xr16, xr16, xr8, xr9, xr10, xr11
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr17, xr17, xr8, xr9, xr10, xr11
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    add.d        t5,    t5,    a1
    XMADD4_W xr0, xr1, xr18, xr18, xr8, xr9, xr10, xr11
    xvld         xr0,   t5,    0
    xvld         xr1,   t5,    32
    XMADD4_W xr0, xr1, xr19, xr19, xr8, xr9, xr10, xr11

    xvssrani.h.w  xr10, xr8,  6
    xvssrani.h.w  xr11, xr9,  6
    addi.d        t1,   t1,   64
    xvilvl.h      xr12, xr11, xr10
    xvilvh.h      xr13, xr11, xr10
    xvst          xr12, t2,   0
    xvst          xr13, t2,   32
    addi.d        t2,   t2,   64
.endr
    addi.d        t0,   t0,   -1
    add.d         a0,   a0,   a1
    add.d         a2,   a2,   a3
    blt           zero, t0,   .loopV_4tap_ss_lasx_\w\()x\h
endfunc
.endm

FILTER_VERT_4TAP_SS_WxN_LASX 32, 8,  1
FILTER_VERT_4TAP_SS_WxN_LASX 32, 16, 1
FILTER_VERT_4TAP_SS_WxN_LASX 32, 24, 1
FILTER_VERT_4TAP_SS_WxN_LASX 32, 32, 1
FILTER_VERT_4TAP_SS_WxN_LASX 32, 48, 1
FILTER_VERT_4TAP_SS_WxN_LASX 32, 64, 1
FILTER_VERT_4TAP_SS_WxN_LASX 64, 16, 2
FILTER_VERT_4TAP_SS_WxN_LASX 64, 32, 2
FILTER_VERT_4TAP_SS_WxN_LASX 64, 48, 2
FILTER_VERT_4TAP_SS_WxN_LASX 64, 64, 2
